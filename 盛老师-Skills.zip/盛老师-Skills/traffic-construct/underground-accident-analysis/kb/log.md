# Wiki 操作日志

本文件按时间顺序记录 wiki 的所有操作——ingest、query、lint。每条记录以 `## [YYYY-MM-DD] 操作类型 | 描述` 开头，方便 `grep` 解析。

---

## [2026-06-04] ingest | PDF《地下工程事故案例汇编_初稿》批量导入

**变更**：
- 使用 MinerU SDK（`vlm-http-client`）将 PDF 转为 `pdf_output/地下工程事故案例汇编_初稿_clean.md`（697 页，无图片）
- 拆分 251 个案例片段，DeepSeek 并发生成 wiki 页（5 workers，thinking 关闭）
- 导入 wiki **241** 篇，测试集 **10** 篇（`test_set/`）
- 运行 `update_index.py` 更新 `wiki/index.md`

**来源**：`地下工程事故案例汇编_初稿.pdf`（第2–11章）

## [2026-06-04] lint | 去重与乱码文件名清理

**变更**：
- 运行 `dedup_cases.py`：删除乱码文件名 **47** 篇、同标题重复 **51** 篇（含 `CASE-2006-C001` 董家渡漏水，保留 `CASE-2006-C022`）
- 运行 `update_index.py` 刷新索引，当前 wiki 案例 **204** 篇（PDF 汇编 147 篇）

---

## [2026-05-23] rebuild | 基于 Karpathy LLM-Wiki 理念重新构建 wiki 和 schema

**变更**：
- 创建 `CLAUDE.md`（schema 层：wiki 维护指南）
- 创建 `wiki/index.md`（内容目录）
- 创建 `wiki/log.md`（本文件）
- 创建 `wiki/overview.md`（综述页）
- 创建概念页：`collapse.md`、`water-inrush.md`、`ground-subsidence.md`、`shield-construction.md`、`open-cut-construction.md`、`soft-soil.md`、`cause-patterns.md`、`risk-management.md`
- 将原有 132 篇案例从 `wiki/cases/` 迁移至 `wiki/pages/cases/`
- 删除旧 `schema/` 目录（YAML 数据模式已合并至 `CLAUDE.md` 附录）
- 删除旧 `skills/` 目录（查询能力由 `CLAUDE.md` 的工作流定义替代）

**来源**：基于 `doc-markdown/` 中已解析的 14 篇 MinerU 输出
