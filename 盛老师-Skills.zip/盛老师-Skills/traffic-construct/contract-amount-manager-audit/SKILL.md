---
name: contract-amount-manager-audit
description: 审核工程总包与分包合同中的合同金额和履约负责人，按固定批次交给当前 Agent 模型抽取，计算分包合计、占比并生成 Excel。用户上传总包及分包 PDF，要求审查、核对或对比合同金额，或提取项目经理、技术负责人、安全负责人、甲乙方代表时使用。
allowed-tools: [parse_document, bash, read_file, write_file, present_files]
---

# 工程合同金额审查

总包与分包 PDF → `parse_document` → `prepare_contracts.py` 一次生成全部批次 → Agent 顺序抽取 → `review_contract.py` 生成 Excel。

合同语义由当前 Agent 模型判断；脚本负责批次准备、结果合并、候选打分、进度推进、早停、金额计算和 Excel 导出。

## 路径规则

- 将本轮实际加载的 `SKILL.md` 所在目录记为 `SKILL_DIR`。
- 所有脚本都从 `<SKILL_DIR>/scripts/` 调用；执行时替换成真实目录，不要把尖括号传给 shell。
- 不要假设 Skill 位于固定的 `/mnt` 或 Windows 路径，也不要运行 `find`、`which`、`Get-Command` 寻找脚本。

## 工作流（4 步）

```text
步骤 1  parse_document(每份合同 PDF)
        → /mnt/user-data/outputs/{stem}.md + {stem}_middle.json
步骤 2  python "<SKILL_DIR>/scripts/prepare_contracts.py" --main ... --sub ... --output-dir ... --batch-pages 8
        → batch_manifest.json + contract_extract.json + 全部批次 Markdown
步骤 3  advance_extract.py --next → read_file → 固定单批 JSON → advance_extract.py --submit
        → 脚本返回下一批或 stop
步骤 4  python "<SKILL_DIR>/scripts/review_contract.py" --from-json ... --output ... --json [--allow-incomplete]
        → 合同金额审查.xlsx → present_files
```

只按这 4 步执行，不设计替代流程。

## 步骤 1 — 解析每份合同

对用户上传的每份总包、分包 PDF 调用：

```text
parse_document(file_path="/mnt/user-data/uploads/<合同 PDF 原始路径>")
```

- 已存在同名 `.md` 和 `_middle.json` 时直接复用，不要重复解析。
- 等待全部 `parse_document` 完成后再进入步骤 2。
- 此时不要读取完整 `.md`，也不要搜索合同金额或人员。

**进入步骤 2 的条件：**每份合同至少存在 `_middle.json`；只有已知合同不超过 8 页时才允许用完整 `.md` 代替。

## 步骤 2 — 一次生成全部批次

只运行一次，`--main` 传总包，所有分包分别重复一个 `--sub`：

```bash
python "<SKILL_DIR>/scripts/prepare_contracts.py" --main "/mnt/user-data/outputs/<总包stem>_middle.json" --sub "/mnt/user-data/outputs/<分包1stem>_middle.json" --sub "/mnt/user-data/outputs/<分包2stem>_middle.json" --output-dir "/mnt/user-data/outputs/contract_batches" --batch-pages 8
```

脚本成功后输出 manifest 和累计 JSON 路径，例如：

```json
{"manifest":".../batch_manifest.json","extract":".../contract_extract.json"}
```

立即执行以下校验：

1. 用 `read_file` 读取返回的 manifest。
2. 确认恰好一份 `kind=main`。
3. 确认 `kind=sub` 数量等于上传的分包数量。
4. 确认每份合同 `batch_count >= 1`。
5. 用 `read_file` 读取返回的 `contract_extract.json`，确认总包和全部分包均有唯一 `contract_id`，且状态为 `pending`。

不要列目录、不要拼接合同目录名、不要逐批运行脚本。批次只使用 manifest 中的 `path` 原文。

**进入步骤 3 的条件：**manifest 与累计 JSON 均已通过上述校验。

## 步骤 3 — 状态机逐批推进

逐份合同处理。Agent 不得手动修改 `contract_extract.json`，不自行计算分数、进度或下一批路径。

### 3.1 获取当前动作

对累计 JSON 中每个 `contract_id` 执行：

```bash
python "<SKILL_DIR>/scripts/advance_extract.py" --manifest "/mnt/user-data/outputs/contract_batches/batch_manifest.json" --extract "/mnt/user-data/outputs/contract_batches/contract_extract.json" --contract-id "<CONTRACT_ID>" --next
```

只按脚本返回的 `action` 执行：

- `action="read"`：进入 3.2，只读取返回的 `batch_path`。
- `action="stop"`：该合同完成，换下一个 `contract_id`。

### 3.2 读取批次并生成单批 JSON

```text
read_file(path="<batch_path>")
```

总包批次固定写到 `/mnt/user-data/outputs/contract_batches/batch_result.json`：

```json
{
  "amount_lower_raw": "",
  "amount_upper_raw": "",
  "amount_unit": "元",
  "contractor_pm": "",
  "tech_lead": "",
  "safety_lead": ""
}
```

分包批次使用同一路径，固定结构为：

```json
{
  "amount_lower_raw": "",
  "amount_upper_raw": "",
  "amount_unit": "元",
  "party_a_candidates": [{"label": "原文职务", "name": "姓名"}],
  "party_b_candidates": [{"label": "原文职务", "name": "姓名"}]
}
```

本批没有的字段留空；候选数组没有结果时填 `[]`。金额与人员仍遵守“抽取铁律”。

### 3.3 提交本批结果

```bash
python "<SKILL_DIR>/scripts/advance_extract.py" --manifest "/mnt/user-data/outputs/contract_batches/batch_manifest.json" --extract "/mnt/user-data/outputs/contract_batches/contract_extract.json" --contract-id "<CONTRACT_ID>" --submit "/mnt/user-data/outputs/contract_batches/batch_result.json"
```

脚本自动完成：

- 金额保护，不用后续数字覆盖已有有效金额。
- 总包人员只填空字段。
- 分包候选去重、过滤黑名单、按 `pm_scoring.py` 打分。
- `batches_processed` 增加 1。
- 分包双方 `rank >= 70` 与总包必填字段的早停判断。
- 文末缺失标记为 `not_stated`，低分候选标记为 `below_threshold`。
- 原子写回 `contract_extract.json`。

再次只按返回值执行：

- `action="read"`：返回 3.2，读取新的 `batch_path`。
- `action="stop"`：该合同结束，处理下一个 `contract_id`。

禁止在 `--submit` 返回前预读下一批，禁止重复提交同一批次。

**进入步骤 4 的条件：**总包和每份分包均为 `read_progress.complete=true`，且没有字段仍为 `pending`。

## 步骤 4 — 生成报告

字段完整时运行：

```bash
python "<SKILL_DIR>/scripts/review_contract.py" --from-json "/mnt/user-data/outputs/contract_batches/contract_extract.json" --output "/mnt/user-data/outputs/合同金额审查.xlsx" --json
```

存在 `not_stated`，或分包任一侧最佳候选低于 70 分时运行：

```bash
python "<SKILL_DIR>/scripts/review_contract.py" --from-json "/mnt/user-data/outputs/contract_batches/contract_extract.json" --output "/mnt/user-data/outputs/合同金额审查.xlsx" --json --allow-incomplete
```

- 仅当用户明确提供项目名称时添加 `--name "<项目名称>"`。
- 不要由 Agent 自行计算分包合计、占比或比较结论。
- 成功后用 `present_files` 展示 `/mnt/user-data/outputs/合同金额审查.xlsx`。
- 文字汇报必须逐份列出最终核查到的合同金额；每份分包合同必须同时列出甲方人员和乙方人员，并保留原文职务标签与姓名。不得只汇报甲方人员或人员一致性结论。另须汇报分包合计、占比、比较结论，以及所有 `not_stated` 字段。

## 抽取铁律

- 金额只取《合同协议书》《协议书》《承包合同》《分包合同》正文的合同价格、合同金额、签约合同价或合同总价。
- 严禁从工程量清单、结算表、报价单、计价明细中的合计、小计或总价取数。
- 大写和小写同时出现时都原样保留；只有小写时大写留空；保留原文单位。
- 分包双方候选必须保留原文标签，不得自行改写职务。
- 忽略法定代表人、法人代表、法定代理人、质量员、材料员、施工员、资料员和安全员。

## 失败处理

- 步骤 1 失败：报告具体 PDF 和 `parse_document` 错误，不进入步骤 2。
- `prepare_contracts.py` 非零退出：报告实际错误，不寻找其他脚本、不切换 Python 命令、不创建临时脚本。
- `advance_extract.py` 非零退出：报告实际错误，不手改累计 JSON；检查本次 `contract_id` 和单批 JSON 后只重试一次。
- `advance_extract.py` 返回未知 `action`：停止并报告原始 JSON，不自行猜测下一批。
- manifest 中批次路径不存在：报告 manifest 与缺失路径，不猜测目录名。
- `review_contract.py` 退出码 `2`：若仍有未完成合同，只继续其未读批次；若全部完成，添加 `--allow-incomplete` 重跑一次。
- 其他错误只按实际报错修正一次，不绕过脚本手算或自行生成 Excel。

## 禁止操作

- 不得对完整 `.md` 或 `*.md` 使用 `grep`、全文正则或 Python 搜索。
- 不得重复读取本 `SKILL.md`。
- 不得调用已废弃的 `page_splitter.py`、`make_page_batch.py`、`merge_extracts.py`、`score_candidates.py`。
- 不得手动编辑 `contract_extract.json`；只能通过 `advance_extract.py --submit` 更新。
- 不得配置外部 LLM API；批次由当前 Agent 模型直接处理。
