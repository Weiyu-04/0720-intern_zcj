"""Validate Agent extraction JSON and generate the deterministic audit workbook."""
from __future__ import annotations

import argparse
import json
import logging
import re
import sys
from pathlib import Path
from typing import Any


SCRIPTS_DIR = Path(__file__).resolve().parent
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

from app.excel_writer import build_workbook  # noqa: E402
from app.number_utils import clean_str, resolve_amount  # noqa: E402
from app.pm_scoring import party_side_satisfied, pick_party_side, pm_label_rank  # noqa: E402
from app.schemas import MainContractInfo, ReviewReport, SubContractInfo  # noqa: E402


logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("review_contract")
DEFAULT_PROJECT_NAME = "合同金额审查"
DEFAULT_MAIN_NAME = "总包合同"


class IncompleteExtractionError(RuntimeError):
    """Required fields are absent and incomplete output was not allowed."""


def _label(name: str) -> str:
    return re.sub(r"\.pdf$", "", name or "", flags=re.IGNORECASE)


def _build_main(main: dict[str, Any]) -> MainContractInfo:
    amount, lower, upper_raw = resolve_amount(
        main.get("amount_lower_raw"),
        main.get("amount_upper_raw"),
        unit_hint=str(main.get("amount_unit") or ""),
    )
    name = clean_str(main.get("name")) or DEFAULT_MAIN_NAME
    return MainContractInfo(
        file_name=name,
        file_label=_label(name),
        amount=amount,
        amount_lower=lower,
        amount_upper_raw=upper_raw,
        contractor_pm=clean_str(main.get("contractor_pm")),
        tech_lead=clean_str(main.get("tech_lead")),
        safety_lead=clean_str(main.get("safety_lead")),
    )


def _resolve_party_side(sub: dict[str, Any], side: str) -> tuple[str, str]:
    candidates = sub.get(f"party_{side}_candidates")
    if isinstance(candidates, list) and candidates:
        label, name, _ = pick_party_side(candidates)
        return label, name
    label = clean_str(sub.get(f"party_{side}_label"))
    name = clean_str(sub.get(f"party_{side}_name"))
    if not name or pm_label_rank(label) == 0:
        return "", ""
    return label, name


def _build_sub(sub: dict[str, Any], index: int) -> SubContractInfo:
    amount, lower, upper_raw = resolve_amount(
        sub.get("amount_lower_raw"),
        sub.get("amount_upper_raw"),
        unit_hint=str(sub.get("amount_unit") or ""),
    )
    name = clean_str(sub.get("name")) or f"分包合同{index}"
    a_label, a_name = _resolve_party_side(sub, "a")
    b_label, b_name = _resolve_party_side(sub, "b")
    return SubContractInfo(
        file_name=name,
        file_label=_label(name),
        amount=amount,
        amount_lower=lower,
        amount_upper_raw=upper_raw,
        party_a_label=a_label,
        party_a_name=a_name,
        party_b_label=b_label,
        party_b_name=b_name,
    )


def collect_missing(report: ReviewReport) -> list[str]:
    missing: list[str] = []
    main = report.main_contract
    if main.amount <= 0:
        missing.append(f"总包「{main.file_label}」金额未载明")
    if not main.contractor_pm:
        missing.append(f"总包「{main.file_label}」承包人项目经理未载明")
    if not main.tech_lead:
        missing.append(f"总包「{main.file_label}」技术负责人未载明")
    if not main.safety_lead:
        missing.append(f"总包「{main.file_label}」安全负责人未载明")
    for sub in report.sub_contracts:
        if sub.amount <= 0:
            missing.append(f"分包「{sub.file_label}」金额未载明")
        if not party_side_satisfied(sub.party_a_label, sub.party_a_name):
            missing.append(f"分包「{sub.file_label}」甲方人员未达到 rank >= 70")
        if not party_side_satisfied(sub.party_b_label, sub.party_b_name):
            missing.append(f"分包「{sub.file_label}」乙方人员未达到 rank >= 70")
    return missing


def review_from_json(
    data: dict[str, Any],
    project_name: str = DEFAULT_PROJECT_NAME,
    *,
    allow_incomplete: bool = False,
) -> ReviewReport:
    if not isinstance(data, dict):
        raise ValueError("抽取 JSON 顶层必须是对象")
    main = data.get("main")
    if not isinstance(main, dict):
        raise ValueError("抽取 JSON 缺少 'main' 对象")
    subs = data.get("subs") or []
    if not isinstance(subs, list) or any(not isinstance(item, dict) for item in subs):
        raise ValueError("'subs' 必须是对象数组")

    main_info = _build_main(main)
    sub_infos = [_build_sub(item, index) for index, item in enumerate(subs, 1)]
    sub_sum = round(sum(item.amount for item in sub_infos), 2)
    main_amount = round(main_info.amount, 2)
    ratio = round(sub_sum / main_amount * 100, 2) if main_amount > 0 else 0.0
    less = sub_sum < main_amount
    report = ReviewReport(
        project_name=project_name,
        main_contract=main_info,
        sub_contracts=sub_infos,
        main_amount=main_amount,
        sub_sum=sub_sum,
        comparison="<" if less else ">=",
        comparison_text="分包之和<总包" if less else "分包之和>=总包",
        ratio_percent=ratio,
        ratio_text=f"{ratio:.2f}%",
    )
    missing = collect_missing(report)
    if missing and not allow_incomplete:
        raise IncompleteExtractionError(
            "抽取存在未载明字段；全文已处理时使用 --allow-incomplete：\n  - " + "\n  - ".join(missing)
        )
    return report


def _print_summary(report: ReviewReport) -> None:
    print(f"总包金额: {report.main_amount:,.2f} 元")
    print(f"分包合计: {report.sub_sum:,.2f} 元")
    print(f"对比结果: {report.comparison_text}")
    print(f"分包占比: {report.ratio_text}")
    main = report.main_contract
    print(f"总包负责人: 项目经理={main.contractor_pm} 技术={main.tech_lead} 安全={main.safety_lead}")
    for index, sub in enumerate(report.sub_contracts, 1):
        print(
            f"分包{index:02d} {sub.file_label}: {sub.amount:,.2f} 元 "
            f"{sub.party_a_label}={sub.party_a_name} {sub.party_b_label}={sub.party_b_name}"
        )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="读取合同抽取 JSON 并生成 Excel 审查表")
    parser.add_argument("--from-json", required=True, dest="from_json")
    parser.add_argument("--name", default=None)
    parser.add_argument("--output", default=None)
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--allow-incomplete", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    source = Path(args.from_json).expanduser()
    if not source.is_file():
        logger.error("未找到抽取 JSON: %s", source)
        return 1
    try:
        data = json.loads(source.read_text(encoding="utf-8-sig"))
        report = review_from_json(
            data,
            project_name=args.name or DEFAULT_PROJECT_NAME,
            allow_incomplete=args.allow_incomplete,
        )
    except IncompleteExtractionError as exc:
        logger.error("%s", exc)
        return 2
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        logger.error("%s", exc)
        return 1

    output = Path(args.output).expanduser().resolve() if args.output else Path.cwd() / "合同金额审查.xlsx"
    _print_summary(report)
    workbook = build_workbook(report)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(workbook)
    logger.info("Excel 已保存 -> %s", output)
    if args.json:
        result = report.model_copy(update={"excel_base64": None}).model_dump()
        result_path = output.with_suffix(".json")
        if result_path.resolve() == source.resolve():
            result_path = output.with_name(output.stem + "_result.json")
        result_path.write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
