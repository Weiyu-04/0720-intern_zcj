"""Prepare all contract Markdown batches and a deterministic processing manifest."""
from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path
from typing import Callable


logger = logging.getLogger("prepare_contracts")


def _name_from_path(path: Path) -> str:
    if path.name.endswith("_middle.json"):
        return path.name[: -len("_middle.json")]
    return path.stem


def _fallback_md(path: Path) -> list[str]:
    md_path = path if path.suffix.lower() == ".md" else path.parent / f"{_name_from_path(path)}.md"
    if not md_path.is_file():
        return []
    text = md_path.read_text(encoding="utf-8-sig", errors="replace").strip()
    return [text] if text else []


def _get_union_make(middle: dict) -> Callable[[list[dict], str], str]:
    from mineru.utils.enum_class import MakeMode

    backend = str(middle.get("_backend") or "vlm").lower()
    if backend == "pipeline":
        from mineru.backend.pipeline.pipeline_middle_json_mkcontent import union_make
    else:
        from mineru.backend.vlm.vlm_middle_json_mkcontent import union_make
    return lambda page_list, image_dir: union_make(page_list, MakeMode.MM_MD, image_dir)


def load_pages(path: Path) -> tuple[list[str], str]:
    if path.suffix.lower() == ".md":
        return _fallback_md(path), "full_markdown"
    try:
        middle = json.loads(path.read_text(encoding="utf-8-sig"))
        pdf_info = middle.get("pdf_info") if isinstance(middle, dict) else None
        if not isinstance(pdf_info, list) or not pdf_info:
            raise ValueError("missing pdf_info")
        make = _get_union_make(middle)
        image_dir = "images" if (path.parent / "images").is_dir() else ""
        pages = [
            (make([page], image_dir) or "").strip()
            for page in sorted(pdf_info, key=lambda item: int(item.get("page_idx", 0)))
        ]
        return pages, "middle_json"
    except Exception as exc:
        logger.warning("%s 无法恢复逐页 Markdown，回退同名完整 Markdown: %s", path, exc)
        return _fallback_md(path), "full_markdown_fallback"


def _safe_id(kind: str, index: int, name: str) -> str:
    safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in name).strip("_")
    return f"{kind}_{index:02d}_{safe[:48] or 'contract'}"


def prepare_one(
    source: Path,
    kind: str,
    index: int,
    output_dir: Path,
    batch_pages: int,
) -> dict:
    pages, source_mode = load_pages(source)
    if not pages:
        raise ValueError(f"未能从 {source} 读取合同文本")
    name = _name_from_path(source)
    contract_id = _safe_id(kind, index, name)
    contract_dir = output_dir / contract_id
    contract_dir.mkdir(parents=True, exist_ok=True)
    batches = []
    for start in range(0, len(pages), batch_pages):
        end = min(start + batch_pages, len(pages))
        batch_path = contract_dir / f"batch_{start:03d}_{end - 1:03d}.md"
        parts = [
            f"<!-- PAGE {page_index:03d} -->\n\n{pages[page_index].strip()}"
            for page_index in range(start, end)
        ]
        batch_path.write_text("\n\n".join(parts).rstrip() + "\n", encoding="utf-8")
        batches.append(
            {
                "index": len(batches),
                "start_page_index": start,
                "end_page_index": end - 1,
                "path": batch_path.as_posix(),
            }
        )
    return {
        "id": contract_id,
        "kind": kind,
        "name": name,
        "source": source.as_posix(),
        "source_mode": source_mode,
        "total_pages": len(pages),
        "batch_count": len(batches),
        "batches": batches,
    }


def initial_extract(manifest: dict) -> dict:
    main_contract = next(item for item in manifest["contracts"] if item["kind"] == "main")
    main = {
        "contract_id": main_contract["id"],
        "name": main_contract["name"],
        "read_progress": {"total_pages": main_contract["total_pages"], "batches_processed": 0, "complete": False},
        "field_status": {"amount": "pending", "contractor_pm": "pending", "tech_lead": "pending", "safety_lead": "pending"},
        "amount_lower_raw": "",
        "amount_upper_raw": "",
        "amount_unit": "元",
        "contractor_pm": "",
        "tech_lead": "",
        "safety_lead": "",
    }
    subs = []
    for contract in manifest["contracts"]:
        if contract["kind"] != "sub":
            continue
        subs.append(
            {
                "contract_id": contract["id"],
                "name": contract["name"],
                "read_progress": {"total_pages": contract["total_pages"], "batches_processed": 0, "complete": False},
                "field_status": {"amount": "pending", "party_a": "pending", "party_b": "pending"},
                "amount_lower_raw": "",
                "amount_upper_raw": "",
                "amount_unit": "元",
                "party_a_candidates": [],
                "party_b_candidates": [],
            }
        )
    return {"main": main, "subs": subs}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="一次性切分全部合同并生成 Agent 阅读清单")
    parser.add_argument("--main", required=True, help="总包 _middle.json 或 Markdown")
    parser.add_argument("--sub", action="append", default=[], help="分包 _middle.json 或 Markdown；每份重复一次")
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--batch-pages", type=int, default=8)
    return parser.parse_args()


def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
    args = parse_args()
    if not args.sub:
        logger.error("至少需要一个 --sub")
        return 1
    if args.batch_pages < 1:
        logger.error("--batch-pages 必须大于 0")
        return 1
    output_dir = Path(args.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    try:
        contracts = [prepare_one(Path(args.main).expanduser(), "main", 0, output_dir, args.batch_pages)]
        contracts.extend(
            prepare_one(Path(path).expanduser(), "sub", index, output_dir, args.batch_pages)
            for index, path in enumerate(args.sub, 1)
        )
        manifest = {"batch_pages": args.batch_pages, "contracts": contracts}
        manifest_path = output_dir / "batch_manifest.json"
        extract_path = output_dir / "contract_extract.json"
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        extract_path.write_text(json.dumps(initial_extract(manifest), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps({"manifest": manifest_path.as_posix(), "extract": extract_path.as_posix()}, ensure_ascii=False))
        return 0
    except Exception:
        logger.exception("合同批次准备失败")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
