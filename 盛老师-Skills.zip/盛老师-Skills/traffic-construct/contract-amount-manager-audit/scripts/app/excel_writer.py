"""按照 ``合同金额审查.xlsx`` 的样式输出 Excel。

布局（以总包 + N 份分包为例）：

::

    A          B               C(总包)        D..D+N-1(分包)         倒2     倒1
    1:  项目: …                总包（元）     分包1（元）  分包2（元）…  对比结果(合并 2 列)
    2:                          合同文件名     分包文件名1   分包文件名2 … 对比结果   比例
    3:           总金额（含税） 348317829      36957574     10167154    分包之和<总包  13.53%
    4:           主要负责人      承包人项目经理…  甲方代表…    甲方代表…
    5:           （合并 B4:B6）   承包人技术…    乙方代表…    乙方代表…
    6:                           承包人安全…
"""
from __future__ import annotations

import io
from typing import TYPE_CHECKING

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

if TYPE_CHECKING:  # 避免循环引用
    from .schemas import ReviewReport


_THIN = Side(style="thin", color="000000")
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)
_HEADER_FILL = PatternFill(
    start_color="FFD9E1F2", end_color="FFD9E1F2", fill_type="solid"
)
_FONT_BOLD = Font(name="微软雅黑", size=11, bold=True)
_FONT_REG = Font(name="微软雅黑", size=11)
_ALIGN_CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
_ALIGN_LEFT = Alignment(horizontal="left", vertical="center", wrap_text=True)


def _sanitize_sheet_title(name: str) -> str:
    """Excel sheet 名长度上限 31，且不能包含 ``[]:*?/\\``。"""
    bad = set('[]:*?/\\')
    cleaned = "".join("_" if c in bad else c for c in name)
    return (cleaned or "审查结果")[:31]


def build_workbook(report: "ReviewReport") -> bytes:
    """渲染单项目的工作簿，返回 xlsx 二进制。"""
    wb = Workbook()
    ws = wb.active
    ws.title = _sanitize_sheet_title(report.project_name)

    n_sub = len(report.sub_contracts)
    # 列规划
    col_label = 2        # B: 行标签
    col_main = 3         # C: 总包
    col_sub_start = 4    # D 起
    col_cmp = col_sub_start + n_sub        # 倒数第二列：对比结果
    col_pct = col_cmp + 1                  # 最后一列：比例
    last_col = col_pct

    # ===== Row 1 =====
    ws.cell(1, 1, f"项目: {report.project_name}").font = _FONT_BOLD
    ws.cell(1, col_main, "总包（元）").font = _FONT_BOLD
    for i in range(n_sub):
        ws.cell(1, col_sub_start + i, f"分包{i + 1}（元）").font = _FONT_BOLD
    cmp_header = ws.cell(1, col_cmp, "对比结果")
    cmp_header.font = _FONT_BOLD
    cmp_header.alignment = _ALIGN_CENTER
    ws.merge_cells(start_row=1, start_column=col_cmp, end_row=1, end_column=col_pct)

    # ===== Row 2 文件名 =====
    ws.cell(2, col_main, report.main_contract.file_label).font = _FONT_BOLD
    for i, sub in enumerate(report.sub_contracts):
        ws.cell(2, col_sub_start + i, sub.file_label).font = _FONT_BOLD
    ws.cell(2, col_cmp, "对比结果").font = _FONT_BOLD
    ws.cell(2, col_pct, "比例").font = _FONT_BOLD

    # ===== Row 3 金额 =====
    label_amount = ws.cell(3, col_label, "总金额（含税）")
    label_amount.font = _FONT_REG
    label_amount.alignment = _ALIGN_CENTER

    ws.cell(3, col_main, _round_amount(report.main_contract.amount)).font = _FONT_REG
    for i, sub in enumerate(report.sub_contracts):
        ws.cell(3, col_sub_start + i, _round_amount(sub.amount)).font = _FONT_REG

    cmp_cell = ws.cell(3, col_cmp, report.comparison_text)
    cmp_cell.font = _FONT_REG
    cmp_cell.alignment = _ALIGN_CENTER
    cmp_cell.fill = _HEADER_FILL

    pct_cell = ws.cell(3, col_pct, report.ratio_text)
    pct_cell.font = _FONT_REG
    pct_cell.alignment = _ALIGN_CENTER
    pct_cell.fill = _HEADER_FILL

    # ===== Rows 4-6 负责人 =====
    label_resp = ws.cell(4, col_label, "主要负责人")
    label_resp.font = _FONT_REG
    label_resp.alignment = _ALIGN_CENTER
    ws.merge_cells(
        start_row=4, start_column=col_label, end_row=6, end_column=col_label
    )

    main = report.main_contract
    ws.cell(4, col_main, f"承包人项目经理：{main.contractor_pm}").font = _FONT_REG
    ws.cell(5, col_main, f"承包人技术负责人：{main.tech_lead}").font = _FONT_REG
    ws.cell(6, col_main, f"承包人安全负责人：{main.safety_lead}").font = _FONT_REG

    for i, sub in enumerate(report.sub_contracts):
        a_label = sub.party_a_label or "甲方代表"
        b_label = sub.party_b_label or "乙方代表"
        ws.cell(4, col_sub_start + i, f"{a_label}：{sub.party_a_name}").font = _FONT_REG
        ws.cell(5, col_sub_start + i, f"{b_label}：{sub.party_b_name}").font = _FONT_REG

    # 列宽
    ws.column_dimensions["A"].width = 6
    ws.column_dimensions[get_column_letter(col_label)].width = 22
    ws.column_dimensions[get_column_letter(col_main)].width = 32
    for i in range(n_sub):
        ws.column_dimensions[get_column_letter(col_sub_start + i)].width = 28
    ws.column_dimensions[get_column_letter(col_cmp)].width = 18
    ws.column_dimensions[get_column_letter(col_pct)].width = 12

    # 行高
    ws.row_dimensions[1].height = 22
    ws.row_dimensions[2].height = 30
    for r in range(3, 7):
        ws.row_dimensions[r].height = 24

    # 边框、字体兜底、对齐
    for r in range(1, 7):
        for c in range(col_label, last_col + 1):
            cell = ws.cell(r, c)
            cell.border = _BORDER
            if cell.font is None or not cell.font.name:
                cell.font = _FONT_REG
            if cell.alignment is None or cell.alignment.horizontal is None:
                # 金额数字左对齐看着会怪，统一居中
                cell.alignment = _ALIGN_CENTER if c <= col_main + 0 or c >= col_cmp else _ALIGN_LEFT

    # A 列也包一下边框以模拟模板的整体感
    for r in range(1, 7):
        ws.cell(r, 1).border = _BORDER

    bio = io.BytesIO()
    wb.save(bio)
    return bio.getvalue()


def _round_amount(v: float) -> float:
    """金额保留 2 位小数，整数则去掉小数点尾巴让 Excel 显示更干净。"""
    rounded = round(float(v or 0), 2)
    if abs(rounded - int(rounded)) < 1e-9:
        return float(int(rounded))
    return rounded


__all__ = ["build_workbook"]
