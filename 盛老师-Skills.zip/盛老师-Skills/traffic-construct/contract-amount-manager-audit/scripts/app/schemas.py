"""审查结果的 Pydantic 数据模型。"""
from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, Field


class MainContractInfo(BaseModel):
    file_name: str = Field(..., description="原始文件名")
    file_label: str = Field(..., description="去掉 .pdf 后缀的标签，写到 Excel 表头")
    amount: float = Field(0.0, description="最终采用的金额（元，已通过大写双保险校准）")
    amount_lower: float = Field(0.0, description="模型抽到的小写数字")
    amount_upper_raw: str = Field("", description="模型抽到的中文大写原文")
    contractor_pm: str = Field("", description="承包人项目经理")
    tech_lead: str = Field("", description="承包人技术负责人")
    safety_lead: str = Field("", description="承包人安全负责人")


class SubContractInfo(BaseModel):
    file_name: str
    file_label: str
    amount: float = 0.0
    amount_lower: float = 0.0
    amount_upper_raw: str = ""
    party_a_label: str = Field(
        "", description="原文标签：'甲方代表' / '承包人项目经理' / '发包人项目经理' 等"
    )
    party_a_name: str = ""
    party_b_label: str = Field(
        "", description="原文标签：'乙方代表' / '分包人项目经理' 等"
    )
    party_b_name: str = ""


class ReviewReport(BaseModel):
    project_name: str
    main_contract: MainContractInfo
    sub_contracts: List[SubContractInfo]
    main_amount: float = Field(..., description="总包金额")
    sub_sum: float = Field(..., description="分包金额求和")
    comparison: str = Field(..., description="'<' 或 '>='")
    comparison_text: str = Field(..., description="人话版：'分包之和<总包' 或 '分包之和>=总包'")
    ratio_percent: float = Field(..., description="分包占比百分数，保留 2 位小数")
    ratio_text: str = Field(..., description="百分号格式，例如 '13.53%'")
    excel_base64: Optional[str] = Field(
        None, description="可选：xlsx 的 base64，包在 JSON 一次性返回"
    )
