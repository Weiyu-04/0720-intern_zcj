"""项目经理类人员的确定性打分 / 择优 / 早停阈值。

照搬原项目 extractor.py 的 _pm_label_rank / _merge_party_field / missing() 语义，
仅作用于分包合同 party_a / party_b 两侧。零外部依赖。
"""
from __future__ import annotations

from typing import Iterable

NEVER_PM_KEYWORDS = (
    "质量员",
    "材料员",
    "施工员",
    "资料员",
    "安全员",
    "法定代表人",
    "法人代表",
    "法定代理人",
)

PM_SLIDE_STOP_RANK = 70


def pm_label_rank(label: str) -> int:
    """标签 → 优先级分数（越大越像项目经理）。黑名单返回 0（应忽略）。"""
    if not label:
        return 10
    if any(k in label for k in NEVER_PM_KEYWORDS):
        return 0
    if any(k in label for k in ("分包人项目经理", "发包人项目经理", "承包人项目经理")):
        return 100
    if label.strip() == "项目经理" or label.endswith("项目经理"):
        return 95
    if "项目经理" in label:
        return 90
    if "项目负责人" in label:
        return 75
    if "甲方代表" in label or "乙方代表" in label:
        return 75
    if "工地代表" in label:
        return 65
    if "现场负责人" in label or "施工现场负责人" in label:
        return 55
    return 30


def _clean(v) -> str:
    if v is None:
        return ""
    return str(v).strip().strip("：:").strip()


def pick_party_side(candidates: Iterable[dict]) -> tuple[str, str, int]:
    """对一侧候选打分，过滤黑名单(rank 0)，返回最高分 (label, name, rank)。

    平分时取后出现者（与原 _merge_party_field「new_rank >= cur_rank 时覆盖」一致）。
    空/全黑名单返回 ('', '', 0)。
    """
    best_label, best_name, best_rank = "", "", -1
    for c in candidates or []:
        if not isinstance(c, dict):
            continue
        name = _clean(c.get("name"))
        if not name:
            continue
        label = _clean(c.get("label"))
        rank = pm_label_rank(label)
        if rank == 0:
            continue  # 黑名单忽略
        if rank >= best_rank:
            best_label, best_name, best_rank = label, name, rank
    if best_rank < 0:
        return "", "", 0
    return best_label, best_name, best_rank


def party_side_satisfied(label: str, name: str) -> bool:
    """该侧是否已满足早停：有姓名且 rank >= 阈值。"""
    if not name:
        return False
    return pm_label_rank(label) >= PM_SLIDE_STOP_RANK


__all__ = [
    "NEVER_PM_KEYWORDS",
    "PM_SLIDE_STOP_RANK",
    "pm_label_rank",
    "pick_party_side",
    "party_side_satisfied",
]
