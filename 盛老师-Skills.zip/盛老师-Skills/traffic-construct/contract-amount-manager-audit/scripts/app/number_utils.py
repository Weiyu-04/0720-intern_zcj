"""中文大写金额 → 数字 的转换工具。

供「金额双保险」逻辑使用：以中文大写解析结果为最终值，
仅当大写无法解析时才回退到模型给出的小写数字。
"""
from __future__ import annotations

import logging
import re
from typing import Optional

logger = logging.getLogger(__name__)


_DIGIT_MAP: dict[str, int] = {
    "零": 0, "〇": 0, "○": 0, "0": 0,
    "一": 1, "二": 2, "两": 2, "三": 3, "四": 4,
    "五": 5, "六": 6, "七": 7, "八": 8, "九": 9,
    "壹": 1, "贰": 2, "弍": 2, "叁": 3, "参": 3, "肆": 4,
    "伍": 5, "陆": 6, "陸": 6, "柒": 7, "捌": 8, "玖": 9,
    # 模型偶尔会原样保留阿拉伯数字
    "1": 1, "2": 2, "3": 3, "4": 4, "5": 5,
    "6": 6, "7": 7, "8": 8, "9": 9,
}

_UNIT_SMALL: dict[str, int] = {
    "十": 10, "拾": 10,
    "百": 100, "佰": 100,
    "千": 1000, "仟": 1000,
}

_UNIT_WAN = {"万": 10_000, "萬": 10_000}
_UNIT_YI = {"亿": 100_000_000, "億": 100_000_000}


def chinese_upper_to_number(text: str) -> Optional[float]:
    """把中文大写金额转换为 ``float``。

    返回 ``None`` 表示无法解析（调用方应回退到小写值）。
    """
    if text is None:
        return None
    s = str(text).strip()
    if not s:
        return None

    s = re.sub(r"[\s,，·.．]", "", s)
    s = s.replace("圆", "元").replace("園", "元")
    s = s.replace("正", "整")
    s = re.sub(r"^(人民币|￥|¥|RMB)", "", s, flags=re.IGNORECASE)
    s = s.rstrip("整")

    # 拆分整数 / 小数（角分）
    if "元" in s:
        idx = s.index("元")
        int_part = s[:idx]
        frac_part = s[idx + 1 :]
    else:
        int_part, frac_part = s, ""

    int_val = _parse_integer(int_part)
    if int_val is None:
        return None

    frac_val = _parse_fraction(frac_part)
    if frac_val is None:
        return None

    value = int_val + frac_val
    # 金额合理性校验：负数视为非法
    if value < 0:
        return None
    return round(value, 2)


def _parse_integer(s: str) -> Optional[int]:
    """解析整数部分，支持「亿/万」分段。"""
    if not s:
        return 0
    # 模型有时直接给阿拉伯数字
    cleaned = s.replace(",", "")
    if re.fullmatch(r"\d+", cleaned):
        try:
            return int(cleaned)
        except ValueError:
            return None

    # 处理亿
    for ch, unit in _UNIT_YI.items():
        if ch in s:
            left, right = s.split(ch, 1)
            l_val = _parse_under_yi(left)
            r_val = _parse_under_yi(right) if right else 0
            if l_val is None or r_val is None:
                return None
            return l_val * unit + r_val

    return _parse_under_yi(s)


def _parse_under_yi(s: str) -> Optional[int]:
    if not s:
        return 0
    for ch, unit in _UNIT_WAN.items():
        if ch in s:
            left, right = s.split(ch, 1)
            l_val = _parse_under_wan(left)
            r_val = _parse_under_wan(right) if right else 0
            if l_val is None or r_val is None:
                return None
            return l_val * unit + r_val
    return _parse_under_wan(s)


def _parse_under_wan(s: str) -> Optional[int]:
    """解析 [0, 10000) 区间的中文数字。"""
    if not s:
        return 0
    if re.fullmatch(r"\d+", s):
        try:
            return int(s)
        except ValueError:
            return None

    total = 0
    current = 0
    seen_any = False

    for ch in s:
        if ch in _DIGIT_MAP:
            current = _DIGIT_MAP[ch]
            seen_any = True
            continue
        if ch in _UNIT_SMALL:
            unit = _UNIT_SMALL[ch]
            if not seen_any:
                current = 1
            total += current * unit
            current = 0
            seen_any = True
            continue
        # 出现未识别字符则视为非法
        return None

    total += current
    return total


def _parse_fraction(s: str) -> Optional[float]:
    """解析 ``X角Y分`` 这样的尾巴；找不到也返回 0。"""
    if not s:
        return 0.0
    s = s.replace("整", "").replace("正", "")
    if not s:
        return 0.0

    frac = 0.0
    # 角
    m = re.search(r"(.)角", s)
    if m:
        d = _DIGIT_MAP.get(m.group(1))
        if d is None:
            return None
        frac += d * 0.1
    # 分
    m = re.search(r"(.)分", s)
    if m:
        d = _DIGIT_MAP.get(m.group(1))
        if d is None:
            return None
        frac += d * 0.01
    return frac


def normalize_amount_to_yuan(value, *, unit_hint: str = "") -> Optional[float]:
    """将模型返回的小写金额统一换算为「元」。

    支持：
    - 纯数字（默认视为元）
    - 字符串内嵌单位，如 ``1910.7185万元``、``1,234.56元``
    - ``unit_hint`` 为 ``万元`` / ``亿元`` 时按倍数换算
    """
    if value is None:
        return None

    s = str(value).replace(",", "").replace(" ", "").strip()
    if not s:
        return None

    # 字符串内已带单位
    if re.search(r"万元|万圆|萬元", s):
        num = re.sub(r"[^\d.]", "", s)
        if not num:
            return None
        return round(float(num) * 10_000, 2)
    if re.search(r"亿元|亿圆|億元", s):
        num = re.sub(r"[^\d.]", "", s)
        if not num:
            return None
        return round(float(num) * 100_000_000, 2)
    if re.search(r"元", s) and not re.search(r"万|亿", s):
        num = re.sub(r"[^\d.]", "", s)
        if not num:
            return None
        return round(float(num), 2)

    # 纯数字 + unit_hint
    try:
        num = float(s)
    except ValueError:
        return None

    hint = (unit_hint or "元").replace("人民币", "").strip()
    if "亿" in hint:
        # 如 5.2 亿元 → 5.2e8；若已是 5.2e8 量级则不再乘
        if abs(num) < 10_000:
            return round(num * 100_000_000, 2)
        return round(num, 2)
    if "万" in hint:
        # 如 1910.7185 万元；若数字已达「元」量级（≥10万），说明模型已换算，勿重复乘
        if abs(num) < 100_000:
            return round(num * 10_000, 2)
        return round(num, 2)
    return round(num, 2)


def clean_str(value) -> str:
    """清洗大脑抽出的字符串字段：去首尾空白与残留的冒号。"""
    if value is None:
        return ""
    return str(value).strip().strip("：:").strip()


def resolve_amount(amount_lower, amount_upper, *, unit_hint: str = "") -> tuple[float, float, str]:
    """金额双保险裁决：大写优先 / 小写兜底。

    返回 ``(amount, amount_lower_yuan, amount_upper_raw)``：
    - 中文大写可解析且 > 0 时以大写为最终值；
    - 否则回退到小写换算值；
    - 两者都没有则返回 ``(0.0, 0.0, upper_raw)``。
    """
    upper_raw = str(amount_upper or "").strip()
    lower = normalize_amount_to_yuan(amount_lower, unit_hint=unit_hint) or 0.0
    upper_num = chinese_upper_to_number(upper_raw)

    if upper_num is not None and upper_num > 0:
        if lower > 0:
            diff = abs(lower - upper_num) / upper_num
            if diff > 0.01:
                logger.warning(
                    "金额大小写不一致: lower=%.2f upper=%.2f raw_upper=%r（以大写为准）",
                    lower,
                    upper_num,
                    upper_raw,
                )
        return upper_num, lower, upper_raw
    if lower > 0:
        return lower, lower, upper_raw
    return 0.0, 0.0, upper_raw


__all__ = [
    "chinese_upper_to_number",
    "normalize_amount_to_yuan",
    "resolve_amount",
    "clean_str",
]
