"""Advance one contract extraction lane by merging one Agent batch result."""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any


SCRIPTS_DIR = Path(__file__).resolve().parent
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

from app.number_utils import clean_str, resolve_amount  # noqa: E402
from app.pm_scoring import party_side_satisfied, pick_party_side, pm_label_rank  # noqa: E402


def _load_object(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(path)
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} 顶层必须是 JSON 对象")
    return value


def _save_atomic(path: Path, value: dict[str, Any]) -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temp, path)


def _manifest_contract(manifest: dict[str, Any], contract_id: str) -> dict[str, Any]:
    contracts = manifest.get("contracts")
    if not isinstance(contracts, list):
        raise ValueError("manifest.contracts 必须是数组")
    matches = [item for item in contracts if isinstance(item, dict) and item.get("id") == contract_id]
    if len(matches) != 1:
        raise ValueError(f"manifest 中 contract_id={contract_id!r} 必须恰好出现一次")
    return matches[0]


def _extract_contract(extract: dict[str, Any], contract_id: str, kind: str) -> dict[str, Any]:
    if kind == "main":
        item = extract.get("main")
        if isinstance(item, dict) and item.get("contract_id") == contract_id:
            return item
    else:
        subs = extract.get("subs")
        if isinstance(subs, list):
            matches = [item for item in subs if isinstance(item, dict) and item.get("contract_id") == contract_id]
            if len(matches) == 1:
                return matches[0]
    raise ValueError(f"累计 JSON 中未找到 contract_id={contract_id!r}")


def _amount_ok(item: dict[str, Any]) -> bool:
    amount, _, _ = resolve_amount(
        item.get("amount_lower_raw"),
        item.get("amount_upper_raw"),
        unit_hint=str(item.get("amount_unit") or ""),
    )
    return amount > 0


def _merge_amount(target: dict[str, Any], result: dict[str, Any]) -> None:
    if _amount_ok(target):
        return
    for key in ("amount_lower_raw", "amount_upper_raw", "amount_unit"):
        value = clean_str(result.get(key))
        if value:
            target[key] = value


def _merge_main(target: dict[str, Any], result: dict[str, Any]) -> None:
    _merge_amount(target, result)
    for key in ("contractor_pm", "tech_lead", "safety_lead"):
        if not clean_str(target.get(key)):
            target[key] = clean_str(result.get(key))


def _incoming_candidates(result: dict[str, Any], side: str) -> list[dict[str, str]]:
    key = f"party_{side}_candidates"
    raw = result.get(key)
    if isinstance(raw, list):
        candidates = raw
    else:
        name = clean_str(result.get(f"party_{side}_name"))
        label = clean_str(result.get(f"party_{side}_label"))
        candidates = [{"label": label, "name": name}] if name else []
    output = []
    for item in candidates:
        if not isinstance(item, dict):
            continue
        name = clean_str(item.get("name"))
        label = clean_str(item.get("label"))
        if name and pm_label_rank(label) > 0:
            output.append({"label": label, "name": name})
    return output


def _merge_sub(target: dict[str, Any], result: dict[str, Any]) -> None:
    _merge_amount(target, result)
    for side in ("a", "b"):
        key = f"party_{side}_candidates"
        current = target.setdefault(key, [])
        if not isinstance(current, list):
            current = target[key] = []
        seen = {
            (clean_str(item.get("label")), clean_str(item.get("name")))
            for item in current
            if isinstance(item, dict)
        }
        for item in _incoming_candidates(result, side):
            pair = (item["label"], item["name"])
            if pair not in seen:
                current.append(item)
                seen.add(pair)


def _main_missing(item: dict[str, Any]) -> list[str]:
    missing = [] if _amount_ok(item) else ["amount"]
    missing.extend(key for key in ("contractor_pm", "tech_lead", "safety_lead") if not clean_str(item.get(key)))
    return missing


def _sub_side(item: dict[str, Any], side: str) -> tuple[str, str, int]:
    candidates = item.get(f"party_{side}_candidates")
    return pick_party_side(candidates if isinstance(candidates, list) else [])


def _sub_missing(item: dict[str, Any]) -> list[str]:
    missing = [] if _amount_ok(item) else ["amount"]
    for side in ("a", "b"):
        label, name, _ = _sub_side(item, side)
        if not party_side_satisfied(label, name):
            missing.append(f"party_{side}")
    return missing


def _set_found_status(item: dict[str, Any], kind: str) -> None:
    status = item.setdefault("field_status", {})
    status["amount"] = "found" if _amount_ok(item) else "pending"
    if kind == "main":
        for key in ("contractor_pm", "tech_lead", "safety_lead"):
            status[key] = "found" if clean_str(item.get(key)) else "pending"
    else:
        for side in ("a", "b"):
            label, name, _ = _sub_side(item, side)
            status[f"party_{side}"] = "found" if party_side_satisfied(label, name) else "pending"


def _finalize_missing(item: dict[str, Any], kind: str, missing: list[str]) -> None:
    status = item.setdefault("field_status", {})
    for key in missing:
        if kind == "sub" and key in {"party_a", "party_b"}:
            side = key[-1]
            _, name, rank = _sub_side(item, side)
            status[key] = "below_threshold" if name and rank > 0 else "not_stated"
        else:
            status[key] = "not_stated"


def _next_response(contract: dict[str, Any], item: dict[str, Any]) -> dict[str, Any]:
    progress = item.get("read_progress")
    if not isinstance(progress, dict):
        raise ValueError("read_progress 必须是对象")
    if progress.get("complete"):
        return {
            "action": "stop",
            "contract_id": contract["id"],
            "reason": progress.get("stop_reason") or "complete",
        }
    index = int(progress.get("batches_processed") or 0)
    batches = contract.get("batches")
    if not isinstance(batches, list) or index >= len(batches):
        raise ValueError("批次进度超出 manifest 范围")
    batch = batches[index]
    return {
        "action": "read",
        "contract_id": contract["id"],
        "kind": contract["kind"],
        "batch_index": index,
        "batch_path": batch["path"],
    }


def next_action(manifest: dict[str, Any], extract: dict[str, Any], contract_id: str) -> dict[str, Any]:
    contract = _manifest_contract(manifest, contract_id)
    item = _extract_contract(extract, contract_id, contract["kind"])
    return _next_response(contract, item)


def submit_result(
    manifest: dict[str, Any],
    extract: dict[str, Any],
    contract_id: str,
    result: dict[str, Any],
) -> dict[str, Any]:
    contract = _manifest_contract(manifest, contract_id)
    kind = contract.get("kind")
    item = _extract_contract(extract, contract_id, kind)
    progress = item.get("read_progress")
    if not isinstance(progress, dict) or progress.get("complete"):
        raise ValueError("该合同已完成或 read_progress 非法")
    processed = int(progress.get("batches_processed") or 0)
    batches = contract.get("batches")
    if not isinstance(batches, list) or processed >= len(batches):
        raise ValueError("没有可提交的当前批次")

    if kind == "main":
        _merge_main(item, result)
        missing = _main_missing(item)
    else:
        _merge_sub(item, result)
        missing = _sub_missing(item)
    progress["batches_processed"] = processed + 1
    _set_found_status(item, kind)

    if not missing:
        progress["complete"] = True
        progress["stop_reason"] = "all_required_found"
    elif progress["batches_processed"] >= len(batches):
        progress["complete"] = True
        progress["stop_reason"] = "end_of_document"
        _finalize_missing(item, kind, missing)

    response = _next_response(contract, item)
    response["missing"] = missing
    return response


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="合并一个批次结果并返回下一步动作")
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--extract", required=True)
    parser.add_argument("--contract-id", required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--next", action="store_true")
    mode.add_argument("--submit", metavar="BATCH_RESULT_JSON")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    manifest_path = Path(args.manifest).expanduser()
    extract_path = Path(args.extract).expanduser()
    try:
        manifest = _load_object(manifest_path)
        extract = _load_object(extract_path)
        if args.next:
            response = next_action(manifest, extract, args.contract_id)
        else:
            result = _load_object(Path(args.submit).expanduser())
            response = submit_result(manifest, extract, args.contract_id, result)
            _save_atomic(extract_path, extract)
        print(json.dumps(response, ensure_ascii=False))
        return 0
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"advance_extract failed: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
