"""Generate an Excel workbook from review_state.json."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter


HEADERS = [
    "总包/分包",
    "合同文件",
    "合同条款位置",
    "合同相关摘录",
    "不符合或风险说明",
    "依据文件",
    "依据条款及原文摘录",
    "风险等级",
]


def _load_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def _safe_filename(text: str, max_len: int = 80) -> str:
    bad = '<>:"/\\|?*'
    for ch in bad:
        text = text.replace(ch, "_")
    text = text.strip() or "合同合规审查结果"
    return text[:max_len]


def _apply_style(ws) -> Alignment:
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill("solid", fgColor="305496")
    for idx, header in enumerate(HEADERS, 1):
        cell = ws.cell(row=1, column=idx, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center", vertical="center")
    widths = [10, 36, 30, 60, 80, 32, 60, 10]
    for idx, width in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(idx)].width = width
    ws.row_dimensions[1].height = 22
    return Alignment(wrap_text=True, vertical="top", horizontal="left")


def _rows(state: dict[str, Any]) -> list[list[Any]]:
    rows: list[list[Any]] = []
    for contract in state.get("contracts") or []:
        validation = contract.get("validation") or {}
        for finding in validation.get("findings") or []:
            rows.append(
                [
                    finding.get("contract_type") or contract.get("contract_type") or "",
                    finding.get("contract_file") or contract.get("contract_file") or "",
                    finding.get("clause_locator") or "",
                    finding.get("original_quote") or "",
                    finding.get("risk_explanation") or "",
                    finding.get("reference_document") or "",
                    finding.get("reference_clause") or "",
                    finding.get("severity") or "medium",
                ]
            )
    return rows


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Write contract compliance findings to Excel.")
    parser.add_argument("--state", required=True)
    parser.add_argument("--output", default=None, help="完整输出文件路径，覆盖默认命名（失去时间戳，慎用）")
    parser.add_argument("--output-dir", default=None, help="输出目录；文件名按 合同合规审查结果_{时间戳}.xlsx 自动生成")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    state = _load_json(args.state)
    fname = "合同合规审查结果_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".xlsx"
    if args.output:
        out_path = Path(args.output)
    else:
        directory = Path(args.output_dir) if args.output_dir else Path(state.get("output_dir") or ".")
        out_path = directory / fname
    out_path.parent.mkdir(parents=True, exist_ok=True)

    wb = Workbook()
    ws = wb.active
    ws.title = "合同合规审查结果"
    wrap = _apply_style(ws)
    rows = _rows(state)
    for row_idx, row in enumerate(rows, 2):
        for col_idx, value in enumerate(row, 1):
            cell = ws.cell(row=row_idx, column=col_idx, value=value)
            cell.alignment = wrap
    wb.save(out_path)

    summary: dict[str, Any] = {
        "excel": str(out_path.resolve()),
        "contracts": len(state.get("contracts") or []),
        "findings": len(rows),
        "severity": {"high": 0, "medium": 0, "low": 0},
    }
    for row in rows:
        sev = str(row[-1] or "medium").lower()
        if sev in summary["severity"]:
            summary["severity"][sev] += 1
    print(json.dumps(summary, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
