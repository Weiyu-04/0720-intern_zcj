"""Structured negative-list rules used as deterministic reference material.

The Agent performs the final judgment. These rules are bundled so validation
tasks can cite a stable rule id, threshold, exclusion list, and original quote.
"""

from __future__ import annotations

SOURCE_DOCUMENT = "文件一《公路工程施工分包负面清单（2024年版）》"

# 逐字对齐原项目 app/modules/rule_engine.py。
# 原项目 RulePrerequisite 拆成 bridge_type / structure_position / construction_method 三段；
# 本 skill 把它们压平进一个 dict，字段映射（与 advance_review._prefilter_rules_for_clause 配合）：
#   positions == 原项目 prerequisite.structure_position
#   methods   == 原项目 prerequisite.bridge_type + prerequisite.construction_method（顺序、成员完全一致）
# 因此每个 rules[*].prerequisite.methods 都是 bridge_type 与 construction_method 的并集，缺省段为空列表。
# keywords / thresholds / exclusions / quote 与原项目逐字一致。
RULES: list[dict] = [
    {
        "rule_id": "BRIDGE-1-1",
        "category": "桥梁工程",
        "title": "高度≥20米的水中沉井基础",
        "quote": "一、桥梁工程（一）高度≥20米的水中沉井基础。",
        "prerequisite": {"domain": "桥梁工程", "positions": ["基础工程", "下部结构"], "methods": ["水中沉井", "沉井基础"]},
        "thresholds": {"height_m_ge": 20, "scene": "水中"},
        "keywords": ["水中沉井", "沉井基础", "沉井"],
        "exclusions": [],
    },
    {
        "rule_id": "BRIDGE-1-2",
        "category": "桥梁工程",
        "title": "水深≥10米的围堰工程",
        "quote": "一、桥梁工程（二）水深≥10米的围堰工程（钢结构制作和运输除外）。",
        "prerequisite": {"domain": "桥梁工程", "positions": ["基础工程", "下部结构"], "methods": ["围堰"]},
        "thresholds": {"water_depth_m_ge": 10},
        "keywords": ["围堰"],
        "exclusions": ["钢结构制作", "运输"],
    },
    {
        "rule_id": "BRIDGE-1-3-1",
        "category": "桥梁工程",
        "title": "高度≥20米落地式支撑架施工的现浇梁",
        "quote": "一、桥梁工程（三）1.高度≥20米落地式支撑架施工的现浇梁；",
        "prerequisite": {"domain": "桥梁工程", "positions": ["上部承重结构"], "methods": ["梁式桥", "落地式支撑架", "现浇梁"]},
        "thresholds": {"support_height_m_ge": 20, "type": "落地式"},
        "keywords": ["落地式支撑架", "现浇梁", "支撑架"],
        "exclusions": [],
    },
    {
        "rule_id": "BRIDGE-1-3-2",
        "category": "桥梁工程",
        "title": "附着式支撑架施工的现浇梁",
        "quote": "一、桥梁工程（三）2.附着式支撑架施工的现浇梁；",
        "prerequisite": {"domain": "桥梁工程", "positions": ["上部承重结构"], "methods": ["梁式桥", "附着式支撑架", "现浇梁"]},
        "thresholds": {"type": "附着式"},
        "keywords": ["附着式支撑架", "现浇梁"],
        "exclusions": [],
    },
    {
        "rule_id": "BRIDGE-1-3-3",
        "category": "桥梁工程",
        "title": "节段重量≥200吨或长度≥4.5米悬臂施工的现浇梁",
        "quote": "一、桥梁工程（三）3.节段重量≥200吨或长度≥4.5米悬臂施工的现浇梁；",
        "prerequisite": {"domain": "桥梁工程", "positions": ["上部承重结构"], "methods": ["梁式桥", "悬臂施工", "悬臂浇筑", "现浇梁"]},
        "thresholds": {"segment_weight_t_ge": 200, "segment_length_m_ge": 4.5},
        "keywords": ["悬臂施工", "悬臂浇筑", "现浇梁"],
        "exclusions": [],
    },
    {
        "rule_id": "BRIDGE-1-3-4",
        "category": "桥梁工程",
        "title": "跨度≥55米移动模架施工的现浇梁",
        "quote": "一、桥梁工程（三）4.跨度≥55米移动模架施工的现浇梁；",
        "prerequisite": {"domain": "桥梁工程", "positions": ["上部承重结构"], "methods": ["梁式桥", "移动模架", "现浇梁"]},
        "thresholds": {"span_m_ge": 55},
        "keywords": ["移动模架", "现浇梁"],
        "exclusions": [],
    },
    {
        "rule_id": "BRIDGE-1-3-5",
        "category": "桥梁工程",
        "title": "节段重量≥200吨或长度≥4.5米悬拼工法施工的装配式节段梁",
        "quote": "一、桥梁工程（三）5.节段重量≥200吨或长度≥4.5米悬拼工法施工的装配式节段梁；",
        "prerequisite": {"domain": "桥梁工程", "positions": ["上部承重结构"], "methods": ["装配式节段梁", "悬拼", "悬拼工法"]},
        "thresholds": {"segment_weight_t_ge": 200, "segment_length_m_ge": 4.5},
        "keywords": ["悬拼", "装配式节段梁", "节段梁"],
        "exclusions": [],
    },
    {
        "rule_id": "BRIDGE-1-3-6",
        "category": "桥梁工程",
        "title": "整孔预制安装的预制梁",
        "quote": "一、桥梁工程（三）6.整孔预制安装的预制梁（外购梁预制、运输除外）；",
        "prerequisite": {"domain": "桥梁工程", "positions": ["上部承重结构"], "methods": ["预制梁", "整孔预制", "整孔预制安装"]},
        "thresholds": {},
        "keywords": ["整孔预制", "预制梁", "预制安装"],
        "exclusions": ["外购梁预制", "运输"],
    },
    {
        "rule_id": "BRIDGE-1-3-7",
        "category": "桥梁工程",
        "title": "单体自重≥200吨的装配式梁",
        "quote": "一、桥梁工程（三）7.单体自重≥200吨的装配式梁；",
        "prerequisite": {"domain": "桥梁工程", "positions": ["上部承重结构"], "methods": ["装配式梁", "装配式梁安装"]},
        "thresholds": {"unit_weight_t_ge": 200},
        "keywords": ["装配式梁", "单体自重"],
        "exclusions": [],
    },
    {
        "rule_id": "BRIDGE-1-3-8",
        "category": "桥梁工程",
        "title": "顶推系统支撑跨度≥55米施工的上部承重结构",
        "quote": "一、桥梁工程（三）8.顶推系统支撑跨度≥55米施工的上部承重结构；",
        "prerequisite": {"domain": "桥梁工程", "positions": ["上部承重结构"], "methods": ["顶推", "顶推系统"]},
        "thresholds": {"support_span_m_ge": 55},
        "keywords": ["顶推", "顶推系统", "上部承重结构"],
        "exclusions": ["钢结构制作", "运输"],
    },
    {
        "rule_id": "BRIDGE-1-3-9",
        "category": "桥梁工程",
        "title": "上跨既有一级及以上公路、主干路及以上城市道路、铁路的上部承重结构",
        "quote": "一、桥梁工程（三）9.上跨既有一级及以上公路、主干路及以上城市道路、铁路的上部承重结构。",
        "prerequisite": {"domain": "桥梁工程", "positions": ["上部承重结构"], "methods": ["上跨既有道路", "上跨既有铁路"]},
        "thresholds": {"scene": "上跨既有道路/铁路"},
        "keywords": ["上跨", "既有公路", "既有铁路", "上跨铁路", "跨既有"],
        "exclusions": [],
    },
    {
        "rule_id": "BRIDGE-1-4",
        "category": "桥梁工程",
        "title": "大跨度悬索桥/斜拉桥/拱桥的上部承重结构",
        "quote": "一、桥梁工程（四）单孔跨径≥1000米悬索桥、单孔跨径≥600米斜拉桥、单孔跨径≥400米拱桥的上部承重结构（钢结构制作和运输除外）。",
        "prerequisite": {"domain": "桥梁工程", "positions": ["上部承重结构"], "methods": ["悬索桥", "斜拉桥", "拱桥"]},
        "thresholds": {"suspension_span_m_ge": 1000, "cable_stayed_span_m_ge": 600, "arch_span_m_ge": 400},
        "keywords": ["悬索桥", "斜拉桥", "拱桥", "上部承重结构", "主缆", "吊索", "索鞍"],
        "exclusions": ["钢结构制作", "运输"],
    },
    {
        "rule_id": "TUNNEL-2-1",
        "category": "隧道工程",
        "title": "沉管工法施工的水中隧道的预制安装",
        "quote": "二、隧道工程（一）沉管工法施工的水中隧道的预制安装（基槽开挖、回填、浮运除外）。",
        "prerequisite": {"domain": "隧道工程", "positions": ["隧道主体"], "methods": ["沉管", "沉管工法"]},
        "thresholds": {},
        "keywords": ["沉管", "水中隧道"],
        "exclusions": ["基槽开挖", "回填", "浮运"],
    },
    {
        "rule_id": "TUNNEL-2-2",
        "category": "隧道工程",
        "title": "盾构法、TBM工法施工的隧道",
        "quote": "二、隧道工程（二）盾构法、TBM工法施工的隧道（管片预制、运输除外）。",
        "prerequisite": {"domain": "隧道工程", "positions": ["隧道主体"], "methods": ["盾构", "盾构法", "TBM", "TBM工法"]},
        "thresholds": {},
        "keywords": ["盾构", "TBM"],
        "exclusions": ["管片预制", "运输"],
    },
    {
        "rule_id": "TUNNEL-2-3",
        "category": "隧道工程",
        "title": "高瓦斯隧道",
        "quote": "二、隧道工程（三）高瓦斯隧道（瓦斯抽排、爆破、二衬、出碴运输除外）。",
        "prerequisite": {"domain": "隧道工程", "positions": ["隧道主体"], "methods": []},
        "thresholds": {"scene": "高瓦斯"},
        "keywords": ["高瓦斯", "瓦斯隧道"],
        "exclusions": ["瓦斯抽排", "爆破", "二衬", "出碴运输"],
    },
    {
        "rule_id": "TUNNEL-2-4",
        "category": "隧道工程",
        "title": "长度>3km且并存特定不良地质的隧道",
        "quote": "二、隧道工程（四）长度超过3千米，且与下列情形之一并存的隧道：1.深埋富水；2.岩溶强发育地段；3.V级及以上围岩且开挖断面≥150平方米。",
        "prerequisite": {"domain": "隧道工程", "positions": ["隧道主体"], "methods": []},
        "thresholds": {"length_km_gt": 3, "section_m2_ge": 150},
        "keywords": ["深埋富水", "岩溶", "V级围岩", "开挖断面"],
        "exclusions": ["爆破", "二衬", "出碴运输"],
    },
    {
        "rule_id": "TUNNEL-2-5",
        "category": "隧道工程",
        "title": "非无轨运输出碴隧道斜井/大直径深竖井",
        "quote": "二、隧道工程（五）非无轨运输出碴隧道斜井，直径≥5米且深度≥300米的隧道竖井（爆破除外）。",
        "prerequisite": {"domain": "隧道工程", "positions": ["隧道斜井", "隧道竖井"], "methods": []},
        "thresholds": {"shaft_diameter_m_ge": 5, "shaft_depth_m_ge": 300},
        "keywords": ["斜井", "竖井"],
        "exclusions": ["爆破"],
    },
    {
        "rule_id": "TUNNEL-2-6",
        "category": "隧道工程",
        "title": "下穿既有道路/铁路/江河湖海且长度≥50米的隧道工程",
        "quote": "二、隧道工程（六）下穿既有一级及以上公路、主干路及以上城市道路、铁路、江河湖海，且长度≥50米的隧道工程（爆破、二衬、出碴运输除外）。",
        "prerequisite": {"domain": "隧道工程", "positions": ["隧道主体"], "methods": ["下穿"]},
        "thresholds": {"length_m_ge": 50},
        "keywords": ["下穿", "穿越江河", "穿越铁路", "穿越公路"],
        "exclusions": ["爆破", "二衬", "出碴运输"],
    },
]


def get_rulebook() -> dict:
    return {"source_document": SOURCE_DOCUMENT, "rules": RULES}
