"""合同事实合成器（Reduce）—— 逐字移植自原项目 app/modules/contract_synthesizer.py。

定位：在 VL 逐页碎片与合规裁判之间，由 Agent（文字模型）把同一份合同的条款碎片
分组合并 + 摘录去重，输出强绑定 evidence 的「单体施工事实台账」。

本模块只提供 prompt 与**确定性后处理**（分组合并/编号/locator 选取/子串去重），
LLM 调用由 Agent 完成：
  - ``build_user_text(fragments, contract_file)`` → 交给 Agent 的 user 文本；
  - ``build_ledger(fragments, raw)`` → 解析 Agent 返回的 groups JSON，落成台账行。
"""

from __future__ import annotations

import json
import re
from typing import Any, Dict, List, Set, Tuple

SYSTEM_PROMPT = """你是一个专业的工程合同信息整理员。我将提供从同一份合同不同页码由视觉模型提取出的条款碎片（JSON 数组，每条都有唯一 _idx、page_index、clause_locator、scope_text、domain_classification、structural_position 等字段）。

上游已完成页面初筛与条款提取，输入中通常不再含纯商务/纯采购页。你的任务【只做分组合并与摘录去重，不改写原文，不做合规判断，不重复剔除材料采购条款】：

1. 把语义指向同一施工作业面、同一专业分包对象、同一工法/结构物的碎片归入同一 group（跨页拼接）。
   - 典型必须同组：工程概况中的分包范围 + 工程量清单中的同名作业 + 附件/说明里的工程名称或承包范围标题（即使一条很笼统、一条很具体，只要说的是同一对象，例如均含「顶推」「钢箱梁」「PHC管桩」等，必须同组，禁止拆成两组）。
   - 禁止仅因「一条是工程名称概括、一条是施工内容详述」就拆组。
2. 仅当碎片描述的是完全不同的工程对象或工法时，才各自单独成 group。

【按摘录分组与精准去重原则（CRITICAL）】
3. 在合并同一类施工作业时，绝对禁止机械累加重复的摘录文本。
4. 必须以"原文摘录"为基准进行合并去重（Group By Quote）：
   - 同一 group 内若多个 _idx 的 scope_text 完全相同或高度重合（仅排版/空格/标点差异），视为同一段摘录；
   - 在该 group 的 evidence 数组中【只保留一段最完整的唯一 quote】，
     将这些 _idx 对应的 clause_locator 全部塞入同一个 evidence 项的 source_indices 中。
   - 系统在写入 Excel 时，会自动从这些 _idx 里【挑物理页码最小】的那一条 clause_locator 作为最终展示，不需要你罗列全部出处。
5. 最终 evidence 列表必须实现"以 quote 为唯一键"的合并 —— 一段独立摘录 = 一个 evidence 条目；
   若较短 quote 已被较长 quote 包含（如多处重复的「××工程钢结构顶推专业工程」与概况里的详细承包范围），
   必须并入较长 quote 的 source_indices，不得单独占一个 evidence 编号。
6. 严禁改写、概括、翻译 clause_locator / scope_text，quote 字段必须逐字取自某一 _idx 的 scope_text 原文；
   多 _idx 重合时取最完整的一段。
7. 严禁臆造合同中未出现的内容；evidence 中的所有内容必须可由 _idx 反查到原文。

8. 同时为每个 group 推断两个标签（基于工程常识），值与 VLM 已给出的字段保持一致或更精确:
   - domain_classification：桥梁工程 / 隧道工程 / 路基路面 / 其他；
   - structural_position：基础工程 / 下部结构 / 上部承重结构 / 桥面系 / 附属工程 / 隧道主体 / 隧道斜井 / 隧道竖井 / 不适用。
9. 给每个 group 一个简洁的 engineering_subject（施工实体主体名称，例如『嘉松公路越江新建工程主桥钢结构加工制作及运输』）。
10. 输出必须是【严格 JSON】，禁止 Markdown 围栏，禁止注释，禁止多余文字。
11. 对于【仅描述费用结算规则、不含任何施工工法或施工范围说明】的条款（典型特征：以"本报价为综合单价包干""工程量按设计施工图结算""单价包含以下费用""本报价包含"等开头，内容仅为计费/计量说明而无施工工序描述），将其放入 discarded_indices，不参与合规审查。
12. 当同一 PDF 内存在多份相互独立的子合同（各有自己的合同封面标题、独立项目名称或分包方名称），禁止仅因共有"钢结构""钢箱梁""钻孔桩"等泛化关键词而将它们强制合并为同一 group——各独立子合同必须各自成组。"""

OUTPUT_HINT = """输出 JSON 结构：
{
  "groups": [
    {
      "engineering_subject": "施工实体主体名称（简短、可读）",
      "domain_classification": "桥梁工程 | 隧道工程 | 路基路面 | 其他",
      "structural_position": "基础工程 | 下部结构 | 上部承重结构 | 桥面系 | 附属工程 | 隧道主体 | 隧道斜井 | 隧道竖井 | 不适用",
      "evidence": [
        {
          "source_indices": [0, 5],
          "quote": "(逐字取自某一 _idx 的 scope_text 原文，多 _idx 重合时取最完整的一段，禁止改写)"
        },
        {
          "source_indices": [7],
          "quote": "..."
        }
      ],
      "is_generic": false,
      "notes": "可选：合并理由或备注（必须基于已有文字，不得引用法规）"
    }
  ],
  "discarded_indices": [3]
}
硬性约束：
- 同一 _idx 只能出现在一个 group 的某一 evidence.source_indices 中，或出现在 discarded_indices 中，不得在多个 evidence 间重复。
- 一个 group 的 evidence 数组必须包含本 group 涉及的所有 _idx（按 quote 去重合并后），不得遗漏。
- 每条 evidence.quote 必须逐字来自其 source_indices 中某一 _idx 的 scope_text；不同 evidence 的 quote 互不相同（语义/文本均不重合）。
- 严禁输出 clause_locator / scope_text / parameters / source_page_indices —— 系统会按 evidence.source_indices 取用并按 (1)(2)(3) 编号拼接。
- discarded_indices 通常留空；仅当某碎片与任何工程实体/施工内容完全无关且不应进入裁判时再列入。"""


_JSON_BLOCK_RE = re.compile(r"\{[\s\S]*\}")
_FENCE_OPEN_RE = re.compile(r"^\s*```(?:json)?\s*", re.IGNORECASE)
_FENCE_CLOSE_RE = re.compile(r"\s*```\s*$", re.IGNORECASE)

_WORK_METHOD_KEYWORDS: tuple[str, ...] = (
    "顶推", "顶推系统", "钢箱梁", "钢结构", "吊装", "钻孔桩", "灌注桩", "PHC管桩", "PHC",
    "围堰", "沉井", "盾构", "栈桥", "支架", "缆索", "主缆", "导梁", "预制梁", "预制安装",
    "装配式梁", "管桩", "软基", "台后加固",
)
_GENERIC_TITLE_MAX_LEN = 80
_MERGE_BY_KW_MAX_LEN = 500

# 与原项目 SynthesizerConfig 对齐：整份 user_text 超过 MAX_INPUT_CHARS 时按 CHUNK_FRAGMENTS 分块合成。
MAX_INPUT_CHARS = 100_000
CHUNK_FRAGMENTS = 35


def chunk_fragments(fragments: List[Dict[str, Any]], contract_file: str) -> List[List[Dict[str, Any]]]:
    """决定性地把碎片切成分块列表（逐字对齐 ContractSynthesizer.synthesize 的分块阈值）。

    整份 user_text 不超过 MAX_INPUT_CHARS 时单块下发；否则按 CHUNK_FRAGMENTS 等大切片。
    切片对象是已带「全局唯一 _idx」的 fragments，_idx 保持不变；跨块同对象合并由
    _merge_overlapping_groups 兜底（与原项目 _synthesize_chunked 末段一致）。
    """
    if not fragments:
        return []
    if len(build_user_text(fragments, contract_file)) <= MAX_INPUT_CHARS:
        return [fragments]
    return [fragments[i : i + CHUNK_FRAGMENTS] for i in range(0, len(fragments), CHUNK_FRAGMENTS)]


def build_chunk_user_text(
    chunk: List[Dict[str, Any]], contract_file: str, idx: int, total: int
) -> str:
    """单块 user 文本（逐字移植自 ContractSynthesizer._synthesize_chunked 的 ut）。"""
    return (
        f"【分块 {idx + 1}/{total}】合同《{contract_file}》\n"
        "请仅对本块内的碎片分组并按 quote 去重，evidence.source_indices "
        "使用碎片自带的 _idx（全局唯一）。\n\n"
        + OUTPUT_HINT
        + "\n\n【条款碎片】\n"
        + json.dumps(chunk, ensure_ascii=False, indent=2)
    )


def build_user_text(fragments: List[Dict[str, Any]], contract_file: str) -> str:
    """构造交给 Agent 的 user 文本（逐字移植自 ContractSynthesizer.synthesize）。"""
    return (
        "以下 JSON 为同一份合同《"
        + contract_file
        + "》的条款碎片列表（每项含 _idx、page_index、clause_locator、scope_text、"
        "domain_classification、structural_position 等字段）。\n"
        "请按上文规则分组合并，并在每个 group 内按 quote 去重，输出 evidence 列表。\n\n"
        + OUTPUT_HINT
        + "\n\n【条款碎片】\n"
        + json.dumps(fragments, ensure_ascii=False, indent=2)
    )


def _strip_markdown_fence(raw: str) -> str:
    s = (raw or "").strip()
    s = _FENCE_OPEN_RE.sub("", s, count=1)
    s = _FENCE_CLOSE_RE.sub("", s)
    return s.strip()


def _fragment_by_idx(fragments: List[Dict[str, Any]]) -> Dict[int, Dict[str, Any]]:
    by_idx: Dict[int, Dict[str, Any]] = {}
    for f in fragments:
        try:
            by_idx[int(f.get("_idx"))] = f
        except (TypeError, ValueError):
            continue
    return by_idx


def _group_combined_text(group: Dict[str, Any], by_idx: Dict[int, Dict[str, Any]]) -> str:
    parts: List[str] = []
    for i in _flatten_group_indices(group):
        frag = by_idx.get(i)
        if not frag:
            continue
        parts.append(str(frag.get("clause_locator", "")))
        parts.append(str(frag.get("scope_text", "")))
    return "\n".join(parts)


def _flatten_group_indices(group: Dict[str, Any]) -> List[int]:
    out: List[int] = []
    evidence_raw = group.get("evidence")
    if isinstance(evidence_raw, list) and evidence_raw:
        for ev in evidence_raw:
            if not isinstance(ev, dict):
                continue
            for raw in ev.get("source_indices") or []:
                try:
                    out.append(int(raw))
                except (TypeError, ValueError):
                    continue
        if out:
            return out
    for raw in group.get("source_indices") or []:
        try:
            out.append(int(raw))
        except (TypeError, ValueError):
            continue
    return out


def _extract_work_keywords(text: str) -> Set[str]:
    return {kw for kw in _WORK_METHOD_KEYWORDS if kw in text}


def _should_merge_groups(text_a: str, text_b: str, sig_a: Set[str], sig_b: Set[str]) -> bool:
    if sig_a & sig_b:
        if len(text_a) <= _MERGE_BY_KW_MAX_LEN or len(text_b) <= _MERGE_BY_KW_MAX_LEN:
            return True
    shorter, longer = (text_a, text_b) if len(text_a) <= len(text_b) else (text_b, text_a)
    s = shorter.strip()
    if s and len(s) <= _GENERIC_TITLE_MAX_LEN and s in longer:
        return True
    return False


def _merge_overlapping_groups(
    groups: List[Dict[str, Any]], fragments: List[Dict[str, Any]]
) -> List[Dict[str, Any]]:
    if len(groups) <= 1:
        return groups
    by_idx = _fragment_by_idx(fragments)
    n = len(groups)
    parent = list(range(n))

    def find(x: int) -> int:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a: int, b: int) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    texts = [_group_combined_text(g, by_idx) for g in groups]
    sigs = [_extract_work_keywords(t) for t in texts]
    for i in range(n):
        for j in range(i + 1, n):
            if _should_merge_groups(texts[i], texts[j], sigs[i], sigs[j]):
                union(i, j)

    buckets: Dict[int, List[int]] = {}
    for i in range(n):
        buckets.setdefault(find(i), []).append(i)
    if len(buckets) >= n:
        return groups

    merged: List[Dict[str, Any]] = []
    for members in buckets.values():
        evidence_acc: List[Dict[str, Any]] = []
        domain = position = subject = None
        is_generic = False
        notes_parts: List[str] = []
        for mi in members:
            g = groups[mi]
            evidence_acc.extend(_group_evidence_or_fallback(g))
            if not domain and g.get("domain_classification"):
                domain = g.get("domain_classification")
            if not position and g.get("structural_position"):
                position = g.get("structural_position")
            if not subject and g.get("engineering_subject"):
                subject = g.get("engineering_subject")
            is_generic = is_generic or bool(g.get("is_generic", False))
            nt = g.get("notes")
            if nt and str(nt).strip():
                notes_parts.append(str(nt).strip())
        merged.append(
            {
                "engineering_subject": subject,
                "domain_classification": domain,
                "structural_position": position,
                "evidence": evidence_acc,
                "is_generic": is_generic,
                "notes": "；".join(notes_parts) if notes_parts else None,
            }
        )
    return merged


def _group_evidence_or_fallback(group: Dict[str, Any]) -> List[Dict[str, Any]]:
    ev_raw = group.get("evidence")
    if isinstance(ev_raw, list) and ev_raw:
        norm: List[Dict[str, Any]] = []
        for ev in ev_raw:
            if not isinstance(ev, dict):
                continue
            idxs: List[int] = []
            for raw in ev.get("source_indices") or []:
                try:
                    idxs.append(int(raw))
                except (TypeError, ValueError):
                    continue
            if not idxs:
                continue
            quote = ev.get("quote")
            norm.append({"source_indices": idxs, "quote": str(quote).strip() if quote is not None else ""})
        if norm:
            return norm
    legacy_idxs: List[int] = []
    for raw in group.get("source_indices") or []:
        try:
            legacy_idxs.append(int(raw))
        except (TypeError, ValueError):
            continue
    if legacy_idxs:
        return [{"source_indices": legacy_idxs, "quote": ""}]
    return []


def _pick_earliest_locator(indices: List[int], by_idx: Dict[int, Dict[str, Any]]) -> str:
    candidates: List[Tuple[Tuple[bool, int], str]] = []
    for k in indices:
        frag = by_idx.get(int(k)) if isinstance(k, (int, str)) and str(k).lstrip("-").isdigit() else by_idx.get(k)
        if not frag:
            continue
        loc = str(frag.get("clause_locator", "")).strip()
        if not loc:
            continue
        pi = frag.get("page_index")
        candidates.append(((pi is None, pi if isinstance(pi, int) else 0), loc))
    if not candidates:
        return ""
    candidates.sort(key=lambda x: x[0])
    return candidates[0][1]


def _quote_signature(quote: str) -> str:
    if not quote:
        return ""
    s = re.sub(r"\s+", "", quote)
    s = re.sub(r"[，,。.；;：:、（）()\[\]【】\"'']", "", s)
    return s


_TITLE_QUOTE_MAX_SIG_LEN = 120


def _is_subsequence(short: str, long: str) -> bool:
    it = iter(long)
    return all(ch in it for ch in short)


def _is_quote_redundant(short_quote: str, long_quote: str) -> bool:
    short_sig = _quote_signature(short_quote)
    long_sig = _quote_signature(long_quote)
    if not short_sig or not long_sig or len(short_sig) >= len(long_sig):
        return False
    if short_sig in long_sig:
        return True
    if len(short_sig) <= _TITLE_QUOTE_MAX_SIG_LEN and _is_subsequence(short_sig, long_sig):
        return True
    return False


def _merge_evidence_into(target: Dict[str, Any], source: Dict[str, Any], by_idx: Dict[int, Dict[str, Any]]) -> None:
    for key in ("source_indices", "page_indices"):
        existing = list(target.get(key) or [])
        for v in source.get(key) or []:
            if v not in existing:
                existing.append(v)
        target[key] = existing
    all_idxs = [int(k) for k in target.get("source_indices") or [] if isinstance(k, (int, str)) and str(k).lstrip("-").isdigit()]
    if all_idxs:
        target["location"] = _pick_earliest_locator(all_idxs, by_idx)
    src_q = str(source.get("quote", "")).strip()
    tgt_q = str(target.get("quote", "")).strip()
    if len(src_q) > len(tgt_q):
        target["quote"] = src_q


def _collapse_substring_evidence(
    evidence_items: List[Dict[str, Any]], by_idx: Dict[int, Dict[str, Any]]
) -> List[Dict[str, Any]]:
    if len(evidence_items) <= 1:
        return evidence_items
    order = sorted(
        range(len(evidence_items)),
        key=lambda i: len(_quote_signature(str(evidence_items[i].get("quote", "")))),
        reverse=True,
    )
    absorbed = [False] * len(evidence_items)
    for i in order:
        if absorbed[i]:
            continue
        long_ev = evidence_items[i]
        long_q = str(long_ev.get("quote", ""))
        for j in range(len(evidence_items)):
            if j == i or absorbed[j]:
                continue
            if _is_quote_redundant(str(evidence_items[j].get("quote", "")), long_q):
                _merge_evidence_into(long_ev, evidence_items[j], by_idx)
                absorbed[j] = True
    return [evidence_items[i] for i in range(len(evidence_items)) if not absorbed[i]]


def _normalize_group_evidence(
    evidence_raw: List[Dict[str, Any]], by_idx: Dict[int, Dict[str, Any]], used: Set[int]
) -> Tuple[List[Dict[str, Any]], List[int], List[int]]:
    evidence_items: List[Dict[str, Any]] = []
    group_pages: List[int] = []
    group_param_idxs: List[int] = []
    quote_to_pos: Dict[str, int] = {}

    for ev in evidence_raw:
        if not isinstance(ev, dict):
            continue
        valid: List[int] = []
        for raw_i in ev.get("source_indices") or []:
            try:
                ii = int(raw_i)
            except (TypeError, ValueError):
                continue
            if ii not in by_idx or ii in used:
                continue
            valid.append(ii)
            used.add(ii)
        if not valid:
            continue
        valid.sort(key=lambda k: (by_idx[k].get("page_index") is None, by_idx[k].get("page_index", 0)))

        primary_locator = _pick_earliest_locator(valid, by_idx)
        quote = str(ev.get("quote") or "").strip()
        for k in valid:
            sc = str(by_idx[k].get("scope_text", "")).strip()
            if sc and len(sc) > len(quote):
                quote = sc
        quote_key = _quote_signature(quote)
        page_indices = [by_idx[k].get("page_index", -1) for k in valid]

        if quote_key and quote_key in quote_to_pos:
            pos = quote_to_pos[quote_key]
            existing = evidence_items[pos]
            existing.setdefault("source_indices", []).extend(valid)
            existing.setdefault("page_indices", []).extend(page_indices)
            existing["location"] = _pick_earliest_locator(existing["source_indices"], by_idx)
            if len(quote) > len(existing.get("quote", "")):
                existing["quote"] = quote
        else:
            evidence_items.append(
                {
                    "location": primary_locator,
                    "quote": quote,
                    "source_indices": list(valid),
                    "page_indices": list(page_indices),
                }
            )
            if quote_key:
                quote_to_pos[quote_key] = len(evidence_items) - 1

        for pi in page_indices:
            if pi not in group_pages:
                group_pages.append(pi)
        for k in valid:
            if k not in group_param_idxs:
                group_param_idxs.append(k)

    evidence_items = _collapse_substring_evidence(evidence_items, by_idx)
    evidence_items.sort(key=lambda ev: _first_page_of_evidence(ev))
    return evidence_items, group_pages, group_param_idxs


def _first_page_of_evidence(ev: Dict[str, Any]) -> Tuple[bool, int]:
    pages = ev.get("page_indices") or []
    valid_pages = [p for p in pages if isinstance(p, int) and p >= 0]
    if not valid_pages:
        return (True, 0)
    return (False, min(valid_pages))


def _parse_groups(raw: str) -> Tuple[List[Dict[str, Any]], List[int]]:
    text = _strip_markdown_fence(raw or "")
    m = _JSON_BLOCK_RE.search(text)
    if not m:
        return [], []
    try:
        data = json.loads(m.group(0))
    except json.JSONDecodeError:
        return [], []
    out: List[Dict[str, Any]] = []
    for g in data.get("groups") or []:
        if not isinstance(g, dict):
            continue
        out.append(
            {
                "engineering_subject": g.get("engineering_subject"),
                "domain_classification": g.get("domain_classification") or g.get("engineering_category"),
                "structural_position": g.get("structural_position"),
                "evidence": g.get("evidence"),
                "source_indices": g.get("source_indices"),
                "is_generic": bool(g.get("is_generic", False)),
                "notes": g.get("notes"),
            }
        )
    discarded: List[int] = []
    for i in data.get("discarded_indices") or []:
        try:
            discarded.append(int(i))
        except (TypeError, ValueError):
            continue
    return out, discarded


def _build_ledger_from_groups(
    fragments: List[Dict[str, Any]], groups: List[Dict[str, Any]], discarded: List[int]
) -> List[Dict[str, Any]]:
    if not fragments:
        return []
    by_idx: Dict[int, Dict[str, Any]] = {}
    for f in fragments:
        try:
            by_idx[int(f.get("_idx"))] = f
        except (TypeError, ValueError):
            continue

    ledger: List[Dict[str, Any]] = []
    used: Set[int] = set()
    discarded_set = {int(i) for i in discarded if isinstance(i, (int, str)) and str(i).lstrip("-").isdigit()}
    _pos_unknown = {"不适用", "N/A", "无", "", None}

    for g in groups:
        evidence_raw = _group_evidence_or_fallback(g)
        evidence_items, group_pages, group_param_idxs = _normalize_group_evidence(evidence_raw, by_idx, used)
        if not evidence_items:
            continue

        locator_text = "\n".join(f"({n}) {ev['location']}" for n, ev in enumerate(evidence_items, start=1))
        scope_text_combined = "\n".join(f"({n}) {ev['quote']}" for n, ev in enumerate(evidence_items, start=1))

        params: List[Dict[str, Any]] = []
        for k in group_param_idxs:
            p = by_idx[k].get("parameters") or []
            if isinstance(p, list):
                params.extend(p)

        domain = g.get("domain_classification")
        position = g.get("structural_position")
        subject = g.get("engineering_subject")
        if not domain:
            for k in group_param_idxs:
                c = by_idx[k].get("domain_classification") or by_idx[k].get("engineering_category")
                if c:
                    domain = c
                    break
        if not position:
            for k in group_param_idxs:
                p = by_idx[k].get("structural_position")
                if p:
                    position = p
                    break

        seen_positions: list = []
        for k in group_param_idxs:
            p = by_idx[k].get("structural_position")
            if p and p not in _pos_unknown and p not in seen_positions:
                seen_positions.append(p)
        if position and position not in _pos_unknown and position not in seen_positions:
            seen_positions.insert(0, position)

        is_generic = bool(g.get("is_generic", False)) or any(
            bool(by_idx[k].get("is_generic")) for k in group_param_idxs
        )
        ledger.append(
            {
                "page_index": group_pages[0] if group_pages else -1,
                "source_page_indices": group_pages,
                "source_fragment_indices": group_param_idxs,
                "engineering_subject": subject,
                "engineering_category": domain,
                "domain_classification": domain,
                "structural_position": position,
                "structural_positions": seen_positions,
                "evidence": evidence_items,
                "clause_locator": locator_text,
                "scope_text": scope_text_combined,
                "parameters": params,
                "is_generic": is_generic,
                "notes": g.get("notes"),
            }
        )

    # 兜底：未分组、未显式剔除的碎片，单独成条
    for key, frag in by_idx.items():
        if key in used or key in discarded_set:
            continue
        loc = str(frag.get("clause_locator", "")).strip()
        quote = str(frag.get("scope_text", "")).strip()
        page_idx = frag.get("page_index", -1)
        if not (loc or quote):
            continue
        ev = [{"location": loc, "quote": quote, "source_indices": [key], "page_indices": [page_idx]}]
        frag_pos = frag.get("structural_position")
        frag_positions = [frag_pos] if frag_pos and frag_pos not in {"不适用", "N/A", "无", ""} else []
        ledger.append(
            {
                "page_index": page_idx,
                "source_page_indices": [page_idx],
                "source_fragment_indices": [key],
                "engineering_subject": None,
                "engineering_category": frag.get("domain_classification") or frag.get("engineering_category"),
                "domain_classification": frag.get("domain_classification") or frag.get("engineering_category"),
                "structural_position": frag_pos,
                "structural_positions": frag_positions,
                "evidence": ev,
                "clause_locator": f"(1) {loc}",
                "scope_text": f"(1) {quote}",
                "parameters": frag.get("parameters") or [],
                "is_generic": bool(frag.get("is_generic", False)),
                "notes": None,
            }
        )
    return ledger


def parse_groups(raw: str) -> Tuple[List[Dict[str, Any]], List[int]]:
    """解析 Agent 返回的 groups JSON（_parse_groups 的公开入口，供分块合成累积调用）。"""
    return _parse_groups(raw)


def build_ledger_from_groups(
    fragments: List[Dict[str, Any]],
    groups: List[Dict[str, Any]],
    discarded: List[int],
) -> List[Dict[str, Any]]:
    """跨块关键词合并 + 落台账（分块合成在所有块回收后调用一次，对应原项目 _synthesize_chunked 末段）。"""
    groups = _merge_overlapping_groups(groups, fragments)
    return _build_ledger_from_groups(fragments, groups, discarded)


def build_ledger(fragments: List[Dict[str, Any]], raw: str) -> List[Dict[str, Any]]:
    """解析 Agent 返回的 groups JSON，落成台账行（含跨组关键词合并 + 子串去重后处理）。"""
    groups, discarded = _parse_groups(raw)
    return build_ledger_from_groups(fragments, groups, discarded)
