"""Deterministic helpers for the contract compliance audit skill."""
