"""Evidence / Findings 语义去重器 —— 逐字移植自原项目 app/modules/evidence_deduplicator.py。

两个独立任务：
  1. evidence 去重（synthesizer 之后、validate 之前）：对每条台账的 evidence 列表做
     「宏观母体识别 + 父子级吸收」，剔除被总括覆盖的冗余子项 evidence；
  2. findings 去重（validate 之后）：剔除被宏观 finding 覆盖的冗余子项 finding（仅 low 可被剔除）。

LLM 调用由 Agent 完成，本模块只提供 prompt 与**确定性后处理**（安全校验 + 编号重建）。
为减少 Agent 轮次，evidence 去重按【整份合同】一次性下发（原项目按单条台账调用，
判定逻辑完全一致）；findings 去重与原项目一致，按合同一次性处理。
"""

from __future__ import annotations

import json
import re
from typing import Any, Dict, List, Set

EVIDENCE_SYSTEM_PROMPT = """你是一个工程合同信息质量审核员。我将提供属于【同一施工实体】的若干条"证据摘录"（每条有编号、条款位置、摘录原文）。

你的唯一任务：为后续的【合规审查】保留最精炼的证据集合。请执行以下两步决策框架。

═══════════════════════════════════════════════
第一步：识别「宏观母体」
═══════════════════════════════════════════════
在所有摘录中，首先寻找并标记【宏观母体】——即对该施工实体的"总括性承包范围描述"。
典型特征：
  - 来自合同"工程概况"或"分包工程承包范围和内容"章节；
  - 内容形如"××工程相关的……（主缆制作安装、吊索制作安装、索鞍索夹安装、…）等工程内容"；
  - 用"包含但不限于"或"等工程内容"概括多项子工程；
  - 通常是列表中信息量最大、最综合的一条。

若找到宏观母体，执行第二步；若所有条目均为平级清单（无总括描述），跳至【平级保留规则】。

═══════════════════════════════════════════════
第二步：父子级吸收法则（CRITICAL）
═══════════════════════════════════════════════
宏观母体一旦确认，对其他每条摘录逐一执行以下判断：

【必须剔除 → 放入 discard_indices】
凡满足以下任一条件，直接剔除：
  A. 该条描述的工程内容已被宏观母体点名提及（即使措辞不完全相同）；
  B. 该条仅是宏观母体某一子系统的"工程量清单明细"：
     - 工程量清单单行条目（如"序号3：主缆检修通道Q235C：含原材料、加工制作……"），
       且其描述的对象已在宏观母体中被总括覆盖；
  C. 附属件、防护件、临时措施件，且已被宏观母体的"等"或"包含但不限于"范畴涵盖
     （典型：爬梯、检修通道、鞍罩、保护罩、定位骨架、锚箱、横梁、猫道、牵引系统）；
  D. 仅重复工程名称标题，无实质性施工内容；
  E. 主语义是付款触发条件、验收程序、结算比例。

【必须保留 → 放入 keep_indices】
满足以下任一条件，必须保留：
  - 宏观母体本身（无论如何都保留）；
  - 描述与宏观母体中【完全未提及】的独立物理实体（非附属、非子系统），
    例如：宏观母体只说"主缆制作安装"，而另一条说的是"引桥预应力管桩"——平级不同实体；
  - 包含宏观母体中没有的独立合同计价方式（如"包干结算"）或核心阈值参数
    （桥梁跨径、桩长、承载力等），且该参数对判断是否触发负面清单阈值有直接价值。

═══════════════════════════════════════════════
平级保留规则（无宏观母体时）
═══════════════════════════════════════════════
  - 若所有条目均为平级清单条目（无总括描述），则：
    - 剔除仅重复工程名称标题的条目；
    - 剔除付款/验收条目；
    - 其余全部保留。

═══════════════════════════════════════════════
兜底约束
═══════════════════════════════════════════════
  - 至少保留 1 条（兜底保留信息量最大的那条）；
  - 输出必须是【严格 JSON】，禁止 Markdown 围栏，禁止额外解释。"""

EVIDENCE_OUTPUT_HINT = """输出 JSON 结构（使用输入中的 0-based 编号）：
{
  "macro_index": 0,
  "keep_indices": [0],
  "discard_indices": [1, 2, 3, 4, 5],
  "reason": "条目0为宏观母体；条目1-5均为其工程量清单子项，已被宏观母体总括覆盖"
}
硬性要求：
- keep_indices + discard_indices 必须覆盖全部输入编号，不得遗漏；
- macro_index 填宏观母体的编号（若无则填 -1）；
- 宏观母体（macro_index）必须在 keep_indices 中，绝不能被剔除；
- reason 使用中文，说明剔除依据（不超过 80 字）。"""


FINDINGS_SYSTEM_PROMPT = """你是合同合规审查质检员。以下是同一合同的若干条「合规发现」，每条有编号、风险等级、原文摘录、依据条款。

任务：识别冗余条目并放入 discard_indices，让最终报告精炼无重复。

【判断规则（按优先级）】
1. 父子实体吸收：若发现A的工程实体是发现B中某实体的具体子构件
   （如「主索鞍」「主索鞍鞍罩」均属于B所说的「索鞍索夹安装」范畴），
   且B的原文已总括提及该类构件，则A为冗余子项 → 放入 discard_indices。
2. 平级实体合并：若两条发现描述高度相似的同类实体，保留 risk 更高
   或原文更完整的一条，另一条放入 discard_indices。
3. 保护高风险：medium / high 发现绝对不可被 discard；
   只有 low 发现可能被剔除。
4. 宁可多留：实体不同、信息互补、无法判断包含关系的两条均保留。

输出严格 JSON（禁止 Markdown 围栏，禁止额外解释）：
{"discard_indices": [0-based 整数列表，为空时输出 []]}"""


_JSON_BLOCK_RE = re.compile(r"\{[\s\S]*\}")


def build_evidence_user_text(ledger: List[Dict[str, Any]]) -> str:
    """整份台账一次性下发：每条台账独立判定其 evidence 去重。"""
    entries = []
    for i, item in enumerate(ledger):
        evidence = item.get("evidence") or []
        if len(evidence) < 2:
            # 原项目：evidence < min_evidence_to_deduplicate(=2) 直接跳过；这里也不下发
            continue
        subject = str(item.get("engineering_subject") or item.get("engineering_category") or "")
        entries.append(
            {
                "entry_index": i,
                "subject": subject,
                "evidence": [
                    {
                        "index": j,
                        "location": str(ev.get("location", ""))[:80],
                        "quote": str(ev.get("quote", ""))[:300],
                    }
                    for j, ev in enumerate(evidence)
                ],
            }
        )
    return (
        "【台账条目列表】（每条台账的 evidence 需独立判定去重）\n"
        + json.dumps(entries, ensure_ascii=False, indent=2)
        + "\n\n请对每条台账独立执行「宏观母体识别 + 父子级吸收」两步决策。\n\n"
        + EVIDENCE_OUTPUT_HINT
        + '\n\n输出：{"entries":[{"entry_index":0,"macro_index":0,"keep_indices":[0],"discard_indices":[1],'
        '"reason":"..."}]}（仅对下发了的 entry_index 输出）。'
    )


def _parse_int_set(values: Any) -> Set[int]:
    out: Set[int] = set()
    if not isinstance(values, list):
        return out
    for v in values:
        try:
            out.add(int(v))
        except (TypeError, ValueError):
            continue
    return out


def _safe_discard(discard_raw: Any, keep_raw: Any, macro_raw: Any, total: int) -> Set[int]:
    """剔除被宏观母体总括覆盖的 evidence；keep_indices / macro_index 永不被剔除（移植自 _parse_discard）。"""
    discard = {i for i in _parse_int_set(discard_raw) if 0 <= i < total}
    discard -= _parse_int_set(keep_raw)
    try:
        macro_idx = int(macro_raw)
        if 0 <= macro_idx < total:
            discard.discard(macro_idx)
    except (TypeError, ValueError):
        pass
    return discard


def _rebuild_item(item: Dict[str, Any], kept_evidence: List[Dict[str, Any]]) -> Dict[str, Any]:
    """用保留的 evidence 列表重新生成 clause_locator / scope_text（重新 (1)(2)(3) 编号）。"""
    new_item = dict(item)
    new_item["evidence"] = kept_evidence
    new_item["clause_locator"] = "\n".join(
        f"({n}) {ev.get('location', '')}" for n, ev in enumerate(kept_evidence, start=1)
    )
    new_item["scope_text"] = "\n".join(
        f"({n}) {ev.get('quote', '')}" for n, ev in enumerate(kept_evidence, start=1)
    )
    all_pages: List[int] = []
    all_frags: List[int] = []
    for ev in kept_evidence:
        for pi in ev.get("page_indices") or []:
            if isinstance(pi, int) and pi not in all_pages:
                all_pages.append(pi)
        for fi in ev.get("source_indices") or []:
            try:
                fi_int = int(fi)
                if fi_int not in all_frags:
                    all_frags.append(fi_int)
            except (TypeError, ValueError):
                pass
    if all_pages:
        new_item["source_page_indices"] = all_pages
        new_item["page_index"] = all_pages[0]
    if all_frags:
        new_item["source_fragment_indices"] = all_frags
    return new_item


def apply_evidence_dedup(ledger: List[Dict[str, Any]], raw: str) -> List[Dict[str, Any]]:
    """解析 Agent 返回的 per-entry discard，剔除冗余 evidence 并重建编号。失败/无输出时原样返回。"""
    if not ledger:
        return ledger
    text = raw or ""
    m = _JSON_BLOCK_RE.search(text)
    if not m:
        return ledger
    try:
        data = json.loads(m.group(0))
    except json.JSONDecodeError:
        return ledger

    by_entry: Dict[int, Dict[str, Any]] = {}
    for e in data.get("entries") or []:
        if not isinstance(e, dict):
            continue
        try:
            by_entry[int(e.get("entry_index"))] = e
        except (TypeError, ValueError):
            continue

    cleaned: List[Dict[str, Any]] = []
    for i, item in enumerate(ledger):
        evidence = item.get("evidence") or []
        entry = by_entry.get(i)
        if not entry or len(evidence) < 2:
            cleaned.append(item)
            continue
        discard = _safe_discard(
            entry.get("discard_indices"),
            entry.get("keep_indices"),
            entry.get("macro_index", -1),
            len(evidence),
        )
        if not discard:
            cleaned.append(item)
            continue
        kept = [ev for j, ev in enumerate(evidence) if j not in discard]
        if not kept:
            # 兜底：LLM 欲剔除全部，强制保留信息量最大的一条
            kept = [max(evidence, key=lambda ev: len(str(ev.get("quote", ""))))]
        cleaned.append(_rebuild_item(item, kept))
    return cleaned


def build_findings_user_text(findings: List[Dict[str, Any]]) -> str:
    payload = []
    for i, f in enumerate(findings):
        payload.append(
            {
                "index": i,
                "risk": str(f.get("severity", "low")),
                "quote": str(f.get("original_quote", ""))[:250],
                "rule": str(f.get("reference_clause", ""))[:120],
            }
        )
    return (
        "【合规发现列表】\n"
        + json.dumps(payload, ensure_ascii=False, indent=2)
        + "\n\n请输出 discard_indices（严格 JSON）。"
    )


def apply_findings_dedup(findings: List[Dict[str, Any]], raw: str) -> List[Dict[str, Any]]:
    """剔除被宏观 finding 覆盖的冗余子项 finding；high/medium 永不被剔除（移植自 _parse_findings_discard）。"""
    if not findings or len(findings) < 2:
        return findings
    m = _JSON_BLOCK_RE.search(raw or "")
    if not m:
        return findings
    try:
        data = json.loads(m.group(0))
    except json.JSONDecodeError:
        return findings

    discard: Set[int] = set()
    for v in data.get("discard_indices") or []:
        try:
            idx = int(v)
        except (TypeError, ValueError):
            continue
        if not (0 <= idx < len(findings)):
            continue
        sev = str(findings[idx].get("severity", "low"))
        if sev in ("high", "medium"):
            continue  # 强制保留高风险发现
        discard.add(idx)
    if not discard:
        return findings
    return [f for i, f in enumerate(findings) if i not in discard]
