"""extract_text / synthesize 的 payload 文件按 chunk_index 分文件，避免批量 emit 互相覆盖。"""
from __future__ import annotations

from pathlib import Path


def _contract(tmp_path: Path) -> dict:
    return {
        "contract_id": "c001",
        "contract_file": "x.pdf",
        "contract_type": "分包",
        "ocr": {"middle_path": "/abs/x_middle.json", "markdown_path": "", "raw_response": "", "error": ""},
    }


def _state(tmp_path: Path, contract: dict) -> dict:
    return {"schema_version": 1, "project_name": "t", "output_dir": str(tmp_path), "contracts": [contract]}


def test_write_text_payload_filename_has_chunk_suffix(tmp_path: Path) -> None:
    """传 chunk_index 时文件名带 _c{ci}；不传时保持原样（dedup_* 单任务）。"""
    from advance_review import _write_text_payload

    contract = _contract(tmp_path)
    state = _state(tmp_path, contract)

    p0 = _write_text_payload(tmp_path / "state.json", state, contract, "extract_text", "SYS", "USER", chunk_index=0)
    p1 = _write_text_payload(tmp_path / "state.json", state, contract, "extract_text", "SYS", "USER", chunk_index=1)
    p_none = _write_text_payload(tmp_path / "state.json", state, contract, "dedup_evidence", "SYS", "USER")

    assert "_c0" in p0 and "_c1" in p1
    assert p0 != p1
    assert "_c" not in p_none  # dedup_* 不分块，文件名不带 _c
    assert Path(p0).is_file() and Path(p1).is_file() and Path(p_none).is_file()


def test_extract_text_chunk_item_payload_per_chunk(tmp_path: Path) -> None:
    """_extract_text_chunk_item 对不同 chunk_index 产出不同 payload_path（不互相覆盖）。"""
    from advance_review import _extract_text_chunk_item

    text_tasks = tmp_path / "text_tasks"
    text_tasks.mkdir()
    chunks = []
    for ci in range(2):
        p = text_tasks / f"c001_extract_chunk_{ci:03d}.md"
        p.write_text(f"## 第 {ci + 1} 页\n\nPAGE {ci}", encoding="utf-8")
        chunks.append({"chunk_index": ci, "page_indices": [ci], "path": str(p)})

    contract = _contract(tmp_path)
    state = _state(tmp_path, contract)
    item0 = _extract_text_chunk_item(tmp_path / "state.json", state, contract, 0, chunks[0], 2)
    item1 = _extract_text_chunk_item(tmp_path / "state.json", state, contract, 1, chunks[1], 2)

    assert item0["payload_path"] != item1["payload_path"]
    assert "_c0" in item0["payload_path"] and "_c1" in item1["payload_path"]
    assert Path(item0["payload_path"]).is_file() and Path(item1["payload_path"]).is_file()


def test_synthesize_item_payload_per_chunk(tmp_path: Path) -> None:
    """_synthesize_item 对不同 chunk_index 产出不同 payload_path。"""
    from unittest import mock
    from advance_review import _synthesize_item

    contract = _contract(tmp_path)
    state = _state(tmp_path, contract)
    with mock.patch("advance_review._synth.build_chunk_user_text", return_value="USER TEXT"):
        item0 = _synthesize_item(tmp_path / "state.json", state, contract, 0, [{"_idx": 0}], 2)
        item1 = _synthesize_item(tmp_path / "state.json", state, contract, 1, [{"_idx": 1}], 2)

    assert item0["payload_path"] != item1["payload_path"]
    assert "_c0" in item0["payload_path"] and "_c1" in item1["payload_path"]
    assert Path(item0["payload_path"]).is_file() and Path(item1["payload_path"]).is_file()
