"""_load_pages_from_middle rebuilds per-page markdown via MinerU union_make."""
from __future__ import annotations

import json
from pathlib import Path
from unittest import mock


def test_load_pages_happy(tmp_path: Path) -> None:
    from advance_review import _load_pages_from_middle
    middle_path = tmp_path / "x_middle.json"
    middle_path.write_text(
        json.dumps(
            {
                "_backend": "vlm",
                "pdf_info": [
                    {"page_idx": 1, "blocks": ["b1"]},
                    {"page_idx": 0, "blocks": ["b0"]},
                ],
            }
        ),
        encoding="utf-8",
    )

    def fake_make(page_list, image_dir):
        return f"MD page {page_list[0]['page_idx']}"

    with mock.patch("advance_review._get_union_make", return_value=fake_make):
        result = _load_pages_from_middle(str(middle_path))

    # 按 page_idx 升序，markdown 来自 union_make
    assert result == [(0, "MD page 0"), (1, "MD page 1")]


def test_load_pages_fallback_to_full_markdown(tmp_path: Path) -> None:
    from advance_review import _load_pages_from_middle
    # middle.json 无 pdf_info；同名 x.md 存在
    middle_path = tmp_path / "x_middle.json"
    middle_path.write_text(json.dumps({"_backend": "vlm"}), encoding="utf-8")
    (tmp_path / "x.md").write_text("FULL MARKDOWN", encoding="utf-8")

    # _get_union_make 不应被调用（fallback 路径）
    with mock.patch("advance_review._get_union_make", side_effect=AssertionError("should not call union_make")):
        result = _load_pages_from_middle(str(middle_path))

    assert result == [(0, "FULL MARKDOWN")]


def test_load_pages_raises_when_middle_incomplete_and_md_absent(tmp_path: Path) -> None:
    """middle.json 已落盘但内容不全（无 pdf_info，写一半）且同名 .md 不存在
    → 视为瞬时未就绪，抛 MiddleNotReadyError，而非静默 []。

    回归：parse_document 写 _middle.json 时可能先写下 _backend、pdf_info 尚未写入；
    若此时静默返回 []，next_batch 会把 text_extraction 永久判死（线上卡死根因之一）。
    """
    import pytest
    from advance_review import _load_pages_from_middle, MiddleNotReadyError

    middle_path = tmp_path / "y_middle.json"
    middle_path.write_text(json.dumps({"_backend": "vlm"}), encoding="utf-8")  # 无 pdf_info
    # 无同名 y.md

    with mock.patch("advance_review._get_union_make", side_effect=AssertionError("should not call")):
        with pytest.raises(MiddleNotReadyError):
            _load_pages_from_middle(str(middle_path))


def test_load_pages_raises_when_md_present_but_empty(tmp_path: Path) -> None:
    """middle.json 尚未落盘、同名 .md 已创建但内容为空（写一半）→ 瞬时未就绪抛错。

    回归：用户线上卡死的真实时序 —— next_batch 在 .md 已建空文件、正文尚未写入的
    窗口内读到空串，旧逻辑返回 []，text_extraction 被永久判死。
    """
    import pytest
    from advance_review import _load_pages_from_middle, MiddleNotReadyError

    middle_path = tmp_path / "z_middle.json"  # 不存在
    (tmp_path / "z.md").write_text("", encoding="utf-8")  # 存在但空

    with mock.patch("advance_review._get_union_make", side_effect=AssertionError("should not call")):
        with pytest.raises(MiddleNotReadyError):
            _load_pages_from_middle(str(middle_path))


def test_load_pages_raises_not_ready_when_middle_and_md_absent(tmp_path: Path) -> None:
    """middle.json 与同名 .md 均不存在 → 瞬时未就绪，抛 MiddleNotReadyError 而非静默 []。

    回归：OCR 提交后 next_batch 立即运行时，parse_document 的 _middle.json 可能尚未落盘。
    若静默返回 []，空结果会被 _extract_chunks 缓存，永久卡死该合同的提取阶段
    （见 test_extract_chunks_does_not_cache_empty_result 与 next_batch 回归测试）。
    """
    import pytest
    from advance_review import _load_pages_from_middle, MiddleNotReadyError

    missing = tmp_path / "not_yet_middle.json"  # 既无 middle，也无同名 not_yet.md
    with pytest.raises(MiddleNotReadyError):
        _load_pages_from_middle(str(missing))
