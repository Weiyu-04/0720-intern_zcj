"""synthesize 阶段：next_batch 一次 emit 多个 pending 分块。"""
from __future__ import annotations

from pathlib import Path
from unittest import mock


def _state_with_synth_chunks(tmp_path: Path, n_chunks: int) -> tuple[Path, dict]:
    """构造一个 text_extraction 已完成、ledger=None、synth_chunks 已预置 n 块的合同。"""
    contract = {
        "contract_id": "c001",
        "contract_file": "x.pdf",
        "contract_path": "/abs/x.pdf",
        "contract_type": "分包",
        "ocr": {"markdown_path": "", "middle_path": "/abs/x_middle.json", "raw_response": "", "error": ""},
        "text_extraction": {"clauses": [{"clause_locator": f"（第{i+1}页）x"} for i in range(n_chunks)], "error": ""},
        "ledger": None,
        "synth_chunks": [[{"_idx": i}] for i in range(n_chunks)],
    }
    return tmp_path / "state.json", {
        "schema_version": 1, "project_name": "t", "output_dir": str(tmp_path), "contracts": [contract],
    }


def test_next_batch_synthesize_emits_all_pending_chunks(tmp_path: Path) -> None:
    """limit 够大时，synthesize 一次 emit 全部 pending 分块。"""
    from advance_review import next_batch
    state_path, state = _state_with_synth_chunks(tmp_path, 3)
    with mock.patch("advance_review._synth.build_chunk_user_text", return_value="USER"):
        result = next_batch(state_path, state, limit=8)
    assert result["action"] == "batch"
    assert result["phase"] == "synthesize"
    assert len(result["items"]) == 3
    assert [it["chunk_index"] for it in result["items"]] == [0, 1, 2]


def test_next_batch_synthesize_respects_limit(tmp_path: Path) -> None:
    """pending 多于 limit 时，本轮只 emit limit 个。"""
    from advance_review import next_batch
    state_path, state = _state_with_synth_chunks(tmp_path, 4)
    with mock.patch("advance_review._synth.build_chunk_user_text", return_value="USER"):
        result = next_batch(state_path, state, limit=2)
    assert result["action"] == "batch"
    assert len(result["items"]) == 2
    assert [it["chunk_index"] for it in result["items"]] == [0, 1]
