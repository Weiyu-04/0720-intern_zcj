"""--reset-extraction：清空 extract_text 及下游阶段，干净恢复被误判死的合同。"""
from __future__ import annotations

from pathlib import Path
from unittest import mock


def _dead_contract(tmp_path: Path) -> dict:
    """一个 text_extraction 被竞态误判死、且下游阶段已部分推进的合同。"""
    return {
        "contract_id": "c001",
        "contract_file": "x.pdf",
        "contract_path": "/abs/x.pdf",
        "contract_type": "分包",
        "ocr": {"markdown_path": "", "middle_path": str(tmp_path / "x_middle.json"),
                "raw_response": "", "error": ""},
        "text_extraction": {"clauses": [], "error": "no pages from middle.json / markdown"},
        "extract_chunks": [{"chunk_index": 0, "page_indices": [0], "path": "/abs/x.md"}],
        "extract_chunk_done": [0],
        "extract_clauses_acc": [{"clause_locator": "stale"}],
        "synth_chunks": [[{"_idx": 0}]],
        "synth_chunk_done": [0],
        "synth_groups_acc": [{"group": "stale"}],
        "synth_discarded_acc": [0],
        "ledger": [{"evidence": []}],
        "evidence_dedup_done": True,
        "validation": {"findings": []},
        "validate_done": [0],
        "validate_complete": True,
        "findings_dedup_done": True,
    }


_RESET_KEYS = (
    "text_extraction", "extract_chunks", "extract_chunk_done", "extract_clauses_acc",
    "synth_chunks", "synth_chunk_done", "synth_groups_acc", "synth_discarded_acc",
    "ledger", "evidence_dedup_done", "validation", "validate_done", "validate_complete",
    "findings_dedup_done",
)


def test_reset_extraction_clears_phase_state(tmp_path: Path) -> None:
    from advance_review import reset_extraction

    contract = _dead_contract(tmp_path)
    state = {"schema_version": 1, "project_name": "t", "output_dir": str(tmp_path),
             "contracts": [contract]}

    result = reset_extraction(state, "c001")

    for key in _RESET_KEYS:
        assert key not in contract, f"{key} 应被清空"
    # 元数据 + ocr 保留
    assert contract["contract_id"] == "c001"
    assert contract["ocr"]["middle_path"].endswith("x_middle.json")
    assert result["action"] == "reset"
    assert result["contract_id"] == "c001"
    assert set(result["cleared"]) == set(_RESET_KEYS)


def test_reset_extraction_unknown_contract_raises(tmp_path: Path) -> None:
    import pytest
    from advance_review import reset_extraction

    state = {"contracts": [{"contract_id": "c001"}]}
    with pytest.raises(ValueError):
        reset_extraction(state, "nope")


def test_next_batch_re_enters_extract_after_reset(tmp_path: Path) -> None:
    """reset 后 text_extraction 回到 None，next_batch 重新从 ocr.middle.json 切块进 extract_text。"""
    from advance_review import reset_extraction, next_batch

    contract = _dead_contract(tmp_path)
    state = {"schema_version": 1, "project_name": "t", "output_dir": str(tmp_path),
             "contracts": [contract]}

    reset_extraction(state, "c001")
    assert contract.get("text_extraction") is None

    with mock.patch("advance_review._load_pages_from_middle",
                    return_value=[(0, "P0"), (1, "P1")]):
        result = next_batch(tmp_path / "state.json", state, limit=8)
    assert result["action"] == "batch"
    assert result["phase"] == "extract_text"
    assert result["items"][0]["chunk_index"] == 0  # 从头重新切块
