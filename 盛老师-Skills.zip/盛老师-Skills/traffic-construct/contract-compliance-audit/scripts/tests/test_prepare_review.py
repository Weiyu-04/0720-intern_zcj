"""Tests for the rewritten prepare_review.py (no page-image rendering)."""
from __future__ import annotations

import json
from pathlib import Path

import fitz


def _make_pdf(path: Path, pages: int = 2) -> None:
    doc = fitz.open()
    for i in range(pages):
        doc.new_page().insert_text((72, 72), f"page {i + 1}")
    doc.save(str(path))
    doc.close()


def test_prepare_writes_state_without_pages_array(tmp_path: Path) -> None:
    from prepare_review import main

    pdf = tmp_path / "contract.pdf"
    _make_pdf(pdf, pages=2)
    out_dir = tmp_path / "out"

    rc = main([
        "--project", "demo",
        "--contract-type", "分包",
        "--pdf", str(pdf),
        "--output-dir", str(out_dir),
    ])
    assert rc == 0

    state = json.loads((out_dir / "review_state.json").read_text(encoding="utf-8"))
    assert state["project_name"] == "demo"
    assert len(state["contracts"]) == 1
    contract = state["contracts"][0]
    assert contract["contract_id"] == "c001"
    assert contract["contract_type"] == "分包"
    assert contract["contract_file"] == "contract.pdf"
    assert contract["contract_path"].endswith("contract.pdf")
    # route 全删：不再有 pages 数组 / total_pages
    assert "pages" not in contract
    assert "total_pages" not in contract
    # 下游阶段占位字段
    assert contract["ocr"] is None
    assert contract["text_extraction"] is None


def test_prepare_rejects_missing_pdf(tmp_path: Path) -> None:
    from prepare_review import main

    rc = main([
        "--pdf", str(tmp_path / "nope.pdf"),
        "--output-dir", str(tmp_path / "out"),
    ])
    assert rc != 0
