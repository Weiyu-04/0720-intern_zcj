"""ocr phase now points at the original contract PDF (no subset)."""
from __future__ import annotations

import json
from pathlib import Path


def _state_with_contract(tmp_path: Path) -> tuple[Path, dict]:
    state_path = tmp_path / "state.json"
    state = {
        "schema_version": 1,
        "project_name": "t",
        "output_dir": str(tmp_path),
        "contracts": [
            {
                "contract_id": "c001",
                "contract_file": "x.pdf",
                "contract_path": "/abs/path/x.pdf",
                "contract_type": "分包",
                "ocr": None,
                "text_extraction": None,
                "ledger": None,
                "validation": None,
            }
        ],
    }
    return state_path, state


def test_next_batch_ocr_points_at_original_pdf(tmp_path: Path) -> None:
    from advance_review import next_batch
    state_path, state = _state_with_contract(tmp_path)
    result = next_batch(state_path, state, limit=8)
    assert result["action"] == "batch"
    assert result["phase"] == "ocr"
    item = result["items"][0]
    assert item["action"] == "ocr"
    assert item["contract_id"] == "c001"
    assert item["pdf_path"] == "/abs/path/x.pdf"  # 原 PDF，非子集
    assert "ordered_indices" not in item


def test_apply_ocr_no_longer_sets_ordered_indices(tmp_path: Path) -> None:
    from advance_review import _apply_result
    state_path, state = _state_with_contract(tmp_path)
    _apply_result(
        state,
        action="ocr",
        contract_id="c001",
        data={"raw_response": "Parsed. Markdown written to /o/x.md.\nPage-level layout written to /o/x_middle.json."},
    )
    ocr = state["contracts"][0]["ocr"]
    assert "ordered_indices" not in ocr
    assert ocr["markdown_path"].endswith("x.md")
    assert ocr["middle_path"].endswith("x_middle.json")


def test_apply_route_branch_removed(tmp_path: Path) -> None:
    """route 分支已删，submit route 应抛 unknown/ValueError 而非静默接受。"""
    from advance_review import _apply_result
    state_path, state = _state_with_contract(tmp_path)
    try:
        _apply_result(state, action="route", contract_id="c001", data={"answers": []})
    except (ValueError, KeyError):
        return
    raise AssertionError("route 分支应已删除（应抛 ValueError）")
