"""_contract_facts / _synthesize_fragments only read text_extraction (no page fallback)."""
from __future__ import annotations


def _contract(text_extraction_clauses):
    return {
        "contract_id": "c001",
        "text_extraction": {"clauses": text_extraction_clauses, "error": ""},
    }


def test_contract_facts_reads_text_extraction_only():
    from advance_review import _contract_facts
    clauses = [{"clause_locator": "（第1页）a"}, {"clause_locator": "（第2页）b"}]
    facts = _contract_facts(_contract(clauses))
    assert facts == [{"clause_locator": "（第1页）a"}, {"clause_locator": "（第2页）b"}]


def test_contract_facts_empty_when_no_text_extraction():
    from advance_review import _contract_facts
    assert _contract_facts({"contract_id": "c001", "text_extraction": None}) == []


def test_synthesize_fragments_adds_global_idx():
    from advance_review import _synthesize_fragments
    clauses = [{"clause_locator": "a"}, {"clause_locator": "b"}, {"clause_locator": "c"}]
    frags = _synthesize_fragments(_contract(clauses))
    assert [f["_idx"] for f in frags] == [0, 1, 2]
    assert all("clause_locator" in f for f in frags)
