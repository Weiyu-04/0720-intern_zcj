"""_extract_chunks splits per-page markdown into 6-page chunks, text on disk."""
from __future__ import annotations

from pathlib import Path
from unittest import mock


def _contract_with_ocr(tmp_path: Path, middle_path: str) -> dict:
    return {
        "contract_id": "c001",
        "contract_file": "x.pdf",
        "contract_path": "/abs/x.pdf",
        "contract_type": "分包",
        "ocr": {"markdown_path": "", "middle_path": middle_path, "raw_response": "", "error": ""},
        "text_extraction": None,
    }


def test_extract_chunks_6_6_1(tmp_path: Path) -> None:
    from advance_review import _extract_chunks
    state = {"output_dir": str(tmp_path), "contracts": []}
    contract = _contract_with_ocr(tmp_path, "/fake/x_middle.json")
    # 13 页
    fake_pages = [(i, f"PAGE {i} content") for i in range(13)]
    with mock.patch("advance_review._load_pages_from_middle", return_value=fake_pages):
        chunks = _extract_chunks(tmp_path / "state.json", state, contract)
    assert len(chunks) == 3
    assert [len(c["page_indices"]) for c in chunks] == [6, 6, 1]
    assert chunks[0]["page_indices"] == [0, 1, 2, 3, 4, 5]
    assert chunks[2]["page_indices"] == [12]
    # chunk_index 稳定
    assert [c["chunk_index"] for c in chunks] == [0, 1, 2]
    # text 落盘到单独文件，path 存在
    for c in chunks:
        assert c["path"].endswith(".md")
        assert Path(c["path"]).is_file()


def test_extract_chunks_page_header_is_physical_page(tmp_path: Path) -> None:
    from advance_review import _extract_chunks
    state = {"output_dir": str(tmp_path), "contracts": []}
    contract = _contract_with_ocr(tmp_path, "/fake/x_middle.json")
    fake_pages = [(0, "AAA"), (1, "BBB")]
    with mock.patch("advance_review._load_pages_from_middle", return_value=fake_pages):
        chunks = _extract_chunks(tmp_path / "state.json", state, contract)
    text = Path(chunks[0]["path"]).read_text(encoding="utf-8")
    # page_idx 0 → 物理页 1；page_idx 1 → 物理页 2
    assert "## 第 1 页" in text
    assert "AAA" in text
    assert "## 第 2 页" in text
    assert "BBB" in text


def test_extract_chunks_cached(tmp_path: Path) -> None:
    from advance_review import _extract_chunks
    state = {"output_dir": str(tmp_path), "contracts": []}
    contract = _contract_with_ocr(tmp_path, "/fake/x_middle.json")
    fake_pages = [(0, "A"), (1, "B")]
    with mock.patch("advance_review._load_pages_from_middle", return_value=fake_pages):
        first = _extract_chunks(tmp_path / "state.json", state, contract)
        second = _extract_chunks(tmp_path / "state.json", state, contract)
    assert first is second  # 同一缓存对象
    assert "extract_chunks" in contract


def test_extract_chunks_empty_when_no_pages(tmp_path: Path) -> None:
    from advance_review import _extract_chunks
    state = {"output_dir": str(tmp_path), "contracts": []}
    contract = _contract_with_ocr(tmp_path, "/fake/x_middle.json")
    with mock.patch("advance_review._load_pages_from_middle", return_value=[]):
        chunks = _extract_chunks(tmp_path / "state.json", state, contract)
    assert chunks == []


def test_extract_chunks_does_not_cache_empty_result(tmp_path: Path) -> None:
    """真空结果（pages=[]）不得缓存 —— 否则一次空判定会让该合同的提取阶段永久卡死。

    方案1：空 chunks 不写入 contract['extract_chunks']，下一轮 next_batch 才会重新计算。
    """
    from advance_review import _extract_chunks

    state = {"output_dir": str(tmp_path), "contracts": []}
    contract = _contract_with_ocr(tmp_path, "/fake/x_middle.json")
    with mock.patch("advance_review._load_pages_from_middle", return_value=[]):
        chunks = _extract_chunks(tmp_path / "state.json", state, contract)
    assert chunks == []
    assert "extract_chunks" not in contract  # 空结果不缓存 → 下轮重新计算


def test_extract_chunks_propagates_not_ready_without_caching(tmp_path: Path) -> None:
    """文件未就绪（MiddleNotReadyError）时向上抛出且不缓存，允许下一轮重试。"""
    import pytest
    from advance_review import _extract_chunks, MiddleNotReadyError

    state = {"output_dir": str(tmp_path), "contracts": []}
    contract = _contract_with_ocr(tmp_path, str(tmp_path / "missing_middle.json"))
    with mock.patch("advance_review._load_pages_from_middle", side_effect=MiddleNotReadyError("not ready")):
        with pytest.raises(MiddleNotReadyError):
            _extract_chunks(tmp_path / "state.json", state, contract)
    assert "extract_chunks" not in contract


def test_next_batch_waits_and_resumes_when_middle_not_ready(tmp_path: Path) -> None:
    """端到端回归：middle.json 未就绪时 next_batch 不得判死 text_extraction、
    不得缓存空 extract_chunks、不得提前把 ledger 判空；文件就绪后同一 state 正常产出 extract_text。

    复现线上卡死：OCR 提交后 next_batch 立即运行，parse_document 产物尚未落盘 →
    旧逻辑静默返回 [] 并缓存，text_extraction 被打成 {'error': 'no pages...'} 永久卡死。
    """
    import json as _json
    from advance_review import next_batch, _save_state

    middle_path = tmp_path / "x_middle.json"
    contract = {
        "contract_id": "c001",
        "contract_file": "x.pdf",
        "contract_path": "/abs/x.pdf",
        "contract_type": "分包",
        "ocr": {"markdown_path": "", "middle_path": str(middle_path), "raw_response": "", "error": ""},
        "text_extraction": None,
    }
    state = {"schema_version": 1, "project_name": "t", "output_dir": str(tmp_path), "contracts": [contract]}
    state_path = tmp_path / "review_state.json"
    _save_state(state_path, state)

    def fake_make(page_list, image_dir):
        return f"MD page {page_list[0]['page_idx']}"

    # 第一次：middle.json 尚未落盘 → 未就绪，state 不得被污染
    with mock.patch("advance_review._get_union_make", return_value=fake_make):
        first = next_batch(state_path, state, limit=8)
    assert contract.get("text_extraction") is None       # 没被打成错误 dict
    assert "extract_chunks" not in contract               # 没缓存空结果
    assert contract.get("ledger") is None                 # 没提前判空 ledger
    assert first["action"] == "wait"                      # 等待重试，而非 stop（完成）

    # 第二次：middle.json 就绪 → 正常产出 extract_text
    middle_path.write_text(
        _json.dumps({"_backend": "vlm", "pdf_info": [{"page_idx": 0, "blocks": ["b0"]}]}),
        encoding="utf-8",
    )
    with mock.patch("advance_review._get_union_make", return_value=fake_make):
        second = next_batch(state_path, state, limit=8)
    assert second["action"] == "batch"
    assert second["phase"] == "extract_text"
    assert second["items"][0]["chunk_index"] == 0


def test_next_batch_waits_when_middle_written_halfway(tmp_path: Path) -> None:
    """端到端回归（用户线上卡死时序）：OCR 提交后 middle.json 已写下 _backend 但
    pdf_info 尚未写入、同名 .md 也未落盘。next_batch 不得把 text_extraction 永久判死，
    必须返回 wait；待 pdf_info 写入后同一 state 正常产出 extract_text。

    锁定 _load_pages_from_middle「middle 存在但不可重建 + .md 不可用 → MiddleNotReadyError」
    与 next_batch「MiddleNotReadyError → wait 不判死」的端到端联动（区别于上方「middle 完全不存在」用例）。
    """
    import json as _json
    from advance_review import next_batch, _save_state

    middle_path = tmp_path / "x_middle.json"
    # 写一半：只有 _backend，无 pdf_info；无同名 .md
    middle_path.write_text(_json.dumps({"_backend": "vlm"}), encoding="utf-8")

    contract = {
        "contract_id": "c001",
        "contract_file": "x.pdf",
        "contract_path": "/abs/x.pdf",
        "contract_type": "分包",
        "ocr": {"markdown_path": "", "middle_path": str(middle_path), "raw_response": "", "error": ""},
        "text_extraction": None,
    }
    state = {"schema_version": 1, "project_name": "t", "output_dir": str(tmp_path), "contracts": [contract]}
    state_path = tmp_path / "review_state.json"
    _save_state(state_path, state)

    def fake_make(page_list, image_dir):
        return f"MD page {page_list[0]['page_idx']}"

    # 写一半状态：未就绪，state 不得被污染、不得判死
    with mock.patch("advance_review._get_union_make", return_value=fake_make):
        first = next_batch(state_path, state, limit=8)
    assert contract.get("text_extraction") is None
    assert "extract_chunks" not in contract
    assert first["action"] == "wait"

    # pdf_info 写入（落盘完成）→ 正常产出 extract_text
    middle_path.write_text(
        _json.dumps({"_backend": "vlm", "pdf_info": [{"page_idx": 0, "blocks": ["b0"]}]}),
        encoding="utf-8",
    )
    with mock.patch("advance_review._get_union_make", return_value=fake_make):
        second = next_batch(state_path, state, limit=8)
    assert second["action"] == "batch"
    assert second["phase"] == "extract_text"
    assert second["items"][0]["chunk_index"] == 0
