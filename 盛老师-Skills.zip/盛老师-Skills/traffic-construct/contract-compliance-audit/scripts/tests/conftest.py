"""Make skill scripts importable in tests (advance_review + app.*).

pytest 自动加载本文件；把 scripts/ 插入 sys.path 前端，使
``import advance_review`` 与 ``from app.rulebook import ...`` 可解析。
advance_review 顶部仅依赖标准库 + 纯 Python 的 app.* 模块，
prepare_review 测试用 fitz 造 PDF fixture（backend uv 环境已装）；
advance_review 内的 fitz/PIL/mineru 均为函数内 lazy import，普通状态机测试不会触发。
"""
import sys
from pathlib import Path

_SCRIPTS_DIR = Path(__file__).resolve().parent.parent
if str(_SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS_DIR))
