"""extract_text phase: next_batch emits per-chunk items, _apply_result accumulates."""
from __future__ import annotations

from pathlib import Path
from unittest import mock


def _contract_with_chunks(tmp_path: Path, n_chunks: int) -> dict:
    """构造一个 ocr 已完成、text_extraction=None、extract_chunks 已预置的合同。"""
    chunks = []
    text_tasks = tmp_path / "text_tasks"
    text_tasks.mkdir(parents=True, exist_ok=True)
    for ci in range(n_chunks):
        p = text_tasks / f"c001_extract_chunk_{ci:03d}.md"
        p.write_text(f"## 第 {ci + 1} 页\n\nPAGE {ci}", encoding="utf-8")
        chunks.append({"chunk_index": ci, "page_indices": [ci], "path": str(p)})
    return {
        "contract_id": "c001",
        "contract_file": "x.pdf",
        "contract_path": "/abs/x.pdf",
        "contract_type": "分包",
        "ocr": {"markdown_path": "", "middle_path": "/abs/x_middle.json", "raw_response": "", "error": ""},
        "text_extraction": None,
        "extract_chunks": chunks,
    }


def _state(tmp_path: Path, contract: dict) -> tuple[Path, dict]:
    return tmp_path / "state.json", {
        "schema_version": 1,
        "project_name": "t",
        "output_dir": str(tmp_path),
        "contracts": [contract],
    }


def test_next_batch_extract_returns_first_chunk(tmp_path: Path) -> None:
    from advance_review import next_batch
    state_path, state = _state(tmp_path, _contract_with_chunks(tmp_path, 3))
    with mock.patch("advance_review._load_pages_from_middle", return_value=[]):  # 不应重算
        result = next_batch(state_path, state, limit=8)
    assert result["action"] == "batch"
    assert result["phase"] == "extract_text"
    item = result["items"][0]
    assert item["action"] == "extract_text"
    assert item["chunk_index"] == 0
    assert item["chunk_total"] == 3
    assert item["payload_path"]


def test_apply_extract_accumulates_until_all_chunks_done(tmp_path: Path) -> None:
    from advance_review import _apply_result
    state_path, state = _state(tmp_path, _contract_with_chunks(tmp_path, 3))
    contract = state["contracts"][0]
    # chunk 0
    _apply_result(state, action="extract_text", contract_id="c001", chunk_index=0,
                  data={"clauses": [{"clause_locator": "（第1页）a"}]})
    assert contract["text_extraction"] is None  # 未全部完成
    # chunk 1
    _apply_result(state, action="extract_text", contract_id="c001", chunk_index=1,
                  data={"clauses": [{"clause_locator": "（第2页）b"}]})
    assert contract["text_extraction"] is None
    # chunk 2 → finalize
    _apply_result(state, action="extract_text", contract_id="c001", chunk_index=2,
                  data={"clauses": [{"clause_locator": "（第3页）c"}]})
    te = contract["text_extraction"]
    assert te is not None
    assert len(te["clauses"]) == 3
    assert te["clauses"][0]["clause_locator"] == "（第1页）a"
    assert te["clauses"][2]["clause_locator"] == "（第3页）c"


def test_apply_extract_fifo_when_chunk_index_missing(tmp_path: Path) -> None:
    from advance_review import _apply_result
    state_path, state = _state(tmp_path, _contract_with_chunks(tmp_path, 2))
    contract = state["contracts"][0]
    _apply_result(state, action="extract_text", contract_id="c001", chunk_index=None,
                  data={"clauses": [{"clause_locator": "x"}]})
    # chunk_index=None → FIFO 消费 chunk 0
    assert 0 in contract["extract_chunk_done"]
    assert contract["text_extraction"] is None


def test_next_batch_skips_done_chunks(tmp_path: Path) -> None:
    from advance_review import next_batch
    contract = _contract_with_chunks(tmp_path, 3)
    contract["extract_chunk_done"] = [0, 1]
    state_path, state = _state(tmp_path, contract)
    result = next_batch(state_path, state, limit=8)
    item = result["items"][0]
    assert item["chunk_index"] == 2  # 只剩 chunk 2


def test_apply_extract_idempotent_on_resubmit(tmp_path: Path) -> None:
    """Re-submitting an already-done chunk must not double-count its clauses."""
    from advance_review import _apply_result
    state_path, state = _state(tmp_path, _contract_with_chunks(tmp_path, 2))
    contract = state["contracts"][0]
    # chunk 0 first submit
    _apply_result(state, action="extract_text", contract_id="c001", chunk_index=0,
                  data={"clauses": [{"clause_locator": "a"}]})
    # chunk 0 re-submit (e.g. retry) — must NOT duplicate
    _apply_result(state, action="extract_text", contract_id="c001", chunk_index=0,
                  data={"clauses": [{"clause_locator": "a"}]})
    # chunk 1 → finalize
    _apply_result(state, action="extract_text", contract_id="c001", chunk_index=1,
                  data={"clauses": [{"clause_locator": "b"}]})
    te = contract["text_extraction"]
    assert te is not None
    assert len(te["clauses"]) == 2  # a + b，不是 a + a + b
    assert te["clauses"][0]["clause_locator"] == "a"
    assert te["clauses"][1]["clause_locator"] == "b"


def test_next_batch_extract_emits_all_pending_chunks(tmp_path: Path) -> None:
    """limit 够大时，extract_text 一次 emit 该合同全部 pending chunk（而非只 pending[0]）。"""
    from advance_review import next_batch
    state_path, state = _state(tmp_path, _contract_with_chunks(tmp_path, 3))
    with mock.patch("advance_review._load_pages_from_middle", return_value=[]):  # 已预置 extract_chunks，不应重算
        result = next_batch(state_path, state, limit=8)
    assert result["action"] == "batch"
    assert result["phase"] == "extract_text"
    assert len(result["items"]) == 3
    assert [it["chunk_index"] for it in result["items"]] == [0, 1, 2]


def test_next_batch_extract_respects_limit(tmp_path: Path) -> None:
    """pending 多于 limit 时，本轮只 emit limit 个，剩余下轮。"""
    from advance_review import next_batch
    state_path, state = _state(tmp_path, _contract_with_chunks(tmp_path, 5))
    with mock.patch("advance_review._load_pages_from_middle", return_value=[]):
        result = next_batch(state_path, state, limit=2)
    assert result["action"] == "batch"
    assert len(result["items"]) == 2
    assert [it["chunk_index"] for it in result["items"]] == [0, 1]
