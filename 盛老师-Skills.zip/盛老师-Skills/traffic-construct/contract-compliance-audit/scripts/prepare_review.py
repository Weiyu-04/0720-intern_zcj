"""Collect contract PDFs and initialize review_state.json (no page-image rendering)."""

from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any


def _safe_name(text: str, fallback: str = "contract") -> str:
    text = re.sub(r'[<>:"/\\|?*\s]+', "_", text).strip("._")
    return (text or fallback)[:80]


def _path_for_json(path: Path) -> str:
    value = str(path)
    if value.startswith("/mnt/"):
        return path.as_posix()
    return value


def _collect_pdfs(pdfs: list[str], dirs: list[str]) -> list[Path]:
    out: list[Path] = [Path(p) for p in pdfs or []]
    for d in dirs or []:
        base = Path(d)
        out.extend(sorted(base.rglob("*.pdf")))
        out.extend(sorted(base.rglob("*.PDF")))
    seen: set[Path] = set()
    unique: list[Path] = []
    for item in out:
        resolved = item.resolve()
        if resolved not in seen:
            unique.append(item)
            seen.add(resolved)
    return unique


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Collect contract PDFs into review_state.json.")
    parser.add_argument("--project", default="")
    parser.add_argument("--contract-type", default="分包", choices=["总包", "分包"])
    parser.add_argument("--pdf", action="append", default=[])
    parser.add_argument("--dir", action="append", default=[])
    parser.add_argument("--output-dir", default="outputs/contract_compliance_audit")
    return parser.parse_args()


def main(argv: list[str] | None = None) -> int:
    if argv is not None:
        sys.argv = [sys.argv[0], *argv]
    args = parse_args()
    pdfs = _collect_pdfs(args.pdf, args.dir)
    if not pdfs:
        print("[ERROR] 未指定任何 PDF（--pdf 或 --dir）", file=sys.stderr)
        return 2
    for pdf in pdfs:
        if not pdf.is_file():
            print(f"[ERROR] PDF 不存在: {pdf}", file=sys.stderr)
            return 2

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    state_path = out_dir / "review_state.json"

    contracts: list[dict[str, Any]] = []
    for idx, pdf in enumerate(pdfs, 1):
        contracts.append({
            "contract_id": f"c{idx:03d}",
            "contract_file": pdf.name,
            "contract_path": str(pdf.resolve()),
            "contract_type": args.contract_type,
            "ocr": None,
            "text_extraction": None,
            "ledger": None,
            "validation": None,
        })

    state = {
        "schema_version": 1,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "project_name": args.project,
        "output_dir": _path_for_json(out_dir.resolve()),
        "contracts": contracts,
    }
    state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"state": _path_for_json(state_path.resolve()), "contracts": len(contracts)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
