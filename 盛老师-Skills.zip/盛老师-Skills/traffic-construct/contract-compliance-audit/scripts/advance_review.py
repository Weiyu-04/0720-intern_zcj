"""State machine for Agent-driven contract compliance review."""

from __future__ import annotations

import argparse
import json
import logging
import re
import sys
from pathlib import Path
from typing import Any, Callable

from app.rulebook import get_rulebook
from app import synthesizer as _synth
from app import deduplicator as _dedup

logger = logging.getLogger(__name__)


class MiddleNotReadyError(RuntimeError):
    """_middle.json / 同名 .md 尚未落盘 —— 视为瞬时，调用方应重试而非判定为空。

    OCR 提交后 next_batch 立即运行时，parse_document 的页级产物可能尚未写盘；
    此时若静默返回 []，空结果会被 _extract_chunks 缓存，永久卡死该合同的提取阶段。
    """


# —— Prompts：逐字移植自原项目（已验证）的 text_extractor / compliance_validator
# 输入介质：extract_text 走 MinerU OCR 文本（对应原项目 TextExtractor），判定逻辑保持一致。

# —— Validator（移植自 compliance_validator）：漏斗式四步决策树 + 写作规范
VALIDATOR_SYSTEM_PROMPT = """你是一名严谨的工程合同合规审查律师，专精《公路工程施工分包负面清单（2024 年版）》。

【合规推理决策树算法（强制执行剪枝逻辑 — CRITICAL）】
对【每一个施工事实（clause）】 × 【系统已为该 clause 预筛过的候选规则】两两组合执行漏斗式审查：

第一步 Domain（大类）：
  - 取事实的 domain_classification（或 engineering_category）vs 规则的 prerequisite.domain；
  - 不一致（如事实属"桥梁工程"，规则属"隧道工程"）→ 立刻短路跳过，禁止跨主体执法；
  - 若事实标签缺失/"其他"，但 scope_text 中亦未出现该规则 keywords 任一项 → 同样短路跳过。

第二步 Prerequisite（前提条件）：
  - 检查规则 prerequisite.positions 与事实的 structural_position：
    若规则管辖的是"上部承重结构"，而事实标明是"基础工程"/"桥面系"，立刻短路跳过；
  - 检查规则 prerequisite.methods（桥型/工法）：
    若事实未涉及该桥型/工法（scope_text 中无对应用语，参数中也无对应描述）→ 短路跳过。

第三步 Exclusion（豁免条款）：
  - 检查规则 exclusions 列表（如"钢结构制作"、"运输"、"外购梁预制"、"管片预制"、"爆破"、"二衬"、"出碴运输"、"瓦斯抽排"、"基槽开挖"、"回填"、"浮运"等）；
  - 若事实的作业内容【完全落在豁免范围内】（例如承包内容仅为"钢结构加工制作 + 运输"、"管片预制"），
    或合同明确写"甲供"/"外购"等转移性表述 → 立刻判定为合规（不输出 finding，亦不再走第四步）。

第四步 Threshold（阈值）：
  - 仅当前三步全部通过时，才允许比对 prerequisite + thresholds 的数值约束：
    * 参数明确达到或超过阈值（如水深≥10m、跨度≥55m、单体≥200t 等）→ severity = high；
    * 关键工法用语已出现但缺少阈值参数 → severity = medium（参数缺失型预警）；
    * 参数明确低于阈值，或合同未涉及该工法 → 不输出 finding。
  - 任何判定违规的 finding 都必须给出确凿的【依据条款】（reference_rule_ids + reference_clause）。
    无明确规则依据者，禁止输出"中/高风险"警报，整条 finding 必须丢弃。

【无罪推定 / 有据必引】
1. 禁止"通常涉及""可能暗含""文档性风险""无法排除重叠"等无规则支撑的笼统结论。
2. 每条 finding 必须双证据：
   (a) 合同证据：clause_locator、original_quote 须逐字来自该 clause 的台账字段；
   (b) 规则证据：reference_rule_ids 非空且均存在于规则库；reference_clause 非空。
3. 一律不得对纯管理/行政条款输出 finding。

【clause_locator 与 original_quote 精准引用约束（CRITICAL）】
  - 当一条事实含多条证据编号（如 (1)(2)...(N)）时，original_quote 只【逐字复制】直接触发本条违规的那1~2条证据文本，最多3条；
  - clause_locator 同理，只列出触发本条违规的那1~2条 evidence 位置标注（保留原编号 (n) 与页码）；
  - 被选中的 evidence 必须原文逐字照抄，严禁改写、概括、翻译；
  - 严禁跨不同事实（不同 clause）合并 locator/quote；
  - 同一事实命中多条规则可输出多条 findings，或一条 finding 中 reference_rule_ids 列多条规则。

【risk_explanation 写作规范（面向用户，不暴露内部实现）】
风险说明是给业主/审查员看的合规结论，绝对不能出现以下"工程内部用语"：
  - 严禁出现英文词："Domain / Prerequisite / Exclusion / Threshold / Funnel / clause × rule" 等；
  - 严禁出现"第1步漏斗 / 第2步漏斗 / 漏斗审查 / 决策树"等内部流程术语；
  - 严禁出现规则编号字面值："BRIDGE-1-3-8 / TUNNEL-2-2"等 rule_id（rule_id 只放在 reference_rule_ids 字段里）；
  - 严禁出现"已通过第X步"等过程式叙述。
正确写法：全部使用中文，引用依据时使用规则的 quote 原文 / 章节序号（如『一、桥梁工程（三）8』），不要用 rule_id；直接给出"是否构成违规 / 风险点 / 建议核实事项"。"""

VALIDATOR_SCHEMA_HINT = """输出 JSON 结构：
{
  "findings": [
    {
      "clause_locator": "逐字复制本批次某一事实条目的 clause_locator（含 (1)(2)(3) 编号与换行）",
      "original_quote": "逐字复制本批次同一事实条目的 scope_text（含 (1)(2)(3) 编号与换行）",
      "risk_explanation": "面向用户的中文合规结论，引用《负面清单》章节序号与原文；禁止英文词、禁止 rule_id、禁止『漏斗/Domain/Prerequisite/Exclusion/Threshold/第X步』等内部术语。",
      "reference_rule_ids": ["BRIDGE-1-3-8"],
      "reference_clause": "可留空，系统会自动按 rule_ids 取规则 quote 回填；如填写须与规则库 quote 一致",
      "severity": "high | medium | low"
    }
  ]
}
硬性要求：
- 每条 finding 的 reference_rule_ids 非空且均在规则库中存在；
- 若无任何可证违规，返回 {"findings": []}；
- 凡未通过前三步漏斗的 (clause × rule) 组合，绝不允许出现在输出里。"""


# —— risk_explanation 落库清洗（移植自 compliance_validator）：剔除内部术语 / rule_id
_FORBIDDEN_LINE_PATTERNS = [
    re.compile(r"(?:Domain|Prerequisite|Exclusion|Threshold|Funnel)", re.IGNORECASE),
    re.compile(r"漏斗"),
    re.compile(r"决策树"),
    re.compile(r"已?通过第\s*[0-9一二三四]+\s*[-~至到]?\s*[0-9一二三四]*\s*步"),
    re.compile(r"第\s*[0-9一二三四]+\s*步\s*[（(]?"),
]
_RULE_ID_RE = re.compile(r"(?:BRIDGE|TUNNEL|ROAD)-[0-9]+(?:-[0-9A-Za-z]+)*")
_BULLET_PREFIX_RE = re.compile(r"^\s*(?:[0-9一二三四五六七八九十]+\s*[\.、)]|[（(][0-9一二三四五六七八九十]+[）)])\s*")


def _load_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def _save_state(path: str | Path, state: dict[str, Any]) -> None:
    target = Path(path)
    tmp = target.with_suffix(target.suffix + ".tmp")
    tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(target)


def _path_for_json(path: Path) -> str:
    value = str(path)
    if value.startswith("/mnt/"):
        return path.as_posix()
    return value


def _truncate(text: str, limit: int = 60) -> str:
    """截断长文本用于 funnel_prefilter 展示（保留线索，避免 payload 膨胀）。"""
    text = text or ""
    return text[:limit] + ("..." if len(text) > limit else "")


def _normalize_extraction(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict):
        return {"clauses": [], "error": "extraction result is not a JSON object", "raw_response": str(data)}
    clauses = data.get("clauses")
    if not isinstance(clauses, list):
        clauses = []
    return {"clauses": [c for c in clauses if isinstance(c, dict)], "error": str(data.get("error") or "")}


TEXT_EXTRACT_PROMPT = """你是一名只会客观抄录事实的工程合同文本解析器。输入是某页合同的 OCR 文本（已含表格 markdown）。严格遵守：

【只提取什么】
仅提取与「工程实体施工」直接相关的条款，必须属于以下之一：
  - 分包/承包范围、工作内容、工程量清单、技术规格、施工方法/工法
  - 桥梁/隧道/桩基/围堰/沉井/支架/顶推等具体工程描述
  - 可量化的施工参数（高、深、长、跨径、重量、水深、桩径、数量等）

【主语义判定原则（最高优先级）】
提取任何一句前，先判断该句【主语义】：
  → 回答「这个分包单位要做什么工程实体」：✅ 可提取
  → 回答「什么情况下付多少钱/什么时候验收/谁来管理」：❌ 禁止提取，即使含工程词
口诀：把这句话去掉，合规审查员能否少了解某项施工内容/参数？能→提取；否则（条件/程序/义务）→不提取。

【明确排除 — 一律不得写入 clauses】
  - 质量管理、验收标准、资料归档、施工报表
  - 保险、税费、付款方式、违约金、结算条件、进度款支付比例
  - 验收程序、验收合格后触发的任何条款
  - 争议解决、保密、违约责任、通知送达
  - 纯程序性表述：「按图纸施工」「配合甲方」而无具体工程内容
  - 琐碎材料消耗条目（吨/立方米/平方米单位的钢筋水泥）

【工程常识推断与标签化（CRITICAL）】
抄录原文（clause_locator / scope_text / parameters）必须逐字取自输入文本，不可篡改。
同时独立推断两个标签填入 JSON：
  - domain_classification（工程大类）：桥梁工程 / 隧道工程 / 路基路面 / 其他
  - structural_position（空间部位）：基础工程 / 下部结构 / 上部承重结构 / 桥面系 / 附属工程 / 隧道主体 / 隧道斜井 / 隧道竖井 / 不适用
推断范例：承台/沉井/桩基→基础工程；墩柱/盖梁→下部结构；箱梁/顶推/拱肋→上部承重结构；盾构/TBM/沉管→隧道主体。
推断仅用于打标签，绝不可写入 scope_text 或 clause_locator。

【页码锚定】
系统已在输入中给出「第N页」（物理页码）。clause_locator 必须以「（第N页）」锚定该真实页码；
若该页无章节号，如实写「无明确标题段落（第N页）」。严禁脑补父级章节号。

【其他规则】
1. 禁止任何合规判断或法规引用。
2. 该页无任何工程承包范围/工作内容/技术参数 → 返回 {"clauses": []}。
3. 参数缺失 → 写 null，禁止编造数字。
4. 输出必须是【严格 JSON】，禁止 Markdown 围栏、注释、多余文字、逐步推理过程与解释；读完直接一次成型输出 JSON。"""


TEXT_EXTRACT_SCHEMA = """输出 JSON 必须严格符合：
{
  "clauses": [
    {
      "clause_locator": "条款位置（锚定物理页码），例：『工程量清单 序号3（第47页）』或『无明确标题段落（第55页）』",
      "scope_text": "承包范围 / 工作内容原文摘录（逐字取自输入，包含数字和单位）",
      "engineering_category": "桥梁 | 隧道 | 路基路面 | 其他 | null",
      "domain_classification": "桥梁工程 | 隧道工程 | 路基路面 | 其他",
      "structural_position": "基础工程 | 下部结构 | 上部承重结构 | 桥面系 | 附属工程 | 隧道主体 | 隧道斜井 | 隧道竖井 | 不适用",
      "parameters": [
        {"name": "参数名", "value": "数值或原文描述，缺失填 null", "unit": "单位或 null", "raw_quote": "原文片段"}
      ],
      "is_generic": true,
      "notes": "备注或 null"
    }
  ]
}
is_generic：true=条款仅笼统工程门类、无具体参数；false=有具体参数或明确施工内容（客观标签，不构成违规）。
domain_classification / structural_position 为推断标签，不可写入 scope_text；判断不出填「其他」/「不适用」。"""


_MD_PATH_RE = re.compile(r"(/[^\s]+\.md|[A-Za-z]:\\[^\r\n]+?\.md)", re.IGNORECASE)
# parse_document 成功时会在返回串里写 "Page-level layout written to {stem}_middle.json"，
# 该 middle.json 含 pdf_info[].page_idx（MinerU 页级布局），是 extract_text 精确锚定页码的依据。
_MIDDLE_PATH_RE = re.compile(r"(/[^\s]+_middle\.json|[A-Za-z]:\\[^\r\n]+?_middle\.json)", re.IGNORECASE)


def _normalize_ocr_result(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict):
        raw = str(data or "")
        md_match = _MD_PATH_RE.search(raw)
        mid_match = _MIDDLE_PATH_RE.search(raw)
        return {
            "raw_response": raw,
            "markdown_path": md_match.group(1) if md_match else "",
            "markdown_text": "",
            "middle_path": mid_match.group(1) if mid_match else "",
            "error": "",
        }
    raw = str(data.get("raw_response") or data.get("result") or data.get("text") or data.get("content") or "")
    markdown_text = str(data.get("markdown_text") or data.get("markdown") or data.get("content") or "")
    markdown_path = str(
        data.get("markdown_path")
        or data.get("markdown_file")
        or data.get("output_path")
        or data.get("path")
        or ""
    )
    if not markdown_path:
        match = _MD_PATH_RE.search(raw)
        markdown_path = match.group(1) if match else ""
    middle_path = str(data.get("middle_path") or data.get("middle_file") or "")
    if not middle_path:
        mid_match = _MIDDLE_PATH_RE.search(raw)
        middle_path = mid_match.group(1) if mid_match else ""
    return {
        "raw_response": raw,
        "markdown_path": markdown_path,
        "markdown_text": markdown_text,
        "middle_path": middle_path,
        "error": str(data.get("error") or ""),
    }


def _get_union_make(middle: dict[str, Any]) -> Callable[[list[dict[str, Any]], str], str]:
    """按 middle._backend 选 MinerU 的 union_make（pipeline / vlm），返回 MM_MD 渲染器。

    与 contract-amount-manager-audit/scripts/prepare_contracts.py 同源。
    mineru SDK 在 skill 脚本环境可用（amount-manager 已验证）。
    """
    from mineru.utils.enum_class import MakeMode

    backend = str(middle.get("_backend") or "vlm").lower()
    if backend == "pipeline":
        from mineru.backend.pipeline.pipeline_middle_json_mkcontent import union_make
    else:
        from mineru.backend.vlm.vlm_middle_json_mkcontent import union_make
    return lambda page_list, image_dir: union_make(page_list, MakeMode.MM_MD, image_dir)


def _load_pages_from_middle(middle_path: str) -> list[tuple[int, str]]:
    """读 _middle.json，用 MinerU 官方 union_make 逐页渲染 markdown。

    返回 [(page_idx, page_markdown), ...]，按 page_idx 升序；表格 markdown 原样保留。
    middle.json 缺失/无 pdf_info/解析异常时回退同名 .md：
      - .md 存在且非空 → 回退 [(0, full_md)]；
      - .md 不存在/为空、或两个产物均不存在 → 抛 MiddleNotReadyError（视为产物尚未就绪，调用方重试）。
    绝不静默返回 [] —— 否则空结果会被 next_batch 当成「真空」把 text_extraction 永久判死。
    """
    path = Path(middle_path)
    md_stem = path.name[: -len("_middle.json")] if path.name.endswith("_middle.json") else path.stem
    md_path = path.parent / f"{md_stem}.md"
    # 两个产物都不在：多半是 parse_document 尚未落盘（OCR 提交后 next_batch 立即调用的竞态）。
    # 视为瞬时未就绪并抛错让上层重试 —— 绝不静默返回 []，否则空结果会被 _extract_chunks 缓存。
    if not path.is_file() and not md_path.is_file():
        raise MiddleNotReadyError(f"{middle_path} 及同名 .md 均不存在，疑似尚未落盘")
    try:
        middle = json.loads(path.read_text(encoding="utf-8-sig"))
        pdf_info = middle.get("pdf_info") if isinstance(middle, dict) else None
        if not isinstance(pdf_info, list) or not pdf_info:
            raise ValueError("missing pdf_info")
        make = _get_union_make(middle)
        image_dir = "images" if (path.parent / "images").is_dir() else ""
        ordered = sorted(pdf_info, key=lambda item: int(item.get("page_idx", 0)))
        return [
            (int(item.get("page_idx", 0)), (make([item], image_dir) or "").strip())
            for item in ordered
        ]
    except Exception as exc:
        logger.warning("%s 无法逐页重建，回退完整 markdown: %s", middle_path, exc)
        if md_path.is_file():
            text = md_path.read_text(encoding="utf-8-sig", errors="replace").strip()
            if text:
                return [(0, text)]
        # middle.json 无法逐页重建，且同名 .md 也不存在/为空：视为产物尚未就绪
        # （OCR 刚提交、文件写一半的竞态），抛错让上层 next_batch 重试 —— 绝不静默返回 []，
        # 否则空结果会被 next_batch 当成「真空」把 text_extraction 永久判死（线上卡死根因）。
        raise MiddleNotReadyError(
            f"{middle_path} 无法逐页重建且同名 .md 不可用，疑似尚未落盘: {exc}"
        )


def _extract_chunks(
    state_path: Path, state: dict[str, Any], contract: dict[str, Any],
) -> list[dict[str, Any]]:
    """把 ocr 的 middle.json 按页切成 chunk，每 chunk text 写单独文件；缓存元数据到 contract。

    返回 [{"chunk_index", "page_indices", "path"}, ...]，chunk_index 稳定可重复计算。
    chunk text 不进 review_state.json（避免膨胀），与 synthesize/validate 的 payload 落盘一致。
    """
    if "extract_chunks" not in contract:
        ocr = contract.get("ocr") or {}
        middle_path = str(ocr.get("middle_path") or "")
        # middle_path 为空（OCR 未提供中间产物）→ 视为真空，pages=[]；
        # middle_path 非空但产物未落盘 → _load_pages_from_middle 抛 MiddleNotReadyError，向上传播。
        pages = _load_pages_from_middle(middle_path) if middle_path else []
        out_dir = Path(state.get("output_dir") or state_path.parent) / "text_tasks"
        out_dir.mkdir(parents=True, exist_ok=True)
        chunks: list[dict[str, Any]] = []
        for start in range(0, len(pages), _EXTRACT_BATCH_PAGES):
            group = pages[start:start + _EXTRACT_BATCH_PAGES]
            parts = [f"## 第 {page_idx + 1} 页\n\n{md.strip()}" for page_idx, md in group]
            ci = len(chunks)
            chunk_path = out_dir / f"{contract['contract_id']}_extract_chunk_{ci:03d}.md"
            chunk_path.write_text("\n\n".join(parts).rstrip() + "\n", encoding="utf-8")
            chunks.append({
                "chunk_index": ci,
                "page_indices": [page_idx for page_idx, _ in group],
                "path": _path_for_json(chunk_path.resolve()),
            })
        # 只缓存非空结果：空结果（真空或瞬时未就绪重算后仍空）若缓存，会让该合同提取阶段永久卡死。
        if chunks:
            contract["extract_chunks"] = chunks
    return contract.get("extract_chunks") or []


def _normalize_validation(data: Any, contract: dict[str, Any]) -> dict[str, Any]:
    """清洗 Agent 提交的 validate 结果（移植自 compliance_validator._build_findings）。

    - 规则证据：只保留规则库中存在的 reference_rule_ids；全无效或为空 → 丢弃；
    - 依据条款：reference_clause 缺失时用规则的 quote 自动回填；
    - 合同证据：clause_locator/original_quote 仅在 Agent 未给出时用事实台账兜底，任一仍空 → 丢弃；
    - risk_explanation：剔除内部术语 / rule_id。
    """
    if isinstance(data, list):
        findings = data
    elif isinstance(data, dict):
        findings = data.get("findings") or []
    else:
        findings = []
    findings = [f for f in findings if isinstance(f, dict)]

    rulebook = get_rulebook()
    rule_index = {r["rule_id"]: r for r in (rulebook.get("rules") or [])}
    source_document = rulebook.get("source_document", "")

    # 事实索引：clause_locator -> scope_text，仅在 Agent 未给出 original_quote 时兜底
    # 用裁判实际输入（台账优先）建索引，保证台账编号 locator 也能回填
    fact_index: dict[str, str] = {}
    for fact in _clauses_for_validation(contract):
        loc = str(fact.get("clause_locator", "")).strip()
        if loc:
            fact_index[loc] = str(fact.get("scope_text", "")).strip()

    cleaned: list[dict[str, Any]] = []
    for item in findings:
        rule_ids_raw = item.get("reference_rule_ids") or []
        rule_ids: list[str] = []
        if isinstance(rule_ids_raw, list):
            for rid in rule_ids_raw:
                rid_s = str(rid).strip()
                if rid_s and rid_s in rule_index:
                    rule_ids.append(rid_s)
        if not rule_ids:
            continue  # 无规则依据，丢弃

        ref_clauses = [rule_index[rid]["quote"] for rid in rule_ids]
        ref_clause_text = str(item.get("reference_clause") or "").strip()
        if not ref_clause_text:
            ref_clause_text = "；".join(ref_clauses)
        if not ref_clause_text:
            continue

        locator = str(item.get("clause_locator", "")).strip()
        quote = str(item.get("original_quote", "")).strip()
        if not locator:
            continue  # 无合同位置，无法落库
        if not quote:
            quote = fact_index.get(locator, "")
        if not quote:
            continue  # 无合同原文，丢弃

        severity = str(item.get("severity") or "medium").strip().lower()
        if severity not in {"high", "medium", "low"}:
            severity = "medium"

        cleaned.append(
            {
                "contract_type": item.get("contract_type") or contract.get("contract_type") or "",
                "contract_file": item.get("contract_file") or contract.get("contract_file") or "",
                "clause_locator": locator,
                "original_quote": quote,
                "risk_explanation": _sanitize_risk_explanation(
                    str(item.get("risk_explanation", "")), rule_index
                ),
                "reference_document": item.get("reference_document") or source_document,
                "reference_clause": ref_clause_text,
                "reference_rule_ids": rule_ids,
                "severity": severity,
            }
        )
    return {"findings": cleaned}


def _contract_facts(contract: dict[str, Any]) -> list[dict[str, Any]]:
    facts: list[dict[str, Any]] = []
    text_extraction = contract.get("text_extraction")
    if isinstance(text_extraction, dict):
        for clause in text_extraction.get("clauses") or []:
            if isinstance(clause, dict):
                facts.append(dict(clause))
    return facts


def _synthesize_fragments(contract: dict[str, Any]) -> list[dict[str, Any]]:
    """合成器输入：把 text_extraction 的 clauses 打平并加全局 _idx（合成器按 _idx 反查原文）。"""
    fragments: list[dict[str, Any]] = []
    text_extraction = contract.get("text_extraction")
    if isinstance(text_extraction, dict):
        for clause in text_extraction.get("clauses") or []:
            if isinstance(clause, dict):
                fragments.append({"_idx": len(fragments), **clause})
    return fragments


def _clauses_for_validation(contract: dict[str, Any]) -> list[dict[str, Any]]:
    """裁判输入：优先用合成台账（已合并去重 + 证据强绑定），否则回退 extract_text 碎片。"""
    ledger = contract.get("ledger")
    if isinstance(ledger, list) and ledger:
        return ledger
    return _contract_facts(contract)


# 裁判分批送审：每批 1~2 条施工实体（移植自 ValidatorConfig.chunk_clauses_per_request=2，
# 且原项目再 min(...,2) 封顶），避免一次塞太多实体导致跨主体执法/上下文过载。
VALIDATE_CHUNK_SIZE = 2

# extract_text 按页分块：每 chunk 最多页数（对齐 contract-amount-manager-audit 的 batch_pages；
# 本 skill extract 是重理解任务，6 页/chunk 在 Agent 上下文内稳妥）
_EXTRACT_BATCH_PAGES = 6


def _validate_chunks(contract: dict[str, Any]) -> list[list[dict[str, Any]]]:
    """把待裁判事实切成 1~2 条/批的 chunk 列表（确定性，可重复计算，chunk_index 稳定）。"""
    clauses = _clauses_for_validation(contract)
    bs = max(1, min(VALIDATE_CHUNK_SIZE, 2))
    return [clauses[i : i + bs] for i in range(0, len(clauses), bs)]


def _ledger_has_dedupable_evidence(contract: dict[str, Any]) -> bool:
    """台账中是否存在 evidence≥2 的条目（决定 dedup_evidence 阶段是否需要跑）。"""
    for item in contract.get("ledger") or []:
        if len(item.get("evidence") or []) >= 2:
            return True
    return False


# —— Validator 第一/二步漏斗的 Python 侧预筛（移植自 compliance_validator）
#    按事实的 domain + structural_position + 桥型/工法关键词，先剪掉明显跨主体的规则，
#    只把候选规则随 payload 交给 Agent，缩小上下文、抑制跨主体执法幻觉。
#    豁免(Exclusion)与阈值(Threshold)仍由 Agent 按 VALIDATOR_SYSTEM_PROMPT 判断，Python 不做语义裁判。
_UNKNOWN_POSITIONS = {"不适用", "N/A", "无", ""}
_UNKNOWN_DOMAINS = {"其他", ""}


def _normalize_domain(raw: Any) -> str:
    """清洗 domain 标签：返回受控词之一，或空字符串表示未知。"""
    s = (str(raw or "")).strip()
    if not s or s in _UNKNOWN_DOMAINS:
        return ""
    if s == "桥梁":
        return "桥梁工程"
    if s == "隧道":
        return "隧道工程"
    return s


def _normalize_position(raw: Any) -> str:
    s = (str(raw or "")).strip()
    return "" if s in _UNKNOWN_POSITIONS else s


def _extract_fact_positions(clause: dict[str, Any]) -> list[str]:
    """支持多值 structural_positions，回退单值 structural_position；返回有效部位列表。"""
    multi = clause.get("structural_positions") or []
    if multi:
        result = [_normalize_position(p) for p in multi]
        result = [p for p in result if p]
        if result:
            return result
    single = _normalize_position(clause.get("structural_position"))
    return [single] if single else []


def _any_position_matches(fact_positions: list[str], rule_positions: list[str] | None) -> bool:
    """事实部位集合与规则要求部位集合是否有交集（任一匹配即放行，留给 Agent 细判）。"""
    if not rule_positions:
        return True
    if not fact_positions:
        return True
    rule_set = {(rp or "").strip() for rp in rule_positions if rp}
    return any(fp in rule_set for fp in fact_positions)


def _method_appears(text: str, candidates: list[str] | None) -> bool:
    """规则的桥型/工法限定，至少有一个用语出现在事实文本中。"""
    if not candidates:
        return True
    if not text:
        return False
    return any((c or "").strip() and (c or "").strip() in text for c in candidates)


def _fact_text_blob(clause: dict[str, Any]) -> str:
    """汇聚事实里所有可供关键词检索的文本（locator + scope + subject + 参数 + 部位/大类标签）。

    与原项目 compliance_validator._fact_text_blob 逐字一致：纳入 engineering_subject
    （合成台账的施工实体名，常含『顶推/钢箱梁/钢结构』等工法词），用于漏斗第二步
    的桥型/工法关键词兜底，避免仅靠 scope_text 检索时漏掉候选规则。
    """
    parts = [
        str(clause.get("clause_locator", "")),
        str(clause.get("scope_text", "")),
        str(clause.get("engineering_subject", "") or ""),
        str(clause.get("domain_classification", "") or ""),
        str(clause.get("structural_position", "") or ""),
    ]
    for pos in clause.get("structural_positions") or []:
        if pos:
            parts.append(str(pos))
    for p in clause.get("parameters") or []:
        if isinstance(p, dict):
            parts.append(str(p.get("raw_quote", "") or ""))
            parts.append(str(p.get("value", "") or ""))
            parts.append(str(p.get("name", "") or ""))
    return "\n".join(parts)


def _prefilter_rules_for_clause(clause: dict[str, Any], rules: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """第一/二步漏斗：按 domain + structure_position + 桥型/工法关键词预筛候选规则。"""
    fact_domain = _normalize_domain(
        clause.get("domain_classification") or clause.get("engineering_category")
    )
    fact_positions = _extract_fact_positions(clause)
    fact_text = _fact_text_blob(clause)

    kept: list[dict[str, Any]] = []
    for rule in rules:
        prereq = rule.get("prerequisite") or {}
        rdomain = (prereq.get("domain") or rule.get("category") or "").strip()

        # 第一步：Domain 漏斗
        if fact_domain and rdomain and fact_domain != rdomain:
            continue
        if not fact_domain:
            if not any(kw and kw in fact_text for kw in rule.get("keywords") or []):
                if rdomain and rdomain not in fact_text:
                    continue

        # 第二步：structure_position（集合相交）
        if not _any_position_matches(fact_positions, prereq.get("positions")):
            continue

        # 第二步（续）：桥型/工法用语至少出现一个，否则需关键词兜底
        method_pool = list(prereq.get("methods") or [])
        if method_pool and not _method_appears(fact_text, method_pool):
            if not any(kw and kw in fact_text for kw in rule.get("keywords") or []):
                continue

        kept.append(rule)
    return kept


def _sanitize_risk_explanation(text: str, rule_index: dict[str, dict[str, Any]]) -> str:
    """剔除 risk_explanation 中泄露的内部术语 / rule_id（移植自 compliance_validator）。"""
    if not text:
        return text
    kept: list[str] = []
    for line in text.splitlines():
        if any(p.search(line) for p in _FORBIDDEN_LINE_PATTERNS):
            continue
        kept.append(line)
    cleaned = "\n".join(kept)

    def _rid_repl(m: re.Match[str]) -> str:
        rule = rule_index.get(m.group(0))
        return f"《负面清单》{rule['title']}" if rule else ""

    cleaned = _RULE_ID_RE.sub(_rid_repl, cleaned)
    cleaned = re.sub(r"[ \t]*\n[ \t]*", "\n", cleaned)
    cleaned = re.sub(r"\n{2,}", "\n", cleaned)
    cleaned = "\n".join(_BULLET_PREFIX_RE.sub("", ln) for ln in cleaned.splitlines())
    cleaned = re.sub(r"^[\s，,。.；;：:、]+", "", cleaned)
    cleaned = re.sub(r"[ \t]{2,}", " ", cleaned)
    return cleaned.strip()


def _write_validation_payload(
    state_path: Path, state: dict[str, Any], contract: dict[str, Any],
    clauses: list[dict[str, Any]], chunk_index: int,
) -> str:
    out_dir = Path(state.get("output_dir") or state_path.parent)
    tasks_dir = out_dir / "validation_tasks"
    tasks_dir.mkdir(parents=True, exist_ok=True)
    payload_path = tasks_dir / f"{contract['contract_id']}_validate_c{chunk_index}.json"

    all_rules = get_rulebook().get("rules") or []
    use_ledger = bool(contract.get("ledger"))

    # 为每条事实预筛候选规则（第一/二步漏斗），只把候选规则随 payload 下发
    funnel_prefilter: list[dict[str, Any]] = []
    candidate_rule_ids: list[str] = []
    for c in clauses:
        kept = _prefilter_rules_for_clause(c, all_rules)
        kept_ids = [r["rule_id"] for r in kept]
        funnel_prefilter.append(
            {
                "clause_locator": _truncate(str(c.get("clause_locator", "")), 60),
                "domain_classification": c.get("domain_classification") or c.get("engineering_category"),
                "structural_position": c.get("structural_position"),
                "candidate_rule_ids": kept_ids,
            }
        )
        for rid in kept_ids:
            if rid not in candidate_rule_ids:
                candidate_rule_ids.append(rid)

    candidate_rules = [r for r in all_rules if r["rule_id"] in set(candidate_rule_ids)]

    payload = {
        "project_name": state.get("project_name", ""),
        "contract_id": contract["contract_id"],
        "contract_file": contract["contract_file"],
        "contract_type": contract["contract_type"],
        "fact_source": (
            "合同施工事实台账（合成器合并去重 + 证据强绑定）" if use_ledger
            else "OCR 文本逐块提取碎片（未做合规判断）"
        ),
        "funnel_prefilter": funnel_prefilter,
        "clauses": clauses,
        "candidate_rules": candidate_rules,
        "instructions": (
            "严格按下面的【合规推理决策树】对每个 (clause × candidate_rule) 两两审查。\n"
            "对每条 clause，只在其 funnel_prefilter.candidate_rule_ids 列出的规则中考虑违规；"
            "candidate_rules 是系统已为全部 clause 预筛过的候选规则全量（含 rule_id / quote / prerequisite / thresholds / exclusions）。\n"
            "事实落入 exclusions 或参数明确低于阈值时不要输出 finding；工法命中但关键阈值参数缺失时可输出 medium 提示人工核实。\n"
            "每条 finding 必须给出 reference_rule_ids（存在于 candidate_rules）+ 逐字的 clause_locator/original_quote；"
            "risk_explanation 面向用户用中文，引用《负面清单》章节序号/原文，禁止英文词、rule_id、漏斗/Domain/Prerequisite/Exclusion/Threshold 等内部术语。\n"
            "无任何可证违规时返回 {\"findings\": []}。输出严格 JSON，禁止 Markdown 围栏。\n\n"
            + VALIDATOR_SYSTEM_PROMPT
            + "\n\n"
            + VALIDATOR_SCHEMA_HINT
        ),
    }
    payload_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return _path_for_json(payload_path.resolve())


def _mark_empty_extraction(contract: dict[str, Any], reason: str = "") -> None:
    contract["text_extraction"] = {"clauses": [], "error": reason}


def _ocr_item(state_path: Path, state: dict[str, Any], contract: dict[str, Any]) -> dict[str, Any]:
    return {
        "action": "ocr",
        "contract_id": contract["contract_id"],
        "contract_file": contract["contract_file"],
        "pdf_path": contract["contract_path"],
        "prompt": (
            "Use MainAgent parse_document on pdf_path (the original contract PDF). "
            "Submit JSON with raw_response and, if available, markdown_path/middle_path. "
            "Keep middle_path — its pdf_info[].page_idx is the original-PDF page index "
            "used by the next phase to anchor clause locators."
        ),
    }


def _extract_text_user_text(chunk_text: str) -> str:
    return (
        "以下是合同某批连续页的 OCR 文本（每页以「## 第 N 页」起始，N 为原 PDF 物理页码）。\n"
        "每条 clause_locator 必须以『（第N页）』锚定该真实页码，严禁脑补或错位。\n\n"
        + TEXT_EXTRACT_SCHEMA
        + "\n\n【OCR Markdown（按页）】\n"
        + chunk_text
    )


def _extract_text_chunk_item(
    state_path: Path, state: dict[str, Any], contract: dict[str, Any],
    chunk_index: int, chunk: dict[str, Any], total: int,
) -> dict[str, Any]:
    chunk_text = Path(chunk["path"]).read_text(encoding="utf-8-sig")
    payload_path = _write_text_payload(
        state_path, state, contract,
        "extract_text", TEXT_EXTRACT_PROMPT, _extract_text_user_text(chunk_text),
        chunk_index=chunk_index,
    )
    return {
        "action": "extract_text",
        "contract_id": contract["contract_id"],
        "contract_file": contract["contract_file"],
        "chunk_index": chunk_index,
        "chunk_total": total,
        "payload_path": payload_path,
        "prompt": (
            "Read payload_path and use the current Agent text model to extract objective construction facts "
            "from this batch of OCR pages. Anchor every clause_locator to the physical page shown in its "
            "「## 第 N 页」header. Do not call parse_image / parse_document. Return the extract_text schema JSON."
        ),
    }


def _validate_chunk_item(
    state_path: Path, state: dict[str, Any], contract: dict[str, Any],
    chunk_index: int, chunk_clauses: list[dict[str, Any]],
) -> dict[str, Any]:
    payload_path = _write_validation_payload(state_path, state, contract, chunk_clauses, chunk_index)
    return {
        "action": "validate",
        "contract_id": contract["contract_id"],
        "contract_file": contract["contract_file"],
        "chunk_index": chunk_index,
        "chunk_total": len(_validate_chunks(contract)),
        "payload_path": payload_path,
        "prompt": (
            "读取 payload_path 中的 clauses/funnel_prefilter/candidate_rules 与 instructions，"
            "用当前 Agent 文字模型按漏斗决策树【只对本 chunk 的事实】输出 validate schema JSON。"
        ),
    }


def _write_text_payload(
    state_path: Path, state: dict[str, Any], contract: dict[str, Any],
    kind: str, system_prompt: str, user_text: str,
    chunk_index: int | None = None,
) -> str:
    """synthesize / extract_text / dedup_* 共用的 payload 落盘（system_prompt + user_text）。

    chunk_index 非空时文件名带 _c{ci} 后缀，避免同合同多 chunk 批量 emit 时互相覆盖
    （extract_text / synthesize 分块下发）；dedup_* 每合同单任务，不传 chunk_index。
    """
    out_dir = Path(state.get("output_dir") or state_path.parent)
    tasks_dir = out_dir / "text_tasks"
    tasks_dir.mkdir(parents=True, exist_ok=True)
    suffix = f"_c{chunk_index}" if chunk_index is not None else ""
    payload_path = tasks_dir / f"{contract['contract_id']}_{kind}_payload{suffix}.json"
    payload = {
        "contract_id": contract["contract_id"],
        "contract_file": contract["contract_file"],
        "system_prompt": system_prompt,
        "user_text": user_text,
    }
    payload_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return _path_for_json(payload_path.resolve())


def _synth_chunks(contract: dict[str, Any]) -> list[list[dict[str, Any]]]:
    """确定性计算合成分块并缓存到 contract 上，保证 chunk_index 稳定可重复计算。"""
    if "synth_chunks" not in contract:
        fragments = _synthesize_fragments(contract)
        contract["synth_chunks"] = _synth.chunk_fragments(fragments, contract["contract_file"])
    return contract["synth_chunks"]


def _synthesize_item(
    state_path: Path, state: dict[str, Any], contract: dict[str, Any],
    chunk_index: int, chunk: list[dict[str, Any]], total: int,
) -> dict[str, Any]:
    user_text = _synth.build_chunk_user_text(chunk, contract["contract_file"], chunk_index, total)
    payload_path = _write_text_payload(
        state_path, state, contract, "synthesize", _synth.SYSTEM_PROMPT, user_text, chunk_index=chunk_index
    )
    return {
        "action": "synthesize",
        "contract_id": contract["contract_id"],
        "contract_file": contract["contract_file"],
        "chunk_index": chunk_index,
        "chunk_total": total,
        "payload_path": payload_path,
        "prompt": (
            "阅读 payload 的 system_prompt + user_text，把【本块内】的条款碎片分组合并 + 摘录去重，"
            "输出严格 JSON：{\"groups\":[...],\"discarded_indices\":[...]}（schema 见 payload）。"
            "evidence.source_indices 必须使用碎片自带的全局 _idx；只用当前 Agent 文字模型，不要调用 parse_image。"
        ),
    }


def _dedup_evidence_item(state_path: Path, state: dict[str, Any], contract: dict[str, Any]) -> dict[str, Any]:
    user_text = _dedup.build_evidence_user_text(contract.get("ledger") or [])
    payload_path = _write_text_payload(
        state_path, state, contract, "dedup_evidence", _dedup.EVIDENCE_SYSTEM_PROMPT, user_text
    )
    return {
        "action": "dedup_evidence",
        "contract_id": contract["contract_id"],
        "contract_file": contract["contract_file"],
        "payload_path": payload_path,
        "prompt": (
            "阅读 payload，对每条台账的 evidence 独立执行『宏观母体识别 + 父子级吸收』，"
            "输出 {\"entries\":[{entry_index,macro_index,keep_indices,discard_indices,reason}]}。只用当前 Agent 文字模型。"
        ),
    }


def _dedup_findings_item(state_path: Path, state: dict[str, Any], contract: dict[str, Any]) -> dict[str, Any]:
    findings = (contract.get("validation") or {}).get("findings") or []
    user_text = _dedup.build_findings_user_text(findings)
    payload_path = _write_text_payload(
        state_path, state, contract, "dedup_findings", _dedup.FINDINGS_SYSTEM_PROMPT, user_text
    )
    return {
        "action": "dedup_findings",
        "contract_id": contract["contract_id"],
        "contract_file": contract["contract_file"],
        "payload_path": payload_path,
        "prompt": (
            "阅读 payload，剔除被宏观 finding 覆盖的冗余子项（仅 low 可被剔除，high/medium 强制保留），"
            "输出 {\"discard_indices\":[...]}。只用当前 Agent 文字模型。"
        ),
    }


def next_batch(state_path: Path, state: dict[str, Any], limit: int) -> dict[str, Any]:
    limit = max(1, limit)
    changed = False
    items: list[dict[str, Any]] = []

    for contract in state["contracts"]:
        if contract.get("ocr") is None:
            items.append(_ocr_item(state_path, state, contract))
            if len(items) >= limit:
                if changed:
                    _save_state(state_path, state)
                return {"action": "batch", "phase": "ocr", "items": items}
    if items:
        if changed:
            _save_state(state_path, state)
        return {"action": "batch", "phase": "ocr", "items": items}

    extract_not_ready = False
    for contract in state["contracts"]:
        if contract.get("ocr") is not None and contract.get("text_extraction") is None:
            if (contract.get("ocr") or {}).get("error"):
                _mark_empty_extraction(contract, str((contract.get("ocr") or {}).get("error") or "ocr failed"))
                changed = True
                continue
            try:
                chunks = _extract_chunks(state_path, state, contract)
            except MiddleNotReadyError:
                # middle.json 尚未落盘：不判死 text_extraction、不缓存，下轮 next_batch 自然重试
                extract_not_ready = True
                continue
            changed = True  # _extract_chunks 首次计算会写 chunk 文件并缓存 extract_chunks 到 contract
            if not chunks:
                _mark_empty_extraction(contract, "no pages from middle.json / markdown")
                continue
            total = len(chunks)
            done = set(contract.get("extract_chunk_done") or [])
            pending = [ci for ci in range(total) if ci not in done]
            for ci in pending:
                items.append(_extract_text_chunk_item(state_path, state, contract, ci, chunks[ci], total))
                if len(items) >= limit:
                    if changed:
                        _save_state(state_path, state)
                    return {"action": "batch", "phase": "extract_text", "items": items}
    if items:
        if changed:
            _save_state(state_path, state)
        return {"action": "batch", "phase": "extract_text", "items": items}
    if extract_not_ready:
        # 有合同 middle.json 未就绪且本批无其他 extract 活：等待重试，绝不推进到 synthesize
        # （否则 _synthesize_fragments 因 text_extraction=None 返回 []，会把 ledger 提前判空）
        if changed:
            _save_state(state_path, state)
        return {"action": "wait", "phase": "extract_text", "reason": "middle.json not ready; retry next_batch"}

    # —— synthesize：所有页提取完成后，按合同把碎片合成事实台账（输入过长则分块，对齐原项目 _synthesize_chunked）——
    for contract in state["contracts"]:
        if contract.get("ledger") is None:
            fragments = _synthesize_fragments(contract)
            if not fragments:
                contract["ledger"] = []
                contract["evidence_dedup_done"] = True
                changed = True
                continue
            chunks = _synth_chunks(contract)
            total = len(chunks)
            done = set(contract.get("synth_chunk_done") or [])
            pending = [ci for ci in range(total) if ci not in done]
            for ci in pending:
                items.append(_synthesize_item(state_path, state, contract, ci, chunks[ci], total))
                if len(items) >= limit:
                    if changed:
                        _save_state(state_path, state)
                    return {"action": "batch", "phase": "synthesize", "items": items}
    if items:
        if changed:
            _save_state(state_path, state)
        return {"action": "batch", "phase": "synthesize", "items": items}

    # —— dedup_evidence：台账 evidence 语义去重（仅当存在 evidence≥2 的条目才下发）——
    for contract in state["contracts"]:
        if contract.get("ledger") is not None and not contract.get("evidence_dedup_done"):
            if not _ledger_has_dedupable_evidence(contract):
                contract["evidence_dedup_done"] = True
                changed = True
                continue
            items.append(_dedup_evidence_item(state_path, state, contract))
            if len(items) >= limit:
                if changed:
                    _save_state(state_path, state)
                return {"action": "batch", "phase": "dedup_evidence", "items": items}
    if items:
        if changed:
            _save_state(state_path, state)
        return {"action": "batch", "phase": "dedup_evidence", "items": items}

    # —— validate：合规裁判，分批 1~2 条/批（优先用合成台账，回退 extract_text 碎片）——
    for contract in state["contracts"]:
        if not contract.get("validate_complete"):
            chunks = _validate_chunks(contract)
            if not chunks:
                contract["validation"] = {"findings": []}
                contract["validate_complete"] = True
                contract["findings_dedup_done"] = True
                changed = True
                continue
            done = set(contract.get("validate_done") or [])
            for ci, chunk in enumerate(chunks):
                if ci in done:
                    continue
                items.append(_validate_chunk_item(state_path, state, contract, ci, chunk))
                if len(items) >= limit:
                    if changed:
                        _save_state(state_path, state)
                    return {"action": "batch", "phase": "validate", "items": items}
    if items:
        if changed:
            _save_state(state_path, state)
        return {"action": "batch", "phase": "validate", "items": items}

    # —— dedup_findings：findings 语义去重（仅当 ≥2 条 findings 才下发）——
    for contract in state["contracts"]:
        if contract.get("validate_complete") and not contract.get("findings_dedup_done"):
            findings = (contract.get("validation") or {}).get("findings") or []
            if len(findings) < 2:
                contract["findings_dedup_done"] = True
                changed = True
                continue
            items.append(_dedup_findings_item(state_path, state, contract))
            if len(items) >= limit:
                if changed:
                    _save_state(state_path, state)
                return {"action": "batch", "phase": "dedup_findings", "items": items}
    if items:
        if changed:
            _save_state(state_path, state)
        return {"action": "batch", "phase": "dedup_findings", "items": items}

    if changed:
        _save_state(state_path, state)
    return {"action": "stop", "state": _path_for_json(state_path.resolve())}


def next_action(state_path: Path, state: dict[str, Any]) -> dict[str, Any]:
    batch = next_batch(state_path, state, 1)
    if batch.get("action") == "batch" and batch.get("items"):
        return batch["items"][0]
    return batch


def _apply_result(
    state: dict[str, Any],
    *,
    action: str,
    contract_id: str,
    page_index: int | None = None,
    chunk_index: int | None = None,
    data: Any = None,
) -> None:
    contract = next((c for c in state["contracts"] if c["contract_id"] == contract_id), None)
    if contract is None:
        raise ValueError(f"unknown contract_id: {contract_id}")
    if action == "ocr":
        ocr = _normalize_ocr_result(data)
        contract["ocr"] = ocr
        if ocr.get("error"):
            _mark_empty_extraction(contract, str(ocr.get("error") or "ocr failed"))
    elif action == "extract_text":
        done = contract.setdefault("extract_chunk_done", [])
        chunks = contract.get("extract_chunks") or []  # next_batch emit 时已计算并缓存
        total = len(chunks)
        ci = chunk_index
        if ci is None or ci < 0 or ci >= total:
            for k in range(total):           # 兜底：未回传 chunk_index 时 FIFO 消费下一个未完成 chunk
                if k not in done:
                    ci = k
                    break
        if ci is not None and ci not in done:
            acc = contract.setdefault("extract_clauses_acc", [])
            acc.extend(_normalize_extraction(data)["clauses"])
            done.append(ci)
        if total and len(done) >= total:
            contract["text_extraction"] = {
                "clauses": contract.get("extract_clauses_acc") or [],
                "error": "",
            }
    elif action == "synthesize":
        fragments = _synthesize_fragments(contract)
        chunks = _synth_chunks(contract)
        total = len(chunks)
        raw = data if isinstance(data, str) else json.dumps(data, ensure_ascii=False)
        chunk_groups, chunk_discarded = _synth.parse_groups(raw)
        acc_groups = contract.setdefault("synth_groups_acc", [])
        acc_discarded = contract.setdefault("synth_discarded_acc", [])
        acc_groups.extend(chunk_groups)
        for d in chunk_discarded:
            if d not in acc_discarded:
                acc_discarded.append(d)
        done = contract.setdefault("synth_chunk_done", [])
        ci = chunk_index
        if ci is None or ci < 0 or ci >= total:
            # 兜底：Agent 未回传 chunk_index 时，按 FIFO 消费下一个未完成块，避免卡死
            for k in range(total):
                if k not in done:
                    ci = k
                    break
        if ci is not None and ci not in done:
            done.append(ci)
        if total and len(done) >= total:
            contract["ledger"] = _synth.build_ledger_from_groups(
                fragments, acc_groups, acc_discarded
            )
            contract["evidence_dedup_done"] = False
    elif action == "dedup_evidence":
        raw = data if isinstance(data, str) else json.dumps(data, ensure_ascii=False)
        contract["ledger"] = _dedup.apply_evidence_dedup(contract.get("ledger") or [], raw)
        contract["evidence_dedup_done"] = True
    elif action == "validate":
        # 分批裁判：累计本 chunk 的 findings，全部 chunk 完成后才算 validate_complete
        new_findings = _normalize_validation(data, contract)["findings"]
        if not isinstance(contract.get("validation"), dict):
            contract["validation"] = {"findings": []}
        validation = contract["validation"]
        if not isinstance(validation.get("findings"), list):
            validation["findings"] = []
        validation["findings"].extend(new_findings)
        done = contract.setdefault("validate_done", [])
        total = len(_validate_chunks(contract))
        if chunk_index is not None:
            if chunk_index not in done:
                done.append(chunk_index)
        else:
            # 兜底：Agent 未回传 chunk_index 时，按 FIFO 消费下一个未完成 chunk，避免卡死
            for ci in range(total):
                if ci not in done:
                    done.append(ci)
                    break
        if total and len(done) >= total:
            contract["validate_complete"] = True
            contract["findings_dedup_done"] = False
    elif action == "dedup_findings":
        validation = contract.get("validation") or {}
        raw = data if isinstance(data, str) else json.dumps(data, ensure_ascii=False)
        validation["findings"] = _dedup.apply_findings_dedup(validation.get("findings") or [], raw)
        contract["validation"] = validation
        contract["findings_dedup_done"] = True
    else:
        raise ValueError(f"unknown action: {action}")


# --reset-extraction 要清空的键：extract_text 及其全部下游阶段。
# 清空后 next_batch 从 ocr.middle.json 重新切块，整个合同从头走 extract_text。
_RESET_EXTRACTION_KEYS = (
    "text_extraction",
    "extract_chunks",
    "extract_chunk_done",
    "extract_clauses_acc",
    "synth_chunks",
    "synth_chunk_done",
    "synth_groups_acc",
    "synth_discarded_acc",
    "ledger",
    "evidence_dedup_done",
    "validation",
    "validate_done",
    "validate_complete",
    "findings_dedup_done",
)


def reset_extraction(state: dict[str, Any], contract_id: str) -> dict[str, Any]:
    """清空 extract_text 及其全部下游阶段状态，让 next_batch 从 ocr 的 middle.json 重新
    切块抽取。

    用于 text_extraction 被判死（竞态误判 / OCR 产物瞬时未就绪）后的干净恢复 —— agent
    调 ``--reset-extraction`` 即可，不必手工改 review_state.json。OCR 本身（含 ocr.error）
    不受影响：若 OCR 真失败，重置后 next_batch 仍会照常按 ocr.error 判死。
    """
    contract = next((c for c in state["contracts"] if c["contract_id"] == contract_id), None)
    if contract is None:
        raise ValueError(f"unknown contract_id: {contract_id}")
    cleared: list[str] = []
    for key in _RESET_EXTRACTION_KEYS:
        if key in contract:
            del contract[key]
            cleared.append(key)
    return {"action": "reset", "contract_id": contract_id, "cleared": cleared}


def submit_result(args: argparse.Namespace, state_path: Path, state: dict[str, Any]) -> dict[str, Any]:
    data = _load_json(args.result)
    _apply_result(
        state,
        action=args.submit,
        contract_id=args.contract_id,
        page_index=args.page_index,
        chunk_index=args.chunk_index,
        data=data,
    )
    _save_state(state_path, state)
    return next_action(state_path, state)


def submit_batch(args: argparse.Namespace, state_path: Path, state: dict[str, Any]) -> dict[str, Any]:
    payload = _load_json(args.result)
    entries = payload.get("results") if isinstance(payload, dict) else payload
    if not isinstance(entries, list):
        raise ValueError("batch result must be a list or an object with a results list")
    for entry in entries:
        if not isinstance(entry, dict):
            raise ValueError("each batch result entry must be an object")
        data = _load_json(entry["result_path"]) if entry.get("result_path") else entry.get("result")
        if data is None:
            data = entry
        _apply_result(
            state,
            action=str(entry.get("action") or entry.get("type") or ""),
            contract_id=str(entry.get("contract_id") or ""),
            page_index=entry.get("page_index"),
            chunk_index=entry.get("chunk_index"),
            data=data,
        )
    _save_state(state_path, state)
    return next_batch(state_path, state, args.limit)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Advance or update a contract compliance review state.")
    parser.add_argument("--state", required=True)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--next", action="store_true")
    group.add_argument("--next-batch", action="store_true")
    group.add_argument(
        "--submit",
        choices=["ocr", "extract_text", "synthesize", "dedup_evidence", "validate", "dedup_findings"],
    )
    group.add_argument("--submit-batch", action="store_true")
    group.add_argument("--reset-extraction", action="store_true")
    parser.add_argument("--limit", type=int, default=8)
    parser.add_argument("--contract-id")
    parser.add_argument("--page-index", type=int)
    parser.add_argument("--chunk-index", type=int)
    parser.add_argument("--result")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    state_path = Path(args.state)
    state = _load_json(state_path)
    try:
        if args.next:
            result = next_action(state_path, state)
        elif args.next_batch:
            result = next_batch(state_path, state, args.limit)
        elif args.submit_batch:
            if not args.result:
                raise ValueError("--result is required with --submit-batch")
            result = submit_batch(args, state_path, state)
        elif args.reset_extraction:
            if not args.contract_id:
                raise ValueError("--contract-id is required with --reset-extraction")
            result = reset_extraction(state, args.contract_id)
            _save_state(state_path, state)
        else:
            if not args.contract_id or not args.result:
                raise ValueError("--contract-id and --result are required with --submit")
            result = submit_result(args, state_path, state)
    except Exception as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
