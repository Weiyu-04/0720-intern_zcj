---
name: contract-compliance-audit
description: 审核工程分包合同 PDF 是否触及《公路工程施工分包负面清单（2024年版）》的分包限制，并导出 Excel 审查结果。负面清单规则已内置在脚本规则库（桥梁工程 12 条 + 隧道工程 6 条，共 18 条）；全程禁止联网查询法规原文。用户上传公路工程合同要求做合规审查、分包负面清单核查或识别违规分包范围时使用。
allowed-tools: [parse_document, bash, read_file, write_file, present_files]
---

# 工程合同合规性审核

本 skill 审核工程分包合同 PDF 是否触及《公路工程施工分包负面清单（2024年版）》中的桥梁工程、隧道工程等分包限制，并生成 Excel 结果。

## 路径规则

- 将本轮实际加载的 `SKILL.md` 所在目录记为 `SKILL_DIR`（本 skill 即 `…/skills/public/contract-compliance-audit`）。
- 所有脚本都从 `<SKILL_DIR>/scripts/` 调用；执行时把 `<SKILL_DIR>` 替换成真实目录，不要把尖括号原样传给 shell。
- 不要假设 Skill 位于固定的 `/mnt` 或 Windows 路径，也不要运行 `find`、`which`、`Get-Command` 去寻找脚本。

## 硬性规则

- `parse_document` 只能在 `ocr` 阶段对原始合同 PDF 调用（脚本返回的 `pdf_path` 即源 PDF）；若同名 `.md` 与 `_middle.json` 已存在且非空则直接复用，不要重复解析（详见「phase/action = ocr」）。
- OCR 后的施工事实抽取按页分块读取 `parse_document`/MinerU 的 `_middle.json` 重建的页 markdown（每 6 页一批），用当前 Agent 文字模型完成；每条 `clause_locator` 必须锚定 `_middle.json` 给出的物理页码。
- 所有推进和提交只走 `advance_review.py`，不要手工改 `review_state.json`；提取阶段被误判死时用 `--reset-extraction` 恢复（见下文「重置提取阶段」），仍不要手改状态文件。
- 负面清单规则已内置在脚本规则库（`scripts/app/rulebook.py`，即《公路工程施工分包负面清单（2024年版）》），`validate` 阶段会随 payload 的 `candidate_rules` 下发；全程禁止联网搜索法规 / 负面清单 / 标准原文，也不得引用规则库之外的规则。
- 提交结果 JSON 的合法性由 `advance_review.py` 校验；不要自己用 `python -c` 反复验证 —— Windows 路径 `\U` 转义、sandbox 内的 `/mnt/` 虚拟路径在宿主机不存在，都会让自验脚本读到错误内容而误报「JSON 非法」。提交失败时脚本本身会打印清楚的错误，按错误修 JSON 重提即可。
- 结果 Excel 必须且只能由 `write_report.py` 产出；禁止用 `openpyxl` 或任何手搓代码自建多 sheet / 带标题合并行 / 带项目名称的 Excel（曾出现过 Agent 自建「合规审核表 + 负面清单规则 + 施工事实台账」3-sheet 的偏离，必须避免）。`write_report.py` 输出固定 8 列单 sheet findings 表（首列「总包/分包」，无「项目」列、无项目名），文件名 `合同合规审查结果_{时间戳}.xlsx`；运行末尾按「## 3. 生成 Excel」调一次即可，不要自己写 xlsx。

## 固定流程

```text
prepare_review.py
  -> ocr            按合同并行；对原始合同 PDF 调用 parse_document/MinerU
  -> extract_text   按合同 chunk 并行；脚本把 _middle.json 按页（每6页）切成 chunk，Agent 逐 chunk 抽取客观施工事实
  -> synthesize     按合同并行（碎片过多自动分块）；合并同一施工实体事实并去重
  -> dedup_evidence 按合同并行；台账 evidence 语义去重
  -> validate       按合同 chunk 并行；用负面清单规则裁判
  -> dedup_findings 按合同并行；findings 语义去重
  -> write_report.py
```

同一个 `--next-batch` 返回的 `items` 可以并行执行；提交本批结果前不要再次取下一批。

**如何驱动（状态机循环）**：阶段由 `advance_review.py` 按合同状态自动推进，agent 不自选阶段、不跳阶段。整体只有两步：

1. 跑一次 `prepare_review.py`（见「## 1. 准备合同」）生成 `review_state.json`。
2. 反复推进，直到脚本返回 `{"action": "stop", ...}`：
   - **取批**：首次用 `--next-batch --limit 20`（建议 ≥ 本阶段全部合同 item 总和，一次拿完一个阶段）；之后直接用上一次 `--submit-batch` 的返回值（它就是下一批），或再次 `--next-batch` 均可。
   - **处理**：在同一 turn 内并行处理本批全部 item —— 逐个读 `payload_path`，按其内嵌的 system_prompt + schema 一次成型产出 JSON，每个 chunk 写一个独立结果文件。
   - **提交**：`--submit-batch --result <batch.json>` 一次提交全批；脚本返回下一批 item，或 `stop` / `wait`。
3. 收到 `stop` → 所有合同推进完毕，跑 `write_report.py`（见「## 3. 生成 Excel」）收尾。
   收到 `wait`（极少数，OCR 产物 `_middle.json` 瞬时未落盘）→ 不要改状态文件、不要结束流程，稍候再 `--next-batch` 即可。

`ocr` 阶段的 item 要调 `parse_document`；`extract_text` / `synthesize` / `validate` / `dedup_*` 都是「读 payload → 产 JSON」的确定性机械任务，按下面「轻量执行原则」处理。

**轻量执行原则（机械任务不要过度思考）**：`extract_text` / `synthesize` / `validate` / `dedup_*` 都是确定性机械任务（抄录 / 裁判 / 去重）。处理每个 item 时：

- 直接读 `payload_path`，按其 schema **一次成型**产出 JSON —— 不分步推理、不写思考过程、不写解释。
- 禁止用 `python -c` 反复校验 JSON 合法性、禁止反复重读 payload —— JSON 合法性由 `advance_review.py` 提交时校验，失败会打印清楚错误。
- 本批多个 item 在同一 turn 内并行处理完，最后一次性 `--submit-batch`。

## 多合同处理

多份合同时，`prepare_review.py` 给每份 PDF 编一个 `contract_id`（c001/c002…），一次 `--next-batch` 返回的 item **会横跨多份合同**（共享 `limit`）。每条 item 自带 `contract_id` + `chunk_index`，处理与回传必须原样带回；`--limit` 建议 ≥ 本阶段全部合同 item 总和，一次拿完一个阶段。

主 agent 在同一 turn 内把本批全部 item 处理完（逐个读 `payload_path`、按 schema 一次成型产 JSON、每个 chunk 写一个独立结果文件），再一次 `--submit-batch`。`ocr` 阶段对每份合同的 `parse_document` 可在一个 turn 内并行下发多个 tool call（合同多则分批，每批 3~5 个）。

## 1. 准备合同

```bash
python "<SKILL_DIR>/scripts/prepare_review.py" --contract-type "分包" --pdf "/mnt/user-data/uploads/<合同.pdf>" --output-dir "/mnt/user-data/outputs/contract_compliance_audit"
```

目录批量：

```bash
python "<SKILL_DIR>/scripts/prepare_review.py" --contract-type "分包" --dir "/mnt/user-data/uploads/<合同目录>" --output-dir "/mnt/user-data/outputs/contract_compliance_audit"
```

脚本创建 `review_state.json`（不再渲染页图）。

## 2. 批量推进

**首选批量执行（禁止逐个 `--submit` 循环）**：每个阶段都用下面的三步范式，把 N 个 chunk 压到一轮往返里。

1. `--next-batch --limit <大数>`（建议 ≥ 该合同 chunk 总数，如 20）一次拿一批 item。
2. **同一个 turn 内并行处理本批所有 item**：逐个读 `payload_path`、按其 schema 产出 JSON，每个 chunk 写一个独立结果文件（如 `results/<cid>_extract_text_chunk_<ci>.json`）。
3. `--submit-batch --result <batch.json>` 一次提交全部。

`batch.json` 格式（每项可带 `result_path` 指向该 chunk 的结果文件，脚本会读取）：

```json
{"results": [
  {"action": "extract_text", "contract_id": "<CONTRACT_ID>", "chunk_index": 0, "result_path": "/mnt/user-data/outputs/.../results/c001_extract_text_chunk_0.json"},
  {"action": "extract_text", "contract_id": "<CONTRACT_ID>", "chunk_index": 1, "result_path": "/mnt/user-data/outputs/.../results/c001_extract_text_chunk_1.json"}
]}
```

每 chunk 一次 `--submit` 的串行往返是慢的根源 —— 不要这么做。`--submit-batch` 提交失败时脚本会打印清楚错误，按错误修对应 chunk 的结果 JSON 后整体重提，不要回退到逐个 submit。

```bash
python "<SKILL_DIR>/scripts/advance_review.py" --state "/mnt/user-data/outputs/contract_compliance_audit/review_state.json" --next-batch --limit 8
```

返回：

```json
{"action": "batch", "phase": "ocr|extract_text|synthesize|dedup_evidence|validate|dedup_findings", "items": []}
```

极少数情况下会返回 `{"action": "wait", "phase": "extract_text", "reason": "..."}`：OCR 刚提交、`_middle.json` 或同名 `.md` 尚未完全落盘（含文件已建但内容未写完）时的瞬时竞态。这既不是错误也不是完成 —— 不要结束流程，也不要手工改状态文件，稍等片刻后再次执行 `--next-batch` 即可（脚本判定为瞬时未就绪时不会缓存空结果，下一轮会重新读取并正常推进）。

### phase/action = ocr

每个 item 带 `pdf_path`，即原始合同 PDF（`contract_path`），不是子集。

对每个 item 并行调用：

```text
parse_document(file_path="<pdf_path>")
```

**产物复用（省时）**：每个 item 的 `pdf_path` 对应产物（`{stem}.md` 与 `{stem}_middle.json`，stem 取自 PDF 文件名）若已存在且**内容非空**，直接复用、不要重复调 `parse_document` —— 把已存在路径分别填入 `markdown_path` 与 `middle_path` 提交即可。仅当二者缺失或为空时才重新 `parse_document`。注意与 `wait` 区分：复用要求产物内容完整落盘；文件已建但为空/未写完时仍按 `wait` 稍后重试，不要当可复用。

提交结果建议包含：

```json
{
  "results": [
    {
      "action": "ocr",
      "contract_id": "<CONTRACT_ID>",
      "result": {
        "raw_response": "parse_document 原始返回",
        "markdown_path": "/mnt/user-data/outputs/xxx.md",
        "markdown_text": "",
        "middle_path": ""
      }
    }
  ]
}
```

`parse_document` 返回串里同时含 `Markdown written to .../{stem}.md` 和（MinerU 成功时）`Page-level layout written to .../{stem}_middle.json`。把两个路径分别填入 `markdown_path` 与 `middle_path`；只提交 `raw_response` 也可，脚本会正则兜底抽取这两个路径。`middle.json` 是 MinerU 页级布局（`pdf_info[].page_idx`），下一阶段用它精确锚定页码，务必保留。

### phase/action = extract_text

每个 item 带 `payload_path`、`chunk_index`、`chunk_total`；payload 内含该 chunk 的按页 OCR markdown（每页以「## 第 N 页」起始，N 为原 PDF 物理页码）与抽取 schema。用当前 Agent 文字模型读取 payload，按页头物理页码把每条 `clause_locator` 锚定为「（第N页）」。

`chunk_index` 从 0 起（`chunk_total` 为总数）；`payload_path` 每次 `--next-batch` 覆盖写、只含当前 chunk 的 markdown，提交时必须带回本 chunk 的 `chunk_index`。

`raw_quote` 必须是当前 chunk 原文的逐字 substring，禁止把计算 / 推导 / 合计值冒充原文。反例：原文表格只有「人工费(含税)/机械费(含税)/其他费用(含税)」绝对金额列、并无占比列时，不得输出 `{"name":"人工费占比","value":"20.0%","raw_quote":"20.0%"}` —— 这是自算值（金额 ÷ 总价），应整体省略该 parameter；原文没有的字段一律不补、不编。

禁止调用 `parse_image`；禁止再次调用 `parse_document`。

输出并提交（提交时必须带回 `chunk_index`）：

```json
{
  "results": [
    {
      "action": "extract_text",
      "contract_id": "<CONTRACT_ID>",
      "chunk_index": 0,
      "result": {
        "clauses": [
          {
            "clause_locator": "工程量清单 序号3（第47页）",
            "scope_text": "逐字来自该 chunk OCR Markdown 的施工事实原文",
            "engineering_category": "桥梁",
            "domain_classification": "桥梁工程",
            "structural_position": "基础工程",
            "parameters": [{"name": "桩径", "value": "1.5", "unit": "m", "raw_quote": "桩径1.5m"}],
            "is_generic": false,
            "notes": null
          }
        ],
        "error": ""
      }
    }
  ]
}
```

脚本按 chunk 逐批下发并累计 clauses，全部 chunk 完成后才进入 `synthesize`。只抽取客观施工实体事实，不做合规判断，不引用负面清单。

### phase/action = synthesize

读取 `payload_path`，用当前 Agent 文字模型把【本块内】语义指向同一施工实体/工法的碎片合并为事实台账。碎片很多时脚本会分块下发，每个 item 带 `chunk_index`/`chunk_total`，`evidence.source_indices` 必须用碎片自带的全局 `_idx`（跨块同对象合并由脚本兜底）。不要调用 `parse_image` 或 `parse_document`。

提交时带回 `chunk_index`：

```json
{
  "results": [
    {
      "action": "synthesize",
      "contract_id": "<CONTRACT_ID>",
      "chunk_index": 0,
      "result": {"groups": [...], "discarded_indices": []}
    }
  ]
}
```

### phase/action = dedup_evidence

读取 `payload_path`，用当前 Agent 文字模型对每条台账的 evidence 做语义去重。

结果：

```json
{"entries": [{"entry_index": 0, "macro_index": 0, "keep_indices": [0], "discard_indices": [], "reason": ""}]}
```

### phase/action = validate

读取 `payload_path`，只对本 item 的 `clauses` 和 `candidate_rules` 做裁判。每个 item 带 `chunk_index`，提交时必须带回。

结果：

```json
{"findings": []}
```

每条 finding 必须有合同原文证据和规则依据；无可证违规时返回空数组。

### phase/action = dedup_findings

读取 `payload_path`，用当前 Agent 文字模型剔除被更宏观 finding 覆盖的低风险重复项。

结果：

```json
{"discard_indices": []}
```

## 2.5 重置提取阶段（恢复被误判死的合同）

脚本已尽量用 `wait` 规避 OCR 产物瞬时未就绪（`_middle.json` 写一半 / 同名 `.md` 为空 / 二者均未落盘），不会判死 `text_extraction`。但若用了旧版本留下的状态文件、或 OCR 真把某合同打成 `text_extraction: {"clauses": [], "error": "..."}`，`--next-batch` 会一直跳过该合同返回 `stop`。恢复方式（不要手工改 `review_state.json`）：

```bash
python "<SKILL_DIR>/scripts/advance_review.py" --state "/mnt/user-data/outputs/contract_compliance_audit/review_state.json" --reset-extraction --contract-id <CONTRACT_ID>
```

它会清空该合同 `extract_text` 及其全部下游阶段（synthesize / ledger / validate / dedup），`ocr` 保留；随后 `--next-batch` 从 `_middle.json` 重新切块抽取。若 OCR 本身失败（`ocr.error` 非空），重置无效 —— 那是 `ocr` 阶段问题，需重新对原始 PDF 调 `parse_document`。

## 3. 生成 Excel

调一次 `write_report.py`，传 `--output-dir` 指定输出目录（文件名由脚本按 `合同合规审查结果_{时间戳}.xlsx` 自动生成，避免覆盖与项目名泄漏；**不要传 `--output`**，那会固定文件名且失去时间戳）：

```bash
python "<SKILL_DIR>/scripts/write_report.py" --state "/mnt/user-data/outputs/contract_compliance_audit/review_state.json" --output-dir "/mnt/user-data/outputs"
```

脚本输出固定 8 列单 sheet findings 表（无「项目」列、无项目名），文件名 `合同合规审查结果_{时间戳}.xlsx`，落在 `--output-dir` 指定目录（默认 `review_state.json` 的 `output_dir`）。若未发现 findings，明确说明本轮未发现可落库的负面清单风险。

## 常见失败

- `parse_document` 鉴权/配置失败：这是 MainAgent 文档解析/MinerU 工具配置问题，只能在 `ocr` 阶段对原始合同 PDF 重试。
- `ocr` 失败：该合同事实集为空，后续报告会体现无可裁判事实或无 findings。
- `advance_review.py` 报错：修正本批结果 JSON 后重试，不要手工改状态文件。
- `--next-batch` 返回 `{"action": "wait", ...}`：`_middle.json` 尚未落盘的瞬时竞态，稍后重试 `--next-batch` 即可，不要手工改状态文件。
- 某合同 `text_extraction` 被打成 `{"clauses": [], "error": "..."}`、`--next-batch` 持续返回 `stop`：用 `--reset-extraction --contract-id <ID>` 清空提取阶段后重跑，不要手工改状态文件。
