---
name: migrant-wage-attendance-audit
description: 农民工工资 vs 考勤对账。用户上传工资 PDF + 考勤 Excel 并要求「审核/对账」时使用。工作流：①parse_document(工资PDF)→md ②extract_wage.py 从 md 抽工资记录→wage_records.json（失败时大脑手动抽） ③audit.py 考勤计算+对账+Excel ④present_files。
allowed-tools: [parse_document, bash, read_file, write_file, present_files]
---

# 农民工工资 vs 考勤对账

工资 PDF + 考勤 Excel → **平台 OCR** → **大脑按契约抽工资记录** → **脚本确定性对账** → Excel 报告。

抽取（看 md 抽姓名/出勤天数）由你（大脑）完成；脚本只做确定性的考勤天数计算、对账、Excel 导出，不含任何 LLM/OCR。

## 路径规则

- 将本轮实际加载的 `SKILL.md` 所在目录记为 `SKILL_DIR`。例如实际加载路径为 `/任意位置/migrant-wage-attendance-audit/SKILL.md`，则 `SKILL_DIR` 为 `/任意位置/migrant-wage-attendance-audit`。
- skill 内部目录结构保持不变；所有脚本都从 `<SKILL_DIR>/scripts/` 调用。
- 执行脚本时把 `<SKILL_DIR>` 替换为本轮已知的真实目录。
- 不要假设 Skill 位于 `/mnt/skills/public/`、用户目录或任何固定 Windows 路径。

## 工作流（4 步）

```
步骤 1  parse_document(工资 PDF)          → /mnt/user-data/outputs/{stem}.md
步骤 2  python "<SKILL_DIR>/scripts/extract_wage.py" --md {stem}.md --inspect
        → 大脑判断工资表/姓名列/出勤天数列
        python "<SKILL_DIR>/scripts/extract_wage.py" --md {stem}.md --table-index ... --name-column/--name-index ... --days-column/--days-index ...
        → /mnt/user-data/outputs/wage_records.json
        read_file 校验 wage_records.json 的 month 和 records
步骤 3  python "<SKILL_DIR>/scripts/audit.py" --wage-json ... --uploads ... --output-dir ...   （纯确定性）
步骤 4  present_files + 文字汇总
```

### 步骤 1 — `parse_document`（只对工资 PDF）

从当前消息的 `<uploaded_files>` 中找到工资 PDF，**原样复制其 `Path:` 行**：

```
parse_document(file_path="/mnt/user-data/uploads/<PDF 路径>")
```

- 只对 `.pdf` 调用，不要对考勤 `.xlsx` 调用。
- 成功后写入 `/mnt/user-data/outputs/{PDF的stem}.md`；OCR 可能需要数分钟，等它完成。

### 步骤 2 — `extract_wage.py`（inspect + 大脑选列 + 代码提取）

```bash
python "<SKILL_DIR>/scripts/extract_wage.py" --md "/mnt/user-data/outputs/{stem}.md" --inspect
```

`--inspect` 只展示候选表格、列名和样例行；**你（大脑）判断**哪张表是工资表、哪一列是姓名、哪一列是工资单出勤天数。脚本不得用正则替你判断语义列。

判断后再运行提取命令。列名稳定时用列名：

```bash
python "<SKILL_DIR>/scripts/extract_wage.py" \
  --md "/mnt/user-data/outputs/{stem}.md" \
  --table-index 0 \
  --name-column "姓名" \
  --days-column "出勤天数" \
  --output "/mnt/user-data/outputs/wage_records.json"
```

OCR 表头不稳定或列名重复时，用 0-based 列序号：

```bash
python "<SKILL_DIR>/scripts/extract_wage.py" \
  --md "/mnt/user-data/outputs/{stem}.md" \
  --table-index 0 \
  --name-index 1 \
  --days-index 6 \
  --output "/mnt/user-data/outputs/wage_records.json"
```

脚本负责：解析 Markdown pipe 表格和 HTML `<tr><td>` 表格、按你指定的列提取、跳过合计行、输出 JSON。你负责：从 inspect 输出中判断工资表、姓名列、工资单出勤天数列。

提取后必须用 `read_file` 检查 `/mnt/user-data/outputs/wage_records.json`：
- `month` 必须是本次对账月份（如 `2026-01`），不能留空或错月。
- `records` 必须非空。
- 抽出的 `name` 和 `days` 必须来自 inspect 中选定的工资表列，不能抽到考勤列或汇总行。

**若脚本仍报错**，用 `read_file` 读 md，手动把工资表按下面契约写成 JSON：

```json
{
  "source_file": "江颐202601农民工资.pdf",
  "month": "2026-01",
  "records": [
    {"name": "张三", "days": 26},
    {"name": "李四", "days": 20}
  ]
}
```

字段说明：

| 字段 | 含义 |
| --- | --- |
| `source_file` | 工资 PDF 文件名（用于月份推断、报告标注） |
| `month` | 对账月份 `YYYY-MM`；可从文件名（如 `202601`）推断 |
| `records[].name` | 人员姓名 |
| `records[].days` | 工资单上记录的出勤天数（数字，可为小数） |

选列要点：
- 只从工资支付表/工资发放表中选列，不要从考勤表中选。
- `days` 取工资单上记录的出勤天数；多列候选时取对账月那一列。
- 只抽真实人员行，跳过合计/小计/表头行。

### 步骤 3 — `audit.py`（考勤计算 + 对账 + Excel，纯确定性）

```bash
python "<SKILL_DIR>/scripts/audit.py" \
  --wage-json "/mnt/user-data/outputs/wage_records.json" \
  --uploads "/mnt/user-data/uploads" \
  --output-dir "/mnt/user-data/outputs"
```

- `--uploads` 自动找首个考勤 `.xlsx`；对账月份优先取 `wage_records.json` 的 `month`，否则从 `source_file` 文件名推断。
- 脚本会从考勤 Excel 计算每人有效出勤天数，再与工资记录对账，导出 `农民工工资对账_*.xlsx`。
- 若脚本报错（traceback），把它原样转给用户。

**考勤 Excel 需含列：** `姓名`、`打卡时间`、`进场上班or出厂下班`。缺列时脚本会报错，提示用户补齐。

### 步骤 4 — 汇报

`present_files` 展示 `outputs/农民工工资对账_*.xlsx`，并按四类汇总人数：

| 类别 | 含义 |
| --- | --- |
| 匹配正常 | 姓名匹配，出勤天数一致 |
| 出勤天数不匹配 | 姓名匹配，天数不一致 |
| 有薪资没出勤 | 工资单有、考勤无 |
| 有出勤没薪资 | 考勤有、工资单无 |

## 路径

| 用途 | 路径 |
| --- | --- |
| 上传文件 | `/mnt/user-data/uploads/` |
| OCR 结果 md | `/mnt/user-data/outputs/{PDF的stem}.md` |
| 工资记录 JSON | `/mnt/user-data/outputs/wage_records.json` |
| 对账报告 | `/mnt/user-data/outputs/农民工工资对账_*.xlsx` |
| 提取脚本 | `<SKILL_DIR>/scripts/extract_wage.py` |
| 对账脚本 | `<SKILL_DIR>/scripts/audit.py` |

## 约束

- 步骤 3 之前必须先有 `{stem}.md`（步骤 1）和 `wage_records.json`（步骤 2）。
- 所有产物写到 `/mnt/user-data/outputs/`。
- `audit.py` 报错时把 traceback 原样交给用户。
