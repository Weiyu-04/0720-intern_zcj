"""农民工工资 vs 考勤对账入口（纯确定性：考勤计算 + 对账 + Excel）。

工作流：
    1. Agent 对工资 PDF 调用 parse_document → outputs/{stem}.md
    2. Agent 读 md，按 JSON 契约抽出工资记录 → outputs/wage_records.json
    3. python audit.py --wage-json outputs/wage_records.json \\
           --uploads /mnt/user-data/uploads --output-dir /mnt/user-data/outputs
"""
from __future__ import annotations

import argparse
import json
import logging
import re
import sys
from pathlib import Path

_SCRIPTS_DIR = Path(__file__).resolve().parent
if str(_SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS_DIR))

from app.compare.reconcile import (  # noqa: E402
    CAT_ATTEND_NO_WAGE,
    CAT_DAYS_MISMATCH,
    CAT_MATCH_OK,
    CAT_WAGE_NO_ATTEND,
)
from app.pipeline import load_config, load_wage_records, run_review  # noqa: E402

_DEFAULT_CONFIG = _SCRIPTS_DIR / "config.yaml"


def _find_file(cwd: Path, pattern: str) -> Path | None:
    hits = sorted(cwd.glob(pattern))
    return hits[0] if hits else None


def _resolve_file(path: Path) -> Path:
    p = path.expanduser()
    if p.is_file():
        return p.resolve()
    parent = p.parent
    if not parent.is_dir():
        return p
    want = p.name.replace(" ", "")
    for candidate in sorted(parent.iterdir()):
        if candidate.is_file() and candidate.name.replace(" ", "") == want:
            logging.warning("路径修正（忽略空格差异）: %s -> %s", p.name, candidate.name)
            return candidate.resolve()
    return p


def infer_wage_month(name: str) -> str | None:
    """从文件名（如 ``江颐202601农民工资``）推断 ``YYYY-MM``。"""
    stem = Path(name).stem.replace(" ", "")
    m = re.search(r"(\d{4})(\d{2})", stem)
    if not m:
        return None
    year, month = int(m.group(1)), int(m.group(2))
    if 1 <= month <= 12:
        return f"{year}-{month:02d}"
    return None


def _month_from_wage_json(path: Path) -> str | None:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict):
        return None
    month = str(data.get("month", "") or "").strip()
    return month or None


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="农民工工资 vs 考勤对账（纯确定性，工资记录由 Agent 抽取）")
    p.add_argument("--wage-json", default="", metavar="PATH", help="Agent 抽取的 wage_records.json 路径")
    p.add_argument("--uploads", default="", metavar="DIR", help="上传目录，自动找首个考勤 xlsx")
    p.add_argument("--attendance-xlsx", default="")
    p.add_argument("--config", default=str(_DEFAULT_CONFIG))
    p.add_argument("--output-dir", default="", metavar="DIR")
    p.add_argument("--wage-month", default="", help="省略时优先取 wage_records.json 的 month，再从文件名推断")
    return p.parse_args()


def main(args: argparse.Namespace) -> int:
    cwd = Path.cwd()
    cfg = load_config(Path(args.config))
    if args.output_dir:
        out = Path(args.output_dir).expanduser().resolve()
        out_cfg = cfg.setdefault("output", {})
        out_cfg["excel_dir"] = str(out)
        out_cfg["json_dir"] = str(out / "intermediate")
    logging.basicConfig(
        level=getattr(logging, cfg.get("project", {}).get("log_level", "INFO")),
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )

    if not args.wage_json:
        logging.error(
            "缺少 --wage-json。请先对工资 PDF 调用 parse_document，读取 md 后按 JSON 契约抽出 "
            "wage_records.json，再运行本脚本。"
        )
        return 1
    wage_json = _resolve_file(Path(args.wage_json))
    if not wage_json.is_file():
        logging.error("未找到工资记录 JSON: %s", args.wage_json)
        return 1

    try:
        wage = load_wage_records(wage_json)
    except (FileNotFoundError, ValueError) as exc:
        logging.error("%s", exc)
        return 1
    if not wage.records:
        logging.error("wage_records.json 未包含任何记录，请检查 Agent 抽取结果")
        return 1

    if args.uploads:
        uploads_dir = Path(args.uploads).expanduser().resolve()
        att_xlsx = _find_file(uploads_dir, "*.xlsx")
    else:
        att_xlsx = (
            _resolve_file(Path(args.attendance_xlsx))
            if args.attendance_xlsx
            else _find_file(cwd, "*.xlsx")
        )

    if att_xlsx is None or not att_xlsx.is_file():
        logging.error("未找到考勤 Excel")
        return 1

    logging.info("工资记录: %s（%d 人）", wage_json, len(wage.records))
    logging.info("考勤表: %s", att_xlsx)

    month = (
        args.wage_month.strip()
        or _month_from_wage_json(wage_json)
        or (infer_wage_month(wage.source_file) if wage.source_file else None)
        or cfg.get("review", {}).get("wage_month", "")
    )
    if not month:
        logging.error("缺少对账月份。请检查 wage_records.json 的 month 字段，或传 --wage-month YYYY-MM。")
        return 1
    cfg.setdefault("review", {})["wage_month"] = month
    logging.info("对账月份: %s", month)

    report = run_review(
        wage=wage,
        attendance_xlsx=att_xlsx.resolve(),
        cfg=cfg,
    )

    print("\n========== 对账汇总 ==========")
    print(f"月份: {report.wage_month}")
    for k, v in report.summary.items():
        print(f"  {k}: {v}")
    matched = [i for i in report.items if i.category == CAT_MATCH_OK]
    issues = [i for i in report.items if i.category != CAT_MATCH_OK]
    print(f"\n匹配正常 {len(matched)} 人")
    if matched[:5]:
        print("  示例:", ", ".join(f"{i.name}({i.wage_days}天)" for i in matched[:5]))
    print("\n========== 异常明细（前 30 条）==========")
    for item in issues[:30]:
        print(
            f"  [{item.category}] {item.name} | "
            f"工资={item.wage_days} 实际={item.actual_days} | {item.remark}"
        )
    if len(report.items) > 30:
        print(f"  ... 共 {len(report.items)} 条，详见 outputs/*.xlsx")
    _ = (CAT_ATTEND_NO_WAGE, CAT_DAYS_MISMATCH, CAT_WAGE_NO_ATTEND)
    return 0


if __name__ == "__main__":
    sys.exit(main(parse_args()))
