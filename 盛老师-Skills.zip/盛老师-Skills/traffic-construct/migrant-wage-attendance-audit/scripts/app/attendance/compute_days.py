"""从考勤导出 Excel 计算每人有效出勤天数。"""
from __future__ import annotations

import logging
from collections import defaultdict
from datetime import date, datetime
from pathlib import Path
from typing import Dict, List, Tuple

import pandas as pd

from app.schemas import AttendanceResult, PersonDays

logger = logging.getLogger(__name__)

# 列名（导出表固定列）
COL_NAME = "姓名"
COL_TIME = "打卡时间"
COL_SHIFT = "进场上班or出厂下班"

SHIFT_IN = "上班"
SHIFT_OUT = "下班"


def _normalize_shift(v: str) -> str:
    s = str(v or "").strip()
    if s in (SHIFT_IN, "进场", "进场上班"):
        return SHIFT_IN
    if s in (SHIFT_OUT, "出场", "出厂下班"):
        return SHIFT_OUT
    return s


def _day_work_hours(events: List[Tuple[datetime, str]]) -> float:
    """当日邻近 上班-下班 配对累计工时（小时）。"""
    events = sorted(events, key=lambda x: x[0])
    total_sec = 0.0
    i = 0
    while i < len(events):
        t_in, kind = events[i]
        if kind != SHIFT_IN:
            i += 1
            continue
        j = i + 1
        while j < len(events) and events[j][1] != SHIFT_OUT:
            j += 1
        if j < len(events):
            t_out = events[j][0]
            delta = (t_out - t_in).total_seconds()
            if delta > 0:
                total_sec += delta
            i = j + 1
        else:
            break
    return total_sec / 3600.0


def compute_attendance_days(
    xlsx_path: Path,
    *,
    month: str,
    min_hours_per_valid_day: float = 8.0,
) -> AttendanceResult:
    """读取考勤 Excel，按月份汇总每人有效出勤天数。"""
    df = pd.read_excel(xlsx_path)
    for col in (COL_NAME, COL_TIME, COL_SHIFT):
        if col not in df.columns:
            raise ValueError(f"考勤表缺少列: {col}，实际列: {list(df.columns)}")

    df = df.copy()
    df[COL_TIME] = pd.to_datetime(df[COL_TIME], errors="coerce")
    df = df.dropna(subset=[COL_TIME, COL_NAME])
    df[COL_SHIFT] = df[COL_SHIFT].map(_normalize_shift)

    year, mon = map(int, month.split("-"))
    df = df[(df[COL_TIME].dt.year == year) & (df[COL_TIME].dt.month == mon)]

    # name -> date -> events
    by_person_day: Dict[str, Dict[date, List[Tuple[datetime, str]]]] = defaultdict(
        lambda: defaultdict(list)
    )
    for _, row in df.iterrows():
        name = str(row[COL_NAME]).strip()
        if not name:
            continue
        ts: datetime = row[COL_TIME].to_pydatetime() if hasattr(row[COL_TIME], "to_pydatetime") else row[COL_TIME]
        shift = _normalize_shift(row[COL_SHIFT])
        if shift not in (SHIFT_IN, SHIFT_OUT):
            continue
        by_person_day[name][ts.date()].append((ts, shift))

    records: List[PersonDays] = []
    for name, days_map in sorted(by_person_day.items()):
        valid_days = 0
        for day_events in days_map.values():
            hours = _day_work_hours(day_events)
            if hours >= min_hours_per_valid_day:
                valid_days += 1
        records.append(PersonDays(name=name, days=float(valid_days)))

    logger.info(
        "[考勤] %s 月份 %s：%d 人有有效出勤记录",
        xlsx_path.name, month, len(records),
    )
    return AttendanceResult(
        source_file=xlsx_path.name,
        month=month,
        records=records,
    )


__all__ = ["compute_attendance_days"]
