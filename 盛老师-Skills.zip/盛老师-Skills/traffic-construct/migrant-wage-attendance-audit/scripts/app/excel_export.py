"""导出对账 Excel。"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font

from app.schemas import AttendanceResult, ReconcileReport, WageSheetResult


def _write_sheet(ws, headers: List[str], rows: List[List[Any]]) -> None:
    ws.append(headers)
    for cell in ws[1]:
        cell.font = Font(bold=True)
    for row in rows:
        ws.append(row)
    for col in ws.columns:
        max_len = 0
        col_letter = col[0].column_letter
        for cell in col:
            if cell.value is not None:
                max_len = max(max_len, len(str(cell.value)))
        ws.column_dimensions[col_letter].width = min(max_len + 2, 50)


def export_report(
    out_dir: Path,
    *,
    wage: WageSheetResult,
    attendance: AttendanceResult,
    reconcile: ReconcileReport,
    intermediate: Dict[str, Any] | None = None,
) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    xlsx_path = out_dir / f"农民工工资对账_{ts}.xlsx"

    wb = Workbook()
    # 工资单
    ws1 = wb.active
    ws1.title = "工资单出勤"
    _write_sheet(
        ws1,
        ["姓名", "工资单出勤天数"],
        [[r.name, r.days] for r in wage.records],
    )
    # 实际考勤
    ws2 = wb.create_sheet("实际考勤")
    _write_sheet(
        ws2,
        ["姓名", f"实际有效出勤天数({attendance.month})"],
        [[r.name, r.days] for r in attendance.records],
    )
    # 对账明细（含匹配正常 + 各类异常）
    ws3 = wb.create_sheet("对账明细")
    _write_sheet(
        ws3,
        ["类别", "姓名", "工资单出勤", "实际考勤", "说明"],
        [
            [
                i.category,
                i.name,
                i.wage_days if i.wage_days is not None else "",
                i.actual_days if i.actual_days is not None else "",
                i.remark,
            ]
            for i in reconcile.items
        ],
    )
    # 汇总
    ws4 = wb.create_sheet("汇总")
    _write_sheet(
        ws4,
        ["项目", "数值"],
        [
            ["工资单人数", len(wage.records)],
            ["考勤人数", len(attendance.records)],
            ["匹配正常", reconcile.summary.get("匹配正常", 0)],
            ["有出勤没薪资", reconcile.summary.get("有出勤没薪资", 0)],
            ["有薪资没出勤", reconcile.summary.get("有薪资没出勤", 0)],
            ["出勤天数不匹配", reconcile.summary.get("出勤天数不匹配", 0)],
            ["工资表序号", wage.table_index],
            ["姓名列表头", wage.name_column or "(启发式/默认)"],
            ["出勤天数列表头", wage.days_column or "(启发式/默认)"],
            ["LLM选表说明", wage.llm_reason],
        ],
    )
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                cell.alignment = Alignment(wrap_text=True, vertical="top")

    wb.save(xlsx_path)

    if intermediate is not None:
        json_dir = out_dir / "intermediate"
        json_dir.mkdir(parents=True, exist_ok=True)
        (json_dir / f"对账中间结果_{ts}.json").write_text(
            json.dumps(intermediate, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    return xlsx_path


__all__ = ["export_report"]
