"""比较类规则：金额相等、≥、≤、区间、相对误差。

设计原则：
- 输入容忍 None / 字符串 / int / float；非数字输入返回 False 而不抛异常；
- 金额比较默认开 abs + rel 双容差，避免浮点 / 单位转换微小差异误判；
- 区间判定支持半开半闭（lower=None / upper=None 表示无下/上界）。
"""
from __future__ import annotations

import logging
import math
from typing import Optional, Union

logger = logging.getLogger(__name__)

Number = Union[int, float]


def to_number(v) -> Optional[float]:
    """宽容地把任意输入转 float。失败返回 None。"""
    if v is None:
        return None
    if isinstance(v, bool):  # bool 是 int 子类，必须先过滤
        return None
    if isinstance(v, (int, float)):
        if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
            return None
        return float(v)
    if isinstance(v, str):
        s = v.strip().replace(",", "").replace("，", "").replace(" ", "")
        if not s:
            return None
        try:
            return float(s)
        except ValueError:
            return None
    return None


def amounts_equal(
    a, b,
    *,
    abs_tolerance: float = 1.0,
    rel_tolerance: float = 0.001,
) -> bool:
    """金额相等：abs_tolerance + rel_tolerance 双容差，任一通过即视为相等。

    默认 1 元绝对容差 + 0.1% 相对容差。
    """
    av, bv = to_number(a), to_number(b)
    if av is None or bv is None:
        return False
    diff = abs(av - bv)
    if diff <= abs_tolerance:
        return True
    denom = max(abs(av), abs(bv))
    if denom == 0:
        return diff <= abs_tolerance
    return (diff / denom) <= rel_tolerance


def gte(a, threshold: Number, *, abs_tolerance: float = 0.0) -> bool:
    """a >= threshold；abs_tolerance 用于容忍下边界微小浮点偏差。"""
    av = to_number(a)
    if av is None:
        return False
    return av >= (threshold - abs_tolerance)


def lte(a, threshold: Number, *, abs_tolerance: float = 0.0) -> bool:
    av = to_number(a)
    if av is None:
        return False
    return av <= (threshold + abs_tolerance)


def gt(a, threshold: Number) -> bool:
    av = to_number(a)
    return av is not None and av > threshold


def lt(a, threshold: Number) -> bool:
    av = to_number(a)
    return av is not None and av < threshold


def in_range(
    a,
    *,
    lower: Optional[Number] = None,
    upper: Optional[Number] = None,
    inclusive_lower: bool = True,
    inclusive_upper: bool = True,
) -> bool:
    """区间判定。lower / upper 为 None 表示无该侧边界。"""
    av = to_number(a)
    if av is None:
        return False
    if lower is not None:
        ok = av >= lower if inclusive_lower else av > lower
        if not ok:
            return False
    if upper is not None:
        ok = av <= upper if inclusive_upper else av < upper
        if not ok:
            return False
    return True


def relative_diff(a, b) -> Optional[float]:
    """返回 |a-b| / max(|a|, |b|)；任一无效返回 None。常用于审计报告里描述偏差比例。"""
    av, bv = to_number(a), to_number(b)
    if av is None or bv is None:
        return None
    denom = max(abs(av), abs(bv))
    if denom == 0:
        return 0.0
    return abs(av - bv) / denom


def diff_signed(a, b) -> Optional[float]:
    """返回 a - b；任一无效返回 None。"""
    av, bv = to_number(a), to_number(b)
    if av is None or bv is None:
        return None
    return av - bv


__all__ = [
    "to_number",
    "amounts_equal",
    "gte", "lte", "gt", "lt",
    "in_range",
    "relative_diff",
    "diff_signed",
]
