"""模糊匹配：处理 OCR / VL 抽取里的常见噪声（空白、半全角、相近字、姓名后缀混淆）。

核心场景：
- 姓名匹配：「张 三」 ≡ 「张三」、「李四丰」 ≢ 「李四」（后缀不允许）；
- 字段相等（不强求逐字）；
- 拼音兜底（可选，需要 pypinyin）。

设计原则：
- normalize_for_match 默认温和（只去空白 / 标点 / 全角→半角）；
- aggressive=True 时再做常见 OCR 混淆字归一化（0/O、1/l/I 等），但只在用户明确开启时启用。
"""
from __future__ import annotations

import logging
import re
import unicodedata
from typing import Iterable, List, Optional, Sequence

logger = logging.getLogger(__name__)

# 默认要剥的标点（中英全角）
_PUNCT_RE = re.compile(r"[\s\u3000\.\,\-\_\(\)（）\[\]【】《》<>\"'`、，。；;：:!！?？]+")

# OCR 常见混淆字（仅 aggressive=True 时生效）
_AGGRESSIVE_MAP = str.maketrans({
    "O": "0", "o": "0", "Q": "0",
    "I": "1", "l": "1", "i": "1",
    "Z": "2", "z": "2",
    "S": "5", "s": "5",
    "G": "6", "g": "6",
    "B": "8", "b": "8",
})


def normalize_for_match(s: str, *, aggressive: bool = False) -> str:
    """标准化：全角→半角 + 去空白/标点 + 大小写归一 + （可选）OCR 混淆字归一化。"""
    if s is None:
        return ""
    s = str(s)
    # 全角 → 半角；NFKC 同时把全角数字 / 字母 / 空格归一
    s = unicodedata.normalize("NFKC", s)
    s = _PUNCT_RE.sub("", s).lower()
    if aggressive:
        s = s.translate(_AGGRESSIVE_MAP)
    return s


def fuzzy_equal(
    a: str,
    b: str,
    *,
    aggressive: bool = False,
) -> bool:
    """字段宽松相等：normalize 后逐字相等。"""
    return normalize_for_match(a, aggressive=aggressive) == normalize_for_match(b, aggressive=aggressive)


def name_match(
    name: str,
    candidates: Iterable[str],
    *,
    aggressive: bool = False,
) -> Optional[str]:
    """姓名匹配：candidates 中是否有"完全相等"的姓名（不允许后缀差异）。

    返回命中的 candidate 原文；未命中返回 None。

    示例：
        name_match("张 三", ["张三", "张三丰"]) → "张三"  ✓
        name_match("张三丰", ["张三"]) → None  （后缀不允许）✓
        name_match("张三", ["李四"]) → None
    """
    target = normalize_for_match(name, aggressive=aggressive)
    if not target:
        return None
    for c in candidates:
        if normalize_for_match(c, aggressive=aggressive) == target:
            return c
    return None


def best_name_match(
    name: str,
    candidates: Iterable[str],
    *,
    aggressive: bool = False,
) -> Optional[str]:
    """姓名最佳匹配：先尝试 name_match；失败时返回字符级最长公共前缀≥2 的候选。

    用于"OCR 漏字"场景（如「李新民」OCR 成「李新」），但要求 candidates 里至少有一个前缀匹配。
    """
    direct = name_match(name, candidates, aggressive=aggressive)
    if direct is not None:
        return direct
    target = normalize_for_match(name, aggressive=aggressive)
    if not target:
        return None
    best: Optional[str] = None
    best_len = 0
    for c in candidates:
        ck = normalize_for_match(c, aggressive=aggressive)
        if not ck:
            continue
        common = 0
        for i in range(min(len(target), len(ck))):
            if target[i] == ck[i]:
                common += 1
            else:
                break
        if common >= 2 and common > best_len:
            best, best_len = c, common
    return best


def pinyin_equal(a: str, b: str) -> bool:
    """拼音兜底：两个姓名转拼音后相等（需要 pip install pypinyin）。

    用于处理 OCR 把"张"识别成"章"这类同音字。务必只在 fuzzy_equal 失败时再回退。
    """
    try:
        from pypinyin import lazy_pinyin  # type: ignore[import-not-found]
    except ImportError:
        logger.debug("pypinyin 未安装，pinyin_equal 直接返回 False")
        return False
    if not a or not b:
        return False
    pa = "".join(lazy_pinyin(a)).lower()
    pb = "".join(lazy_pinyin(b)).lower()
    return pa == pb


def any_match(
    target: str,
    candidates: Iterable[str],
    *,
    aggressive: bool = False,
    use_pinyin: bool = False,
) -> Optional[str]:
    """串联：精确 → 模糊 → 前缀 → 拼音；返回首次命中的 candidate。"""
    cands_list: List[str] = list(candidates)
    direct = name_match(target, cands_list, aggressive=aggressive)
    if direct is not None:
        return direct
    if use_pinyin:
        for c in cands_list:
            if pinyin_equal(target, c):
                return c
    return None


__all__ = [
    "normalize_for_match",
    "fuzzy_equal",
    "name_match",
    "best_name_match",
    "pinyin_equal",
    "any_match",
]
