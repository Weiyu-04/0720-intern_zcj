"""audit-rule-code 脚本包：纯代码规则判断。

- compare.py：金额 / 数字相等、阈值、区间、相对偏差；
- fuzzy_match.py：OCR 噪声容忍的字符串/姓名模糊匹配（含可选拼音兜底）。
"""

__all__ = ["compare", "fuzzy_match"]
