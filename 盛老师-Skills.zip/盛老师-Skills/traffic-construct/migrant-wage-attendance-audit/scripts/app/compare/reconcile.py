"""工资单出勤 vs 实际考勤对账（代码规则，无需 LLM）。"""
from __future__ import annotations

import logging
from typing import Dict, List, Optional, Tuple

from app.audit_rules.compare import amounts_equal
from app.audit_rules.fuzzy_match import name_match, normalize_for_match
from app.schemas import AttendanceResult, PersonDays, ReconcileItem, ReconcileReport, WageSheetResult

logger = logging.getLogger(__name__)

CAT_MATCH_OK = "匹配正常"
CAT_ATTEND_NO_WAGE = "有出勤没薪资"
CAT_WAGE_NO_ATTEND = "有薪资没出勤"
CAT_DAYS_MISMATCH = "出勤天数不匹配"

# Excel / 控制台展示顺序
CATEGORY_ORDER = (
    CAT_MATCH_OK,
    CAT_DAYS_MISMATCH,
    CAT_WAGE_NO_ATTEND,
    CAT_ATTEND_NO_WAGE,
)


def _index_by_name(records: List[PersonDays]) -> Dict[str, PersonDays]:
    out: Dict[str, PersonDays] = {}
    for r in records:
        key = normalize_for_match(r.name)
        if key and key not in out:
            out[key] = r
    return out


def _match_name(
    name: str,
    other_records: List[PersonDays],
) -> Optional[PersonDays]:
    hit = name_match(name, [r.name for r in other_records])
    if not hit:
        return None
    for r in other_records:
        if normalize_for_match(r.name) == normalize_for_match(hit):
            return r
    return None


def reconcile_wage_and_attendance(
    wage: WageSheetResult,
    attendance: AttendanceResult,
    *,
    day_tolerance: float = 0.0,
) -> ReconcileReport:
    wage_by = _index_by_name(wage.records)
    att_by = _index_by_name(attendance.records)
    items: List[ReconcileItem] = []

    matched_att_keys: set[str] = set()

    for w in wage.records:
        w_key = normalize_for_match(w.name)
        att_rec = _match_name(w.name, attendance.records)
        if att_rec is None:
            items.append(
                ReconcileItem(
                    category=CAT_WAGE_NO_ATTEND,
                    name=w.name,
                    wage_days=w.days,
                    actual_days=None,
                    remark="工资单有记录，考勤中未找到对应姓名",
                )
            )
            continue
        a_key = normalize_for_match(att_rec.name)
        matched_att_keys.add(a_key)
        if amounts_equal(w.days, att_rec.days, abs_tolerance=day_tolerance, rel_tolerance=0):
            items.append(
                ReconcileItem(
                    category=CAT_MATCH_OK,
                    name=w.name,
                    wage_days=w.days,
                    actual_days=att_rec.days,
                    remark=f"工资单与考勤均为 {w.days} 天",
                )
            )
        else:
            items.append(
                ReconcileItem(
                    category=CAT_DAYS_MISMATCH,
                    name=w.name,
                    wage_days=w.days,
                    actual_days=att_rec.days,
                    remark=f"工资单出勤 {w.days} 天，实际考勤 {att_rec.days} 天",
                )
            )

    for a in attendance.records:
        if a.days <= 0:
            continue
        a_key = normalize_for_match(a.name)
        if a_key in matched_att_keys:
            continue
        if _match_name(a.name, wage.records) is None:
            items.append(
                ReconcileItem(
                    category=CAT_ATTEND_NO_WAGE,
                    name=a.name,
                    wage_days=None,
                    actual_days=a.days,
                    remark="考勤有有效出勤，工资单中未找到对应姓名",
                )
            )

    order_map = {c: i for i, c in enumerate(CATEGORY_ORDER)}
    items.sort(key=lambda x: (order_map.get(x.category, 99), x.name))

    summary = {
        CAT_MATCH_OK: sum(1 for i in items if i.category == CAT_MATCH_OK),
        CAT_ATTEND_NO_WAGE: sum(1 for i in items if i.category == CAT_ATTEND_NO_WAGE),
        CAT_WAGE_NO_ATTEND: sum(1 for i in items if i.category == CAT_WAGE_NO_ATTEND),
        CAT_DAYS_MISMATCH: sum(1 for i in items if i.category == CAT_DAYS_MISMATCH),
    }
    logger.info("[对账] 汇总: %s", summary)
    return ReconcileReport(
        wage_file=wage.source_file,
        attendance_file=attendance.source_file,
        wage_month=attendance.month,
        items=items,
        summary=summary,
    )


__all__ = [
    "reconcile_wage_and_attendance",
    "CAT_MATCH_OK",
    "CAT_ATTEND_NO_WAGE",
    "CAT_WAGE_NO_ATTEND",
    "CAT_DAYS_MISMATCH",
]
