"""农民工工资 vs 考勤 确定性管线（考勤计算 + 对账 + Excel 导出，零 LLM）。

工资记录由 Lead Agent 读取 parse_document 产出的 markdown 后，按 JSON 契约抽出
并写入 ``wage_records.json``；本管线只负责确定性计算，不创建任何 LLM 客户端。
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict

import yaml

from app.attendance.compute_days import compute_attendance_days
from app.audit_rules.compare import to_number
from app.compare.reconcile import reconcile_wage_and_attendance
from app.excel_export import export_report
from app.schemas import PersonDays, ReconcileReport, WageSheetResult

logger = logging.getLogger(__name__)


def load_config(path: Path) -> Dict[str, Any]:
    """读取 config.yaml（仅 review / output / project 段，无 LLM）。"""
    resolved = Path(path).expanduser()
    if not resolved.is_file():
        return {}
    return yaml.safe_load(resolved.read_text(encoding="utf-8")) or {}


def load_wage_records(path: Path) -> WageSheetResult:
    """从 Agent 抽取的 ``wage_records.json`` 构造 ``WageSheetResult``（纯 json → dataclass）。

    契约：``{"source_file": str, "month": str, "records": [{"name": str, "days": number}]}``。
    """
    resolved = Path(path).expanduser().resolve()
    if not resolved.is_file():
        raise FileNotFoundError(f"工资记录 JSON 不存在: {path}")

    data = json.loads(resolved.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict):
        raise ValueError(f"wage_records.json 顶层必须是对象: {path}")

    raw_records = data.get("records", [])
    if not isinstance(raw_records, list):
        raise ValueError("wage_records.json 的 records 字段必须是数组")

    records = []
    for r in raw_records:
        if not isinstance(r, dict):
            continue
        name = str(r.get("name", "") or "").strip()
        if not name:
            continue
        days = to_number(r.get("days", 0))
        records.append(PersonDays(name=name, days=float(days) if days is not None else 0.0))

    return WageSheetResult(
        source_file=str(data.get("source_file", "") or ""),
        records=records,
    )


def run_review(
    *,
    wage: WageSheetResult,
    attendance_xlsx: Path,
    cfg: Dict[str, Any],
) -> ReconcileReport:
    """确定性流程：考勤计算 → 对账 → Excel 导出（不含任何 LLM/OCR）。"""
    review_cfg = cfg.get("review", {})
    month = str(review_cfg.get("wage_month", "") or "").strip()
    min_hours = float(review_cfg.get("min_hours_per_valid_day", 8.0))
    day_tol = float(review_cfg.get("attendance_day_tolerance", 0))

    if not wage.records:
        raise RuntimeError("工资记录为空，请检查 wage_records.json 的 records 字段")
    if not month:
        raise ValueError("缺少对账月份，请在 wage_records.json.month 中提供，或通过 --wage-month YYYY-MM 传入")

    logger.info("Step1 工资记录 %d 条（来自 Agent 抽取）", len(wage.records))

    out_cfg = cfg.get("output", {})

    logger.info("Step2 计算实际考勤: %s", attendance_xlsx.name)
    attendance = compute_attendance_days(
        attendance_xlsx,
        month=month,
        min_hours_per_valid_day=min_hours,
    )

    logger.info("Step3 对账")
    report = reconcile_wage_and_attendance(
        wage,
        attendance,
        day_tolerance=day_tol,
    )

    excel_dir = Path(out_cfg.get("excel_dir", "./outputs"))
    intermediate = {
        "wage": wage.to_dict(),
        "attendance": attendance.to_dict(),
        "reconcile": report.to_dict(),
    }
    xlsx_out = export_report(
        excel_dir,
        wage=wage,
        attendance=attendance,
        reconcile=report,
        intermediate=intermediate if out_cfg.get("include_intermediate_json") else None,
    )
    logger.info("报告已写入: %s", xlsx_out)

    return report


__all__ = ["load_config", "load_wage_records", "run_review"]
