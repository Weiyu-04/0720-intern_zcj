"""数据模型。"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class PersonDays:
    name: str
    days: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {"name": self.name, "days": self.days}


@dataclass
class WageSheetResult:
    source_file: str
    table_index: int = -1
    records: List[PersonDays] = field(default_factory=list)
    llm_reason: str = ""
    name_column: str = ""
    days_column: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "source_file": self.source_file,
            "table_index": self.table_index,
            "name_column": self.name_column,
            "days_column": self.days_column,
            "llm_reason": self.llm_reason,
            "records": [r.to_dict() for r in self.records],
        }


@dataclass
class AttendanceResult:
    source_file: str
    month: str
    records: List[PersonDays] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "source_file": self.source_file,
            "month": self.month,
            "records": [r.to_dict() for r in self.records],
        }


@dataclass
class ReconcileItem:
    category: str
    name: str
    wage_days: Optional[float] = None
    actual_days: Optional[float] = None
    remark: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "category": self.category,
            "name": self.name,
            "wage_days": self.wage_days,
            "actual_days": self.actual_days,
            "remark": self.remark,
        }


@dataclass
class ReconcileReport:
    wage_file: str
    attendance_file: str
    wage_month: str
    items: List[ReconcileItem] = field(default_factory=list)
    summary: Dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "wage_file": self.wage_file,
            "attendance_file": self.attendance_file,
            "wage_month": self.wage_month,
            "summary": self.summary,
            "items": [i.to_dict() for i in self.items],
        }
