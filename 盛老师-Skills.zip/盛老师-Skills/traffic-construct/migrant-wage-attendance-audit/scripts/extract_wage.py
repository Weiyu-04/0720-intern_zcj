"""从工资 md 按大脑指定的列提取 wage_records.json。

边界：
- 脚本只负责机械解析表格、展示候选表格、按指定列提取。
- 大脑负责判断哪一列是姓名、哪一列是工资单出勤天数。

推荐工作流：

    python extract_wage.py --md /mnt/user-data/outputs/工资.md --inspect

大脑根据 inspect 输出判断列后，再运行：

    python extract_wage.py \
        --md /mnt/user-data/outputs/工资.md \
        --name-column 姓名 \
        --days-column 出勤天数 \
        --output /mnt/user-data/outputs/wage_records.json

如果 OCR 表头不稳定，也可以用 0-based 列序号：

    python extract_wage.py --md 工资.md --name-index 1 --days-index 6
"""
from __future__ import annotations

import argparse
import html
import json
import logging
import re
import sys
from dataclasses import dataclass
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
logger = logging.getLogger("extract_wage")

_SKIP_NAMES = re.compile(r"^(合\s*计|小\s*计|总\s*计|汇\s*总|备\s*注|签\s*字|注|—|-|/)$")
_WAGE_SECTION = re.compile(r"工\s*资\s*(支\s*付\s*表|发\s*放\s*表|明\s*细\s*表|汇\s*总\s*表|表)")
_ATTEND_SECTION = re.compile(r"考\s*勤\s*表|打\s*卡\s*记\s*录")


@dataclass
class Table:
    """解析出的候选表格。"""

    index: int
    source: str
    rows: list[list[str]]

    @property
    def header(self) -> list[str]:
        return self.rows[0] if self.rows else []

    @property
    def data_rows(self) -> list[list[str]]:
        return self.rows[1:] if len(self.rows) > 1 else []


def _strip_html(text: str) -> str:
    return html.unescape(re.sub(r"<[^>]+>", "", text)).strip()


def _clean_cell(text: str) -> str:
    return _strip_html(text).replace("\u3000", " ").strip()


def _clean_name(text: str) -> str:
    return _clean_cell(text).replace(" ", "")


def _to_float(text: str) -> float | None:
    normalized = _clean_cell(text).replace(",", "").replace("，", "")
    try:
        return float(normalized)
    except ValueError:
        return None


def _is_skip_name(name: str) -> bool:
    return not name or bool(_SKIP_NAMES.match(name))


def _extract_wage_section(text: str) -> str:
    """尽量裁出工资表段，避免后续考勤表混入；找不到标题时返回全文。"""
    wage_pos = _WAGE_SECTION.search(text)
    if not wage_pos:
        return text

    section = text[wage_pos.start():]
    attend_pos = _ATTEND_SECTION.search(section, wage_pos.end() - wage_pos.start() + 1)
    if attend_pos:
        section = section[: attend_pos.start()]
    return section


def _parse_html_tables(text: str) -> list[Table]:
    table_blocks = re.findall(r"(<table[^>]*>.*?</table>)", text, re.DOTALL | re.IGNORECASE)
    if not table_blocks and re.search(r"<tr[^>]*>", text, re.IGNORECASE):
        table_blocks = [text]

    tables: list[Table] = []
    for block in table_blocks:
        rows: list[list[str]] = []
        for row in re.findall(r"<tr[^>]*>(.*?)</tr>", block, re.DOTALL | re.IGNORECASE):
            cells = [
                _clean_cell(cell)
                for cell in re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", row, re.DOTALL | re.IGNORECASE)
            ]
            if cells:
                rows.append(cells)
        if rows:
            tables.append(Table(index=len(tables), source="html", rows=rows))
    return tables


def _parse_pipe_tables(text: str) -> list[Table]:
    tables: list[Table] = []
    current: list[list[str]] = []

    def flush() -> None:
        nonlocal current
        if current:
            tables.append(Table(index=len(tables), source="pipe", rows=current))
            current = []

    for line in text.splitlines():
        line = line.strip()
        if not line.startswith("|"):
            flush()
            continue

        parts = [_clean_cell(p) for p in line.strip("|").split("|")]
        if not parts:
            continue
        if all(re.match(r"^[-: ]+$", p) for p in parts if p):
            continue
        current.append(parts)

    flush()
    return tables


def parse_tables(md_path: str | Path) -> list[Table]:
    path = Path(md_path)
    if not path.is_file():
        raise FileNotFoundError(f"md 文件不存在: {md_path}")

    text = path.read_text(encoding="utf-8", errors="ignore")
    section = _extract_wage_section(text)

    # 两种格式都解析；inspect 阶段让大脑自己看候选表。
    tables = _parse_html_tables(section) + _parse_pipe_tables(section)
    if not tables:
        raise ValueError("未解析到候选表格：md 中既没有 HTML 表格，也没有 Markdown pipe 表格。")

    # 过滤太短的表格，但不做语义判断。
    return [t for t in tables if len(t.rows) >= 2]


def _resolve_column(table: Table, *, column_name: str = "", column_index: int | None = None, role: str) -> int:
    if column_index is not None:
        if column_index < 0 or column_index >= len(table.header):
            raise ValueError(f"{role}列序号越界: {column_index}，当前表共有 {len(table.header)} 列")
        return column_index

    wanted = column_name.strip()
    if not wanted:
        raise ValueError(f"缺少 {role} 列。请传 --{role}-column 或 --{role}-index")

    header_map = {h.strip(): i for i, h in enumerate(table.header)}
    if wanted in header_map:
        return header_map[wanted]

    # 只做精确列名失败后的轻量容错：去空格比较。语义仍由大脑指定。
    compact_wanted = wanted.replace(" ", "")
    for i, header in enumerate(table.header):
        if header.replace(" ", "") == compact_wanted:
            return i

    raise ValueError(
        f"表 {table.index} 中找不到 {role} 列名 {wanted!r}。"
        f"可先运行 --inspect 查看表头，或改用 --{role}-index。"
    )


def _select_table(tables: list[Table], table_index: int | None) -> Table:
    if table_index is None:
        if len(tables) == 1:
            return tables[0]
        raise ValueError(f"解析到 {len(tables)} 张候选表，请先 --inspect 后传 --table-index 指定工资表。")

    if table_index < 0 or table_index >= len(tables):
        raise ValueError(f"--table-index 越界: {table_index}，候选表数量为 {len(tables)}")
    return tables[table_index]


def _dedup(records: list[dict]) -> list[dict]:
    seen: set[str] = set()
    result: list[dict] = []
    for record in records:
        name = record["name"]
        if name in seen:
            continue
        seen.add(name)
        result.append(record)
    return result


def _infer_month(source_file: str) -> str:
    stem = Path(source_file).stem.replace(" ", "")
    match = re.search(r"(\d{4})(\d{2})", stem)
    if not match:
        return ""
    year, month = int(match.group(1)), int(match.group(2))
    if 1 <= month <= 12:
        return f"{year}-{month:02d}"
    return ""


def extract(
    md_path: str | Path,
    *,
    table_index: int | None = None,
    name_column: str = "",
    days_column: str = "",
    name_index: int | None = None,
    days_index: int | None = None,
    month: str = "",
    source_file: str = "",
) -> dict:
    """按大脑指定的列提取工资记录。"""
    tables = parse_tables(md_path)
    table = _select_table(tables, table_index)

    name_col = _resolve_column(table, column_name=name_column, column_index=name_index, role="name")
    days_col = _resolve_column(table, column_name=days_column, column_index=days_index, role="days")

    records: list[dict] = []
    for row in table.data_rows:
        if name_col >= len(row) or days_col >= len(row):
            continue

        name = _clean_name(row[name_col])
        days = _to_float(row[days_col])
        if _is_skip_name(name) or days is None:
            continue

        records.append({"name": name, "days": days})

    records = _dedup(records)
    if not records:
        raise ValueError("按指定列未提取到任何人员记录。请检查 --table-index、姓名列、天数列是否正确。")

    path = Path(md_path)
    sf = source_file or path.stem + ".pdf"
    return {"source_file": sf, "month": month or _infer_month(sf), "records": records}


def print_inspect(tables: list[Table], *, max_rows: int = 8) -> None:
    """打印候选表格，供大脑判断列语义。"""
    print(f"共解析到 {len(tables)} 张候选表。请根据表头和样例行选择工资表、姓名列、工资单出勤天数列。\n")

    for table in tables:
        print("=" * 80)
        print(f"table_index: {table.index} | source: {table.source} | rows: {len(table.rows)} | columns: {len(table.header)}")
        print("columns (0-based):")
        for i, header in enumerate(table.header):
            print(f"  [{i}] {header}")

        print("\nsample rows:")
        for row in table.data_rows[:max_rows]:
            preview = " | ".join(row[: len(table.header)])
            print(f"  {preview}")
        print()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="从工资 md 按指定列提取 wage_records.json")
    parser.add_argument("--md", required=True, metavar="PATH", help="parse_document 产出的 .md 文件")
    parser.add_argument("--inspect", action="store_true", help="只打印候选表格、列名和样例行，不输出 JSON")
    parser.add_argument("--table-index", type=int, default=None, help="候选表序号；多张表时必填")
    parser.add_argument("--name-column", default="", help="大脑判断出的姓名列列名（精确匹配，去空格容错）")
    parser.add_argument("--days-column", default="", help="大脑判断出的工资单出勤天数列列名（精确匹配，去空格容错）")
    parser.add_argument("--name-index", type=int, default=None, help="姓名列 0-based 序号；表头不稳定时使用")
    parser.add_argument("--days-index", type=int, default=None, help="工资单出勤天数列 0-based 序号；表头不稳定时使用")
    parser.add_argument("--output", default="", metavar="PATH", help="输出 JSON 路径；默认同目录 wage_records.json")
    parser.add_argument("--month", default="", metavar="YYYY-MM", help="对账月份；省略时从 source-file/md 文件名推断")
    parser.add_argument("--source-file", default="", metavar="NAME", help="工资 PDF 原始文件名（用于报告标注）")
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    try:
        tables = parse_tables(args.md)
        if args.inspect:
            print_inspect(tables)
            return 0

        result = extract(
            args.md,
            table_index=args.table_index,
            name_column=args.name_column,
            days_column=args.days_column,
            name_index=args.name_index,
            days_index=args.days_index,
            month=args.month,
            source_file=args.source_file,
        )
    except (FileNotFoundError, ValueError) as exc:
        logger.error("%s", exc)
        return 1

    out_path = Path(args.output) if args.output else Path(args.md).parent / "wage_records.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    logger.info("已写入 %s（%d 人）", out_path, len(result["records"]))
    for record in result["records"][:10]:
        print(f"  {record['name']}: {record['days']} 天")
    if len(result["records"]) > 10:
        print(f"  ... 共 {len(result['records'])} 人")
    return 0


if __name__ == "__main__":
    sys.exit(main())
