from .clarification_tool import ask_clarification_tool
from .parse_document_tool import parse_document_tool
from .parse_image_tool import parse_image_tool
from .present_file_tool import present_file_tool
from .setup_agent_tool import setup_agent
from .task_tool import task_tool
from .update_agent_tool import update_agent
from .view_image_tool import view_image_tool
from .wiki_tools import (
    read_wiki_index,
    read_wiki_page,
    search_wiki_tool,
    write_wiki_query_page,
)

__all__ = [
    "setup_agent",
    "update_agent",
    "present_file_tool",
    "ask_clarification_tool",
    "view_image_tool",
    "task_tool",
    "read_wiki_index",
    "read_wiki_page",
    "search_wiki_tool",
    "write_wiki_query_page",
    "parse_document_tool",
    "parse_image_tool",
    "all_builtin_tools",
]


def all_builtin_tools() -> list:
    """Return the complete list of platform builtin tools.

    Single source of truth for "which builtin tools exist". Used by the agent
    runtime (``tools.tools.get_available_tools``) AND the admin tool policy
    service (``app.gateway.admin_config_service``) so both views stay in sync
    without per-tool bookkeeping.

    Adds tools in registration order. Tools that may not be importable in all
    environments (``skill_manage_tool`` requires ``skill_evolution.enabled``)
    are best-effort included; callers that need a stricter view (e.g. only
    currently-bound tools) should use ``get_available_tools`` directly.
    """
    from zcjagent.tools.tools import BUILTIN_TOOLS, SUBAGENT_TOOLS

    tools = list(BUILTIN_TOOLS) + list(SUBAGENT_TOOLS)
    tools.extend([
        view_image_tool,
        read_wiki_index,
        read_wiki_page,
        search_wiki_tool,
        write_wiki_query_page,
        parse_document_tool,
        parse_image_tool,
    ])
    try:
        from zcjagent.tools.skill_manage_tool import skill_manage_tool

        tools.append(skill_manage_tool)
    except ImportError:
        pass
    return tools
