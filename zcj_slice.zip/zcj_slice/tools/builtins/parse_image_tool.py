"""Built-in tool that calls the admin-configured vision model for image understanding.

Wraps the model selected via ``task_models.image_parsing`` so any skill or agent
can perform OCR, image description, classification, structured extraction, etc.
without requiring the *main* agent's model to support vision.

The vision model's text answer is returned to the calling agent as the tool
result, keeping the image bytes out of the main agent's context window.
"""

from __future__ import annotations

import asyncio
import base64
import logging
from pathlib import Path

from langchain.tools import tool
from langchain_core.messages import HumanMessage

from zcjagent.config import get_app_config
from zcjagent.config.app_config import AppConfig
from zcjagent.models.factory import create_chat_model
from zcjagent.tools.builtins.parse_document_tool import _resolve_upload_file_path
from zcjagent.tools.builtins.view_image_tool import (
    _ALLOWED_IMAGE_VIRTUAL_ROOTS_TEXT,
    _EXTENSION_TO_MIME,
    _MAX_IMAGE_BYTES,
    _detect_image_mime,
    _is_allowed_image_virtual_path,
)
from zcjagent.tools.types import Runtime

logger = logging.getLogger(__name__)


def _resolve_vision_model_name(app_config: AppConfig) -> str | None:
    """Return the configured image_parsing model name, or None if unset/invalid."""
    task_models = getattr(app_config, "task_models", None)
    if task_models is None:
        return None
    name = getattr(task_models, "image_parsing", None)
    if not name:
        return None
    if app_config.get_model_config(name) is None:
        logger.warning(
            "task_models.image_parsing references unknown model %r; parse_image tool will report it as misconfigured",
            name,
        )
        return None
    return name


def _read_and_encode_image_sync(path: str) -> tuple[str, str]:
    """Validate, read, and base64-encode an image. Raises on any validation failure."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Image file not found: {path}")
    if not p.is_file():
        raise ValueError(f"Path is not a file: {path}")
    expected_mime = _EXTENSION_TO_MIME.get(p.suffix.lower())
    if expected_mime is None:
        raise ValueError(
            f"Unsupported image format: {p.suffix}. Supported: {', '.join(_EXTENSION_TO_MIME)}"
        )
    size = p.stat().st_size
    if size > _MAX_IMAGE_BYTES:
        raise ValueError(
            f"Image file is too large: {size} bytes. Maximum supported size is {_MAX_IMAGE_BYTES} bytes"
        )
    data = p.read_bytes()
    detected = _detect_image_mime(data)
    if detected is None:
        raise ValueError("File contents do not match a supported image format")
    if detected != expected_mime:
        raise ValueError(
            f"Image contents are {detected}, but file extension indicates {expected_mime}"
        )
    return base64.b64encode(data).decode("utf-8"), detected


def _extract_text(content: object) -> str:
    """Normalize a LangChain model response into a plain string."""
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, dict):
                text = block.get("text")
                if text:
                    parts.append(str(text))
            elif isinstance(block, str):
                parts.append(block)
        return "\n".join(parts)
    return str(content)


@tool("parse_image", parse_docstring=True)
async def parse_image_tool(runtime: Runtime, image_path: str, prompt: str) -> str:
    """Analyze an image using the admin-configured vision model.

    Use this tool when you need semantic understanding of an image, for example:
    - OCR / extracting text from an image
    - Describing the contents of a screenshot or photo
    - Classifying an image or answering questions about its content
    - Extracting structured data (forms, charts, tables) from an image

    The result is the vision model's text answer, returned to you for further
    processing. Unlike ``view_image``, this tool does NOT require your main
    model to support vision — it always delegates to a dedicated vision model
    set by the admin under 模型管理 → 任务模型指派 → 通用视觉解析.

    Args:
        image_path: Sandbox virtual path to the image file. Must be under
            ``/mnt/user-data/{workspace,uploads,outputs}``. Supports jpg, jpeg,
            png, webp.
        prompt: What you want to know about the image. Be specific — e.g.
            ``"Extract all visible text preserving layout"`` or
            ``"Describe the trend shown in this chart"``.
    """
    state = (runtime.state if runtime is not None else None) or {}
    thread_data = state.get("thread_data") or {}

    app_config = get_app_config()
    model_name = _resolve_vision_model_name(app_config)
    if model_name is None:
        return (
            "Error: parse_image is not configured. Ask the admin to set a vision "
            "model under 模型管理 → 任务模型指派 → 通用视觉解析 (task_models.image_parsing)."
        )

    if not _is_allowed_image_virtual_path(image_path):
        return f"Error: Only image paths under {_ALLOWED_IMAGE_VIRTUAL_ROOTS_TEXT} are allowed"

    try:
        resolved = _resolve_upload_file_path(image_path, thread_data)
    except Exception as exc:
        logger.exception("parse_image path resolution failed for %s", image_path)
        return f"Error: failed to resolve path {image_path}: {exc}"

    try:
        image_base64, mime_type = await asyncio.to_thread(_read_and_encode_image_sync, resolved)
    except (FileNotFoundError, ValueError) as exc:
        return f"Error: {exc}"
    except Exception as exc:
        logger.exception("parse_image failed to read image %s", image_path)
        return f"Error: failed to read image: {exc}"

    message = HumanMessage(
        content=[
            {"type": "text", "text": prompt},
            {"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{image_base64}"}},
        ]
    )

    try:
        model = create_chat_model(name=model_name, app_config=app_config, attach_tracing=False)
    except Exception as exc:
        logger.exception("parse_image failed to instantiate model %s", model_name)
        return f"Error: failed to initialize vision model '{model_name}': {exc}"

    try:
        response = await model.ainvoke([message])
    except Exception as exc:
        logger.exception("parse_image model invocation failed for %s", image_path)
        return f"Error: vision model call failed: {exc}"

    return _extract_text(getattr(response, "content", None))
