"""Built-in tool that parses PDF/PPT/Word/Excel/images into Markdown.

Wraps ``zcjagent.knowledge.parser.parse_document`` so any agent or skill can
trigger document parsing via the platform's configured MinerU SDK (with
markitdown fallback), without going through the knowledge-base upload flow.

Output is dual-track:
- Markdown is written to ``/mnt/user-data/outputs/{stem}.md`` (visible to user)
- Markdown content (or truncated preview for >50k chars) is returned to the
  agent for further processing.
"""

from __future__ import annotations

import logging
from pathlib import Path

from langchain.tools import tool

from zcjagent.knowledge.parser import parse_document_with_artifacts
from zcjagent.sandbox.tools import replace_virtual_path
from zcjagent.tools.types import Runtime

logger = logging.getLogger(__name__)

# Beyond this length, the inline tool result is truncated to a preview.
# The output file is still written in full.
_MAX_INLINE_CHARS = 50_000


def _resolve_upload_file_path(file_path: str, thread_data: dict | None) -> str:
    """Translate virtual path; fuzzy-match basename ignoring whitespace."""
    td = thread_data or {}
    resolved = replace_virtual_path(file_path, td)
    path = Path(resolved)
    if path.is_file():
        return resolved

    want = Path(file_path.replace("\\", "/")).name.replace(" ", "")
    search_dirs: list[Path] = []
    if "/uploads/" in file_path.replace("\\", "/"):
        upl = td.get("uploads_path")
        if upl:
            search_dirs.append(Path(upl))
    if path.parent not in search_dirs:
        search_dirs.append(path.parent)

    for parent in search_dirs:
        if not parent.is_dir():
            continue
        for candidate in sorted(parent.iterdir()):
            if candidate.is_file() and candidate.name.replace(" ", "") == want:
                logger.warning("路径修正（忽略空格差异）: %s -> %s", path.name, candidate.name)
                return str(candidate.resolve())
    return resolved


@tool("parse_document", parse_docstring=True)
async def parse_document_tool(runtime: Runtime, file_path: str) -> str:
    """Parse a document file (PDF/PPT/Word/Excel/Image) into Markdown.

    Calls the platform's MinerU SDK against the configured VLM server, with
    markitdown as automatic fallback. The parsed Markdown is both returned
    to the agent AND written to ``/mnt/user-data/outputs/{stem}.md`` so the
    user can see the result as a downloadable file.

    Use this tool when the user uploads a document and asks you to:
    - Extract text / tables from a PDF/PPT/Word/Excel file
    - Convert a document to Markdown
    - Read the content of an Office file you cannot otherwise open

    Do NOT use this tool for plain text or Markdown files — read those
    directly with ``read_file``.

    Args:
        file_path: Sandbox virtual path (e.g.
            ``/mnt/user-data/uploads/report.pdf``) or absolute host path.
            Virtual paths under ``/mnt/user-data/*`` are translated
            automatically to the current thread's host paths.
    """
    state = (runtime.state if runtime is not None else None) or {}
    thread_data = state.get("thread_data") or {}

    resolved = _resolve_upload_file_path(file_path, thread_data or None)

    try:
        content, middle = await parse_document_with_artifacts(resolved)
    except FileNotFoundError:
        return f"Error: file not found at {file_path}"
    except ValueError as exc:
        return f"Error: {exc}"
    except Exception as exc:
        logger.exception("parse_document tool failed for %s", file_path)
        return f"Error: failed to parse {file_path}: {exc}"

    stem = Path(resolved).stem
    outputs_path = thread_data.get("outputs_path")
    if outputs_path:
        outputs_dir = Path(outputs_path)
        virtual_out = f"/mnt/user-data/outputs/{stem}.md"
        virtual_middle = f"/mnt/user-data/outputs/{stem}_middle.json"
    else:
        outputs_dir = Path(resolved).parent
        virtual_out = str(outputs_dir / f"{stem}.md")
        virtual_middle = str(outputs_dir / f"{stem}_middle.json")

    outputs_dir.mkdir(parents=True, exist_ok=True)
    out_path = outputs_dir / f"{stem}.md"
    out_path.write_text(content, encoding="utf-8")

    middle_note = ""
    if middle:
        (outputs_dir / f"{stem}_middle.json").write_text(middle, encoding="utf-8")
        middle_note = f"\nPage-level layout written to {virtual_middle}"

    if len(content) > _MAX_INLINE_CHARS:
        preview = content[:_MAX_INLINE_CHARS]
        return (
            f"Parsed successfully ({len(content)} chars). Full Markdown written "
            f"to {virtual_out}.{middle_note} Inline result truncated to first "
            f"{_MAX_INLINE_CHARS} chars:\n\n---\n\n{preview}\n\n---\n\n"
            f"... ({len(content) - _MAX_INLINE_CHARS} more chars in file)"
        )

    return f"Parsed successfully. Markdown written to {virtual_out}.{middle_note}\n\n---\n\n{content}"
