"""Karpathy Wiki tools for agent progressive loading."""

from langchain.tools import tool
from zcjagent.knowledge.repository import KnowledgeRepository
from zcjagent.persistence.engine import get_session_factory


def _get_repo() -> KnowledgeRepository:
    return KnowledgeRepository(get_session_factory())


@tool("read_wiki_index", parse_docstring=True)
async def read_wiki_index(topic_id: str) -> str:
    """Read the wiki index page for a topic, listing all available pages with their type and summary.

    Use this as the first step when answering a question about a knowledge topic.
    The index page lists every wiki page with a one-line summary, allowing you to
    identify which pages are relevant before drilling deeper.

    Args:
        topic_id: The knowledge topic ID to read the index for
    """
    repo = _get_repo()
    index = await repo.get_index_page(topic_id)
    if index is None:
        return "No wiki index found for this topic. The topic may not have been ingested yet."
    return index["content"]


@tool("read_wiki_page", parse_docstring=True)
async def read_wiki_page(page_id: str) -> str:
    """Read a specific wiki page with full Markdown content, metadata, and backlinks.

    Use this after read_wiki_index to drill into pages that appear relevant.
    Returns the complete page content plus a list of other pages that link to this one.

    Args:
        page_id: The page ID to read (obtained from index or search results)
    """
    repo = _get_repo()
    page = await repo.get_page(page_id)
    if page is None:
        return f"Page not found: {page_id}"

    backlinks = await repo.get_pages_linking_to(page_id)
    lines = [
        f"# {page['title']}",
        f"Type: {page['page_type']}",
        f"---",
        "",
        page["content"],
        "",
    ]
    if backlinks:
        lines.append("## Backlinks (pages linking here)")
        for bl in backlinks:
            lines.append(f"- [[{bl['title']}]] ({bl['page_type']}) - id: {bl['id']}")
    if page.get("linked_page_ids"):
        lines.append("")
        lines.append("## Forward Links")
        for lid in page["linked_page_ids"]:
            linked = await repo.get_page(lid)
            if linked:
                lines.append(f"- [[{linked['title']}]] ({linked['page_type']}) - id: {lid}")
    return "\n".join(lines)


@tool("search_wiki", parse_docstring=True)
async def search_wiki_tool(topic_id: str, query: str) -> str:
    """Full-text search across wiki pages for a topic.

    Use this when the topic has more than ~50 pages or the index summaries aren't detailed enough.
    Returns top 10 matching pages with snippets. After finding relevant pages, use read_wiki_page for full content.

    Args:
        topic_id: The knowledge topic ID to search within
        query: Search query string (keywords or phrase)
    """
    repo = _get_repo()
    results = await repo.search_wiki_pages(topic_id, query, limit=10)
    if not results:
        return "No results found for this query."

    lines = [f"Search results for: '{query}'", ""]
    for r in results:
        lines.append(f"- **{r['title']}** ({r['page_type']}) - id: {r['id']}")
        lines.append(f"  {r['snippet'][:150]}...")
    return "\n".join(lines)


@tool("write_wiki_query_page", parse_docstring=True)
async def write_wiki_query_page(topic_id: str, title: str, content: str) -> str:
    """Archive a valuable question-answer as a new wiki query page.

    Use this to save a synthesized answer for future reference.
    Only creates page_type='query' pages. Cannot modify existing pages.

    Args:
        topic_id: The knowledge topic ID to write the page to
        title: A descriptive title for the query page (will be slugified)
        content: The full Markdown content of the answer
    """
    import re

    slug = re.sub(r"[^\w\s-]", "", title.lower().strip())
    slug = re.sub(r"\s+", "-", slug)[:60]
    page_title = f"query-{slug}"

    repo = _get_repo()
    page = await repo.create_page(
        topic_id=topic_id,
        title=page_title,
        content=content,
        page_type="query",
        frontmatter={"tags": ["query"], "confidence": 0.9},
    )

    await repo.create_log_entry(
        topic_id=topic_id,
        operation="query_writeback",
        detail={"page_id": page["id"], "title": page_title},
    )

    return f"Query page created: {page_title} (id: {page['id']})"
