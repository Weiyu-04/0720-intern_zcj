"""Mutable domain taxonomy manifest (domains.json).

The authoritative source for the left-sidebar domain menu. Default seed lives
in ``zcjagent/skills/default_domains.json`` (version-controlled); the runtime
copy is ``<skills_root>/domains.json`` and is seeded on first load.

Concurrency: all mutations are serialized by a module-level ``asyncio.Lock``
(read-modify-write inside the lock). Single-admin operation, low contention.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import shutil
import unicodedata
from collections.abc import Callable
from pathlib import Path
from typing import Any

from zcjagent.skills.types import SkillCategory

logger = logging.getLogger(__name__)

_MANIFEST_FILENAME = "domains.json"
_DEFAULT_SEED_REL = Path("default_domains.json")  # relative to zcjagent/skills/
_LOCK = asyncio.Lock()


def _slugify(name: str) -> str:
    """Convert a display name to a stable kebab-case slug.

    Non-ASCII (e.g. Chinese) is romanized via NFKD then ASCII-folded to a
    best-effort phonetic slug; remaining non [a-z0-9-] chars are dropped.
    Falls back to a sanitized form when ASCII folding yields nothing usable.
    """
    text = unicodedata.normalize("NFKD", name.strip().lower())
    ascii_text = text.encode("ascii", "ignore").decode("ascii")
    slug = re.sub(r"[^a-z0-9]+", "-", ascii_text).strip("-")
    if not slug:
        # No ASCII fold-out (pure-emoji, pure-CJK with no romanization) —
        # fall back to a safe placeholder so the slug is never empty.
        slug = "domain"
    return slug


def _unique_slug(base: str, existing: set[str]) -> str:
    """Return ``base`` if free, else ``base-2``, ``base-3`` ... (first free)."""
    if base not in existing:
        return base
    n = 2
    while f"{base}-{n}" in existing:
        n += 1
    return f"{base}-{n}"


class DomainManifestStore:
    """Loads/saves/mutates the domains.json taxonomy."""

    def __init__(self, skills_root: Path) -> None:
        self._skills_root = Path(skills_root)

    # ------------------------------------------------------------------
    # Path helpers
    # ------------------------------------------------------------------
    @property
    def manifest_path(self) -> Path:
        return self._skills_root / _MANIFEST_FILENAME

    def _default_seed_path(self) -> Path:
        return Path(__file__).resolve().parent.parent / _DEFAULT_SEED_REL

    # ------------------------------------------------------------------
    # Load / save
    # ------------------------------------------------------------------
    async def aload(self) -> dict[str, Any]:
        """Load the manifest, seeding from default if absent. Does NOT run orphan check."""
        return await self._aload(run_orphan_check=False)

    async def aload_with_orphan_check(self) -> dict[str, Any]:
        """Load and auto-null any slot whose linked skill dir no longer exists."""
        return await self._aload(run_orphan_check=True)

    async def _aload(self, *, run_orphan_check: bool) -> dict[str, Any]:
        path = self.manifest_path
        if not path.exists():
            seed = self._default_seed_path()
            shutil.copyfile(seed, path)
            logger.info("Seeded domains.json from default (%s)", seed)
        manifest = json.loads(path.read_text(encoding="utf-8"))
        if run_orphan_check:
            changed = self._null_orphans(manifest)
            if changed:
                await self._write_unsafe(manifest)
        return manifest

    def _null_orphans(self, manifest: dict[str, Any]) -> bool:
        """Null slots whose skill_name points at a missing public skill dir.

        Returns True if any change was made.
        """
        public_root = self._skills_root / SkillCategory.PUBLIC.value
        changed = False
        for domain in manifest.get("domains", []):
            for slot in domain.get("slots", []):
                name = slot.get("skill_name")
                if name and not (public_root / name).is_dir():
                    slot["skill_name"] = None
                    changed = True
        return changed

    async def asave(self, manifest: dict[str, Any]) -> None:
        """Persist the manifest (atomic write). Does NOT take the lock."""
        await self._write_unsafe(manifest)

    async def _write_unsafe(self, manifest: dict[str, Any]) -> None:
        path = self.manifest_path
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)

    async def _mutate(self, fn: Callable[[dict[str, Any]], Any]) -> Any:
        """Lock-guarded read-modify-write."""
        async with _LOCK:
            manifest = await self._aload(run_orphan_check=False)
            result = fn(manifest)
            await self._write_unsafe(manifest)
            return result

    # ------------------------------------------------------------------
    # Helpers to locate
    # ------------------------------------------------------------------
    @staticmethod
    def _find_domain(manifest: dict[str, Any], domain_id: str) -> dict[str, Any]:
        from zcjagent.skills.storage.domain_errors import DomainNotFound

        for d in manifest.get("domains", []):
            if d["id"] == domain_id:
                return d
        raise DomainNotFound(domain_id)

    @staticmethod
    def _find_slot(domain: dict[str, Any], slot_id: str) -> dict[str, Any]:
        from zcjagent.skills.storage.domain_errors import SlotNotFound

        for s in domain.get("slots", []):
            if s["id"] == slot_id:
                return s
        raise SlotNotFound(domain["id"], slot_id)

    @staticmethod
    def _all_ids(manifest: dict[str, Any]) -> set[str]:
        ids: set[str] = set()
        for d in manifest.get("domains", []):
            ids.add(d["id"])
            for s in d.get("slots", []):
                ids.add(s["id"])
        return ids

    # ------------------------------------------------------------------
    # Domain CRUD
    # ------------------------------------------------------------------
    async def acreate_domain(self, *, name: str, icon: str) -> dict[str, Any]:
        def _do(manifest: dict[str, Any]) -> dict[str, Any]:
            existing = self._all_ids(manifest)
            base = _unique_slug(_slugify(name), existing)
            new_domain = {
                "id": base,
                "name": name.strip(),
                "icon": icon,
                "sort": len(manifest["domains"]),
                "slots": [],
            }
            manifest["domains"].append(new_domain)
            return new_domain

        return await self._mutate(_do)

    async def aupdate_domain(
        self, domain_id: str, *, name: str | None = None, icon: str | None = None,
    ) -> dict[str, Any]:
        def _do(manifest: dict[str, Any]) -> dict[str, Any]:
            domain = self._find_domain(manifest, domain_id)
            if name is not None:
                domain["name"] = name.strip()
            if icon is not None:
                domain["icon"] = icon
            return domain

        return await self._mutate(_do)

    async def adelete_domain(self, domain_id: str) -> None:
        def _do(manifest: dict[str, Any]) -> None:
            domain = self._find_domain(manifest, domain_id)
            if any(s.get("skill_name") for s in domain.get("slots", [])):
                from zcjagent.skills.storage.domain_errors import DomainHasContent
                raise DomainHasContent(domain_id)
            manifest["domains"] = [d for d in manifest["domains"] if d["id"] != domain_id]

        await self._mutate(_do)

    async def areorder_domains(self, ordered_ids: list[str]) -> None:
        def _do(manifest: dict[str, Any]) -> None:
            from zcjagent.skills.storage.domain_errors import DomainNotFound
            by_id = {d["id"]: d for d in manifest["domains"]}
            new_list: list[dict[str, Any]] = []
            for idx, did in enumerate(ordered_ids):
                d = by_id.get(did)
                if d is None:
                    raise DomainNotFound(did)
                d["sort"] = idx
                new_list.append(d)
            manifest["domains"] = new_list

        await self._mutate(_do)

    # ------------------------------------------------------------------
    # Slot CRUD
    # ------------------------------------------------------------------
    async def acreate_slot(self, domain_id: str, *, name: str, icon: str) -> dict[str, Any]:
        def _do(manifest: dict[str, Any]) -> dict[str, Any]:
            domain = self._find_domain(manifest, domain_id)
            existing = self._all_ids(manifest)
            base = _unique_slug(_slugify(name), existing)
            new_slot = {
                "id": base,
                "name": name.strip(),
                "icon": icon,
                "sort": len(domain["slots"]),
                "skill_name": None,
            }
            domain["slots"].append(new_slot)
            return new_slot

        return await self._mutate(_do)

    async def aupdate_slot(
        self, domain_id: str, slot_id: str, *, name: str | None = None, icon: str | None = None,
    ) -> dict[str, Any]:
        def _do(manifest: dict[str, Any]) -> dict[str, Any]:
            domain = self._find_domain(manifest, domain_id)
            slot = self._find_slot(domain, slot_id)
            if name is not None:
                slot["name"] = name.strip()
            if icon is not None:
                slot["icon"] = icon
            return slot

        return await self._mutate(_do)

    async def adelete_slot(self, domain_id: str, slot_id: str) -> None:
        def _do(manifest: dict[str, Any]) -> None:
            from zcjagent.skills.storage.domain_errors import SlotHasContent
            domain = self._find_domain(manifest, domain_id)
            slot = self._find_slot(domain, slot_id)
            if slot.get("skill_name"):
                raise SlotHasContent(domain_id, slot_id)
            domain["slots"] = [s for s in domain["slots"] if s["id"] != slot_id]

        await self._mutate(_do)

    async def areorder_slots(self, domain_id: str, ordered_ids: list[str]) -> None:
        def _do(manifest: dict[str, Any]) -> None:
            from zcjagent.skills.storage.domain_errors import SlotNotFound
            domain = self._find_domain(manifest, domain_id)
            by_id = {s["id"]: s for s in domain["slots"]}
            new_list: list[dict[str, Any]] = []
            for idx, sid in enumerate(ordered_ids):
                s = by_id.get(sid)
                if s is None:
                    raise SlotNotFound(domain_id, sid)
                s["sort"] = idx
                new_list.append(s)
            domain["slots"] = new_list

        await self._mutate(_do)

    # ------------------------------------------------------------------
    # Slot content linkage
    # ------------------------------------------------------------------
    async def aset_slot_skill_name(self, domain_id: str, slot_id: str, skill_name: str) -> None:
        def _do(manifest: dict[str, Any]) -> None:
            domain = self._find_domain(manifest, domain_id)
            slot = self._find_slot(domain, slot_id)
            slot["skill_name"] = skill_name

        await self._mutate(_do)

    async def aclear_slot_skill_name(self, domain_id: str, slot_id: str) -> None:
        def _do(manifest: dict[str, Any]) -> None:
            domain = self._find_domain(manifest, domain_id)
            slot = self._find_slot(domain, slot_id)
            slot["skill_name"] = None

        await self._mutate(_do)

    async def afind_slot_by_id(self, slot_id: str) -> tuple[dict[str, Any], dict[str, Any]] | None:
        """Return (domain, slot) for a slot_id, or None if not found."""
        manifest = await self._aload(run_orphan_check=False)
        for d in manifest.get("domains", []):
            for s in d.get("slots", []):
                if s["id"] == slot_id:
                    return d, s
        return None

    async def afind_slot_by_skill_name(self, skill_name: str) -> tuple[dict[str, Any], dict[str, Any]] | None:
        """Return (domain, slot) whose ``skill_name`` links to ``skill_name``, or None.

        Used to prevent orphan references when an admin tries to delete a public
        skill that a domain slot still points at.
        """
        manifest = await self._aload(run_orphan_check=False)
        for d in manifest.get("domains", []):
            for s in d.get("slots", []):
                if s.get("skill_name") == skill_name:
                    return d, s
        return None
