"""Local-filesystem implementation of ``SkillStorage``."""

from __future__ import annotations

import errno
import json
import logging
import os
import shutil
import tempfile
from collections.abc import Iterable
from datetime import UTC, datetime
from pathlib import Path

from zcjagent.config.runtime_paths import resolve_path
from zcjagent.skills.permissions import make_skill_written_path_sandbox_readable
from zcjagent.skills.storage.skill_storage import SKILL_MD_FILE, SkillStorage
from zcjagent.skills.types import SkillCategory

logger = logging.getLogger(__name__)

DEFAULT_SKILLS_CONTAINER_PATH = "/mnt/skills"


class LocalSkillStorage(SkillStorage):
    """Skill storage backed by the local filesystem.

    Layout::

        <root>/public/<name>/SKILL.md
        <root>/custom/users/{user_id}/<name>/SKILL.md
        <root>/custom/.history/users/{user_id}/<name>.jsonl
    """

    def __init__(
        self,
        host_path: str | None = None,
        container_path: str = DEFAULT_SKILLS_CONTAINER_PATH,
        app_config=None,
    ) -> None:
        super().__init__(container_path=container_path)
        if host_path is None:
            from zcjagent.config import get_app_config

            config = app_config or get_app_config()
            self._host_root: Path = config.skills.get_skills_path()
        else:
            self._host_root = resolve_path(host_path)

    # ------------------------------------------------------------------
    # Abstract operation implementations
    # ------------------------------------------------------------------

    def get_skills_root_path(self) -> Path:
        return self._host_root

    def custom_skill_exists(self, name: str, *, user_id: str) -> bool:
        return self.get_custom_skill_file(name, user_id=user_id).exists()

    def public_skill_exists(self, name: str) -> bool:
        normalized_name = self.validate_skill_name(name)
        return (self._host_root / SkillCategory.PUBLIC.value / normalized_name / SKILL_MD_FILE).exists()

    def _iter_public_skill_files(self) -> Iterable[tuple[SkillCategory, Path, Path]]:
        if not self._host_root.exists():
            return
        category_path = self._host_root / SkillCategory.PUBLIC.value
        if not category_path.exists() or not category_path.is_dir():
            return
        for current_root, dir_names, file_names in os.walk(category_path, followlinks=True):
            dir_names[:] = sorted(name for name in dir_names if not name.startswith("."))
            if SKILL_MD_FILE not in file_names:
                continue
            yield SkillCategory.PUBLIC, category_path, Path(current_root) / SKILL_MD_FILE

    def _iter_user_skill_files(self, user_id: str) -> Iterable[tuple[SkillCategory, Path, Path]]:
        """Yield ``(SkillCategory, category_root, skill_md_path)`` for a user's personal skills.

        Note: ``category_root`` is the ``custom/`` root (NOT the per-user subdir) so the
        ``users/<uid>/`` segment is preserved in downstream ``relative_path`` computations
        and container-facing paths stay correct (``/mnt/skills/custom/users/<uid>/<name>/SKILL.md``).
        """
        normalized_user = self._validate_user_id(user_id)
        custom_root = self._host_root / SkillCategory.CUSTOM.value
        user_path = custom_root / "users" / normalized_user
        if not user_path.exists() or not user_path.is_dir():
            return
        for current_root, dir_names, file_names in os.walk(user_path, followlinks=True):
            dir_names[:] = sorted(name for name in dir_names if not name.startswith("."))
            if SKILL_MD_FILE not in file_names:
                continue
            yield SkillCategory.CUSTOM, custom_root, Path(current_root) / SKILL_MD_FILE

    def _iter_all_user_skill_files(self) -> Iterable[tuple[str, Path, Path]]:
        """Yield ``(user_id, custom_root, skill_md_path)`` for every user's personal skill.

        ``custom_root`` (not ``user_root``) is yielded so downstream ``relative_path``
        preserves the ``users/<uid>/`` segment — matches the convention from
        :meth:`_iter_user_skill_files`.
        """
        custom_root = self._host_root / SkillCategory.CUSTOM.value
        users_root = custom_root / "users"
        if not users_root.exists() or not users_root.is_dir():
            return
        for user_entry in sorted(users_root.iterdir()):
            if not user_entry.is_dir() or user_entry.name.startswith("."):
                continue
            for current_root, dir_names, file_names in os.walk(user_entry, followlinks=True):
                dir_names[:] = sorted(name for name in dir_names if not name.startswith("."))
                if SKILL_MD_FILE not in file_names:
                    continue
                yield user_entry.name, custom_root, Path(current_root) / SKILL_MD_FILE

    def read_custom_skill(self, name: str, *, user_id: str) -> str:
        if not self.custom_skill_exists(name, user_id=user_id):
            raise FileNotFoundError(f"Custom skill '{name}' not found.")
        return (self.get_custom_skill_dir(name, user_id=user_id) / SKILL_MD_FILE).read_text(encoding="utf-8")

    def write_custom_skill(self, name: str, relative_path: str, content: str, *, user_id: str) -> None:
        target = self.validate_relative_path(relative_path, self.get_custom_skill_dir(name, user_id=user_id))
        target.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(
            "w",
            encoding="utf-8",
            delete=False,
            dir=str(target.parent),
        ) as tmp_file:
            tmp_file.write(content)
            tmp_path = Path(tmp_file.name)
        tmp_path.replace(target)
        make_skill_written_path_sandbox_readable(self.get_custom_skill_dir(name, user_id=user_id), target)

    async def ainstall_skill_from_archive(
        self,
        archive_path: str | Path,
        *,
        user_id: str,
        scope: str,
    ) -> dict:
        import zipfile

        from zcjagent.skills.installer import (
            SkillAlreadyExistsError,
            _move_staged_skill_into_reserved_target,
            _scan_skill_archive_contents_or_raise,
            resolve_skill_dir_from_archive,
            safe_extract_skill_archive,
        )
        from zcjagent.skills.validation import _validate_skill_frontmatter

        logger.info("Installing skill from %s", archive_path)
        path = Path(archive_path)
        if not path.is_file():
            if not path.exists():
                raise FileNotFoundError(f"Skill file not found: {archive_path}")
            raise ValueError(f"Path is not a file: {archive_path}")
        if path.suffix not in (".skill", ".zip"):
            raise ValueError("File must have .skill or .zip extension")

        if scope == "public":
            target_root = self._host_root / SkillCategory.PUBLIC.value
        elif scope == "personal":
            if not user_id:
                raise ValueError("user_id is required for personal-scope uploads.")
            target_root = (
                self._host_root
                / SkillCategory.CUSTOM.value
                / "users"
                / self._validate_user_id(user_id)
            )
        else:
            raise ValueError(f"Invalid scope: {scope!r}. Must be 'public' or 'personal'.")

        target_root.mkdir(parents=True, exist_ok=True)

        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)

            try:
                zf = zipfile.ZipFile(path, "r")
            except FileNotFoundError:
                raise FileNotFoundError(f"Skill file not found: {archive_path}") from None
            except (zipfile.BadZipFile, IsADirectoryError):
                raise ValueError("File is not a valid ZIP archive") from None

            with zf:
                safe_extract_skill_archive(zf, tmp_path)

            skill_dir = resolve_skill_dir_from_archive(tmp_path)

            is_valid, message, skill_name = _validate_skill_frontmatter(skill_dir)
            if not is_valid:
                raise ValueError(f"Invalid skill: {message}")
            if not skill_name or "/" in skill_name or "\\" in skill_name or ".." in skill_name:
                raise ValueError(f"Invalid skill name: {skill_name}")

            target = target_root / skill_name
            if target.exists():
                raise SkillAlreadyExistsError(f"Skill '{skill_name}' already exists")

            await _scan_skill_archive_contents_or_raise(skill_dir, skill_name)

            with tempfile.TemporaryDirectory(prefix=f".installing-{skill_name}-", dir=target_root) as staging_root:
                staging_target = Path(staging_root) / skill_name
                shutil.copytree(skill_dir, staging_target)
                _move_staged_skill_into_reserved_target(staging_target, target)
            logger.info("Skill %r installed to %s", skill_name, target)

        return {
            "success": True,
            "skill_name": skill_name,
            "message": f"Skill '{skill_name}' installed successfully",
        }

    def delete_custom_skill(self, name: str, *, user_id: str, history_meta: dict | None = None) -> None:
        self.validate_skill_name(name)
        self.ensure_custom_skill_is_editable(name, user_id=user_id)
        target = self.get_custom_skill_dir(name, user_id=user_id)
        if history_meta is not None:
            prev_content = self.read_custom_skill(name, user_id=user_id)
            try:
                self.append_history(name, {**history_meta, "prev_content": prev_content}, user_id=user_id)
            except OSError as e:
                if not isinstance(e, PermissionError) and e.errno not in {errno.EACCES, errno.EPERM, errno.EROFS}:
                    raise
                logger.warning(
                    "Skipping delete history write for custom skill %s due to readonly/permission failure; continuing with skill directory removal: %s",
                    name,
                    e,
                )
        if target.exists():
            shutil.rmtree(target)

    def append_history(self, name: str, record: dict, *, user_id: str) -> None:
        self.validate_skill_name(name)
        payload = {"ts": datetime.now(UTC).isoformat(), **record}
        history_path = self.get_skill_history_file(name, user_id=user_id)
        history_path.parent.mkdir(parents=True, exist_ok=True)
        with history_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(payload, ensure_ascii=False))
            f.write("\n")

    def read_history(self, name: str, *, user_id: str) -> list[dict]:
        self.validate_skill_name(name)
        history_path = self.get_skill_history_file(name, user_id=user_id)
        if not history_path.exists():
            return []
        records: list[dict] = []
        for line in history_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            records.append(json.loads(line))
        return records
