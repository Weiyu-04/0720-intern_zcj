"""Abstract SkillStorage base class with template-method flows."""

from __future__ import annotations

import logging
import re
from abc import ABC, abstractmethod
from collections.abc import Iterable
from pathlib import Path

from zcjagent.config.paths import _validate_user_id as _validate_user_id_path
from zcjagent.skills.types import SKILL_MD_FILE, Skill, SkillCategory  # noqa: F401

logger = logging.getLogger(__name__)

_SKILL_NAME_PATTERN = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")

# Reuse the strict allowlist validator from ``zcjagent.config.paths`` so the
# skill storage layout shares one user-id policy with the broader per-user
# isolation system (memory, agents, threads). That helper enforces
# ``^[A-Za-z0-9_\-]+$`` — a strict superset of the safety properties a
# skill-storage-local blocklist would provide — and keeps the two paths from
# drifting (e.g. one accepting ``.`` while the other rejects it).
_validate_user_id = _validate_user_id_path


class SkillStorage(ABC):
    """Abstract base for skill storage backends.

    Subclasses implement a small set of storage-medium-specific atomic
    operations; this base class provides final template-method flows
    (load_skills, history serialisation, path helpers, validation) that
    compose them with protocol-level helpers.
    """

    def __init__(self, container_path: str = "/mnt/skills") -> None:
        self._container_root = container_path

    # ------------------------------------------------------------------
    # Static protocol helpers (not storage-specific)
    # ------------------------------------------------------------------

    @staticmethod
    def validate_skill_name(name: str) -> str:
        """Validate and normalise a skill name; return the normalised form."""
        normalized = name.strip()
        if not _SKILL_NAME_PATTERN.fullmatch(normalized):
            raise ValueError("Skill name must be hyphen-case using lowercase letters, digits, and hyphens only.")
        if len(normalized) > 64:
            raise ValueError("Skill name must be 64 characters or fewer.")
        return normalized

    @staticmethod
    def _validate_user_id(user_id: str) -> str:
        """Validate a user_id for filesystem paths.

        Thin wrapper over :func:`zcjagent.config.paths._validate_user_id` so
        the skill-storage layer shares one policy with the rest of the
        per-user isolation system. Allows ``[A-Za-z0-9_\\-]`` only.
        """
        return _validate_user_id_path(user_id)

    @staticmethod
    def validate_relative_path(relative_path: str, base_dir: Path) -> Path:
        """Validate *relative_path* against *base_dir* and return the resolved target.

        Checks that *relative_path* is non-empty, then joins it with *base_dir*
        and resolves the result (following symlinks).  Raises ``ValueError`` if
        the resolved target does not lie within *base_dir*.
        """
        if not relative_path:
            raise ValueError("relative_path must not be empty.")
        resolved_base = base_dir.resolve()
        target = (resolved_base / relative_path).resolve()
        try:
            target.relative_to(resolved_base)
        except ValueError as exc:
            raise ValueError("relative_path must resolve within the skill directory.") from exc
        return target

    @staticmethod
    def validate_skill_markdown_content(name: str, content: str) -> None:
        """Validate SKILL.md content: parse frontmatter and check name matches."""
        import tempfile

        from zcjagent.skills.validation import _validate_skill_frontmatter

        with tempfile.TemporaryDirectory() as tmp_dir:
            temp_skill_dir = Path(tmp_dir) / SkillStorage.validate_skill_name(name)
            temp_skill_dir.mkdir(parents=True, exist_ok=True)
            (temp_skill_dir / SKILL_MD_FILE).write_text(content, encoding="utf-8")
            is_valid, message, parsed_name = _validate_skill_frontmatter(temp_skill_dir)
            if not is_valid:
                raise ValueError(message)
            if parsed_name != name:
                raise ValueError(f"Frontmatter name '{parsed_name}' must match requested skill name '{name}'.")

    def ensure_safe_support_path(self, name: str, relative_path: str, *, user_id: str) -> Path:
        """Validate and return the resolved absolute path for a support file."""
        _ALLOWED_SUPPORT_SUBDIRS = {"references", "templates", "scripts", "assets"}
        skill_dir = self.get_custom_skill_dir(self.validate_skill_name(name), user_id=user_id).resolve()
        if not relative_path or relative_path.endswith("/"):
            raise ValueError("Supporting file path must include a filename.")
        relative = Path(relative_path)
        if relative.is_absolute():
            raise ValueError("Supporting file path must be relative.")
        if any(part in {"..", ""} for part in relative.parts):
            raise ValueError("Supporting file path must not contain parent-directory traversal.")
        top_level = relative.parts[0] if relative.parts else ""
        if top_level not in _ALLOWED_SUPPORT_SUBDIRS:
            raise ValueError(f"Supporting files must live under one of: {', '.join(sorted(_ALLOWED_SUPPORT_SUBDIRS))}.")
        target = (skill_dir / relative).resolve()
        allowed_root = (skill_dir / top_level).resolve()
        try:
            target.relative_to(allowed_root)
        except ValueError as exc:
            raise ValueError("Supporting file path must stay within the selected support directory.") from exc
        return target

    # ------------------------------------------------------------------
    # Abstract atomic operations (storage-medium specific)
    # ------------------------------------------------------------------

    @abstractmethod
    def get_skills_root_path(self) -> Path:
        """Absolute host path to the skills root, used for sandbox mounts.

        Origin: ``zcjagent.skills.loader.get_skills_root_path``.
        """

    @abstractmethod
    def _iter_public_skill_files(self) -> Iterable[tuple[SkillCategory, Path, Path]]:
        """Yield ``(category, category_root, skill_md_path)`` for public skills only."""

    @abstractmethod
    def _iter_user_skill_files(self, user_id: str) -> Iterable[tuple[SkillCategory, Path, Path]]:
        """Yield ``(category, category_root, skill_md_path)`` for one user's personal skills."""

    @abstractmethod
    def _iter_all_user_skill_files(self) -> Iterable[tuple[str, Path, Path]]:
        """Yield ``(user_id, user_root, skill_md_path)`` for every user's personal skill.

        Used by the admin governance view (``GET /api/skills/all-users``). Returns
        skills across ALL users — caller MUST ensure admin auth before invoking.
        """

    @abstractmethod
    def read_custom_skill(self, name: str, *, user_id: str) -> str:
        """Read SKILL.md content for a custom skill.

        Origin: ``zcjagent.skills.manager.read_custom_skill_content``.
        """

    @abstractmethod
    def write_custom_skill(self, name: str, relative_path: str, content: str, *, user_id: str) -> None:
        """Atomically write a text file under ``custom/users/{user_id}/<name>/<relative_path>``.

        Origin: ``zcjagent.skills.manager.atomic_write``.
        """

    @abstractmethod
    async def ainstall_skill_from_archive(
        self,
        archive_path: str | Path,
        *,
        user_id: str,
        scope: str,
    ) -> dict:
        """Async install of a skill from a ``.skill`` ZIP archive.

        Origin: ``zcjagent.skills.installer.ainstall_skill_from_archive``.
        """

    def install_skill_from_archive(
        self,
        archive_path: str | Path,
        *,
        user_id: str = "default",
        scope: str = "personal",
    ) -> dict:
        """Sync wrapper — delegates to :meth:`ainstall_skill_from_archive`.

        Defaults to ``user_id="default"`` / ``scope="personal"`` so legacy
        callers that install without an authenticated user continue to work
        (matching the no-auth fallback used elsewhere in the codebase).
        Production callers that know the user should pass the kwargs explicitly.
        """
        from zcjagent.skills.installer import _run_async_install

        return _run_async_install(self.ainstall_skill_from_archive(archive_path, user_id=user_id, scope=scope))

    @abstractmethod
    def delete_custom_skill(self, name: str, *, user_id: str, history_meta: dict | None = None) -> None:
        """Delete a custom skill (validation + optional history + directory removal).

        Origin: ``app.gateway.routers.skills.delete_custom_skill`` + ``skill_manage_tool``.
        """

    @abstractmethod
    def custom_skill_exists(self, name: str, *, user_id: str) -> bool:
        """Origin: ``zcjagent.skills.manager.custom_skill_exists``."""

    @abstractmethod
    def public_skill_exists(self, name: str) -> bool:
        """Origin: ``zcjagent.skills.manager.public_skill_exists``."""

    @abstractmethod
    def append_history(self, name: str, record: dict, *, user_id: str) -> None:
        """Append a JSONL history entry for ``name``.

        Origin: ``zcjagent.skills.manager.append_history``.
        """

    @abstractmethod
    def read_history(self, name: str, *, user_id: str) -> list[dict]:
        """Return all history records for ``name``, oldest first.

        Origin: ``zcjagent.skills.manager.read_history``.
        """

    # ------------------------------------------------------------------
    # Concrete path helpers (layout is part of the SKILL.md protocol)
    # ------------------------------------------------------------------

    def get_container_root(self) -> str:
        """Origin: ``zcjagent.config.skills_config.SkillsConfig.container_path`` accessor."""
        return self._container_root

    def get_custom_skill_dir(self, name: str, *, user_id: str) -> Path:
        """Path to ``custom/users/{user_id}/<name>``.

        Raises ``ValueError`` if ``user_id`` is falsy — every custom-skill path
        must be user-scoped under the new layout.
        """
        if not user_id:
            raise ValueError("user_id is required for custom-skill paths.")
        normalized_name = self.validate_skill_name(name)
        normalized_user = self._validate_user_id(user_id)
        return (
            self.get_skills_root_path()
            / SkillCategory.CUSTOM.value
            / "users"
            / normalized_user
            / normalized_name
        )

    def get_custom_skill_file(self, name: str, *, user_id: str) -> Path:
        """Path to ``custom/users/{user_id}/<name>/SKILL.md``.

        Origin: ``zcjagent.skills.manager.get_custom_skill_file``.
        """
        normalized_name = self.validate_skill_name(name)
        return self.get_custom_skill_dir(normalized_name, user_id=user_id) / SKILL_MD_FILE

    def get_skill_history_file(self, name: str, *, user_id: str) -> Path:
        """Path to ``custom/.history/users/{user_id}/<name>.jsonl``. Does not create parents.

        Origin: ``zcjagent.skills.manager.get_skill_history_file``.
        """
        normalized_name = self.validate_skill_name(name)
        normalized_user = self._validate_user_id(user_id)
        return (
            self.get_skills_root_path()
            / SkillCategory.CUSTOM.value
            / ".history"
            / "users"
            / normalized_user
            / f"{normalized_name}.jsonl"
        )

    # ------------------------------------------------------------------
    # Final template-method flows
    # ------------------------------------------------------------------

    def load_skills(self, user_id: str | None = None, *, enabled_only: bool = False) -> list[Skill]:
        """Discover skills visible to ``user_id`` (public only if None).

        Origin: ``zcjagent.skills.loader.load_skills``.

        - ``user_id=None`` → public skills only (backward compatible).
        - ``user_id="u1"`` → ``public/*`` + ``custom/users/u1/*``, merged.
          Public wins on name collision (defense-in-depth; collisions are
          rejected at upload time).
        """
        from zcjagent.skills.parser import parse_skill_file

        skills_by_name: dict[str, Skill] = {}
        for category, category_root, md_path in self._iter_public_skill_files():
            skill = parse_skill_file(
                md_path,
                category=category,
                relative_path=md_path.parent.relative_to(category_root),
            )
            if skill:
                skills_by_name[skill.name] = skill

        if user_id is not None:
            for category, category_root, md_path in self._iter_user_skill_files(user_id):
                skill = parse_skill_file(
                    md_path,
                    category=category,
                    relative_path=md_path.parent.relative_to(category_root),
                )
                if skill and skill.name not in skills_by_name:
                    skills_by_name[skill.name] = skill

        skills = list(skills_by_name.values())

        # Merge enabled state from extensions config (public skills only).
        # Personal skills are always enabled (decision 2 of the spec).
        try:
            from zcjagent.config.extensions_config import ExtensionsConfig

            extensions_config = ExtensionsConfig.from_file()
            for skill in skills:
                if skill.category == SkillCategory.PUBLIC:
                    skill.enabled = extensions_config.is_skill_enabled(skill.name, skill.category)
                else:
                    skill.enabled = True
        except Exception as e:
            logger.warning("Failed to load extensions config: %s", e)
            for skill in skills:
                skill.enabled = True

        if enabled_only:
            skills = [s for s in skills if s.enabled]

        skills.sort(key=lambda s: s.name)
        return skills

    def load_all_user_skills(self) -> list[tuple[str, Skill]]:
        """Return ``(user_id, Skill)`` for every personal skill across all users.

        Used by the admin governance view. Personal skills are always enabled
        (per decision 2 of the spec), so the returned skills have ``enabled=True``.
        """
        from zcjagent.skills.parser import parse_skill_file

        out: list[tuple[str, Skill]] = []
        for user_id, custom_root, md_path in self._iter_all_user_skill_files():
            skill = parse_skill_file(
                md_path,
                category=SkillCategory.CUSTOM,
                relative_path=md_path.parent.relative_to(custom_root),
            )
            if skill:
                skill.enabled = True
                out.append((user_id, skill))
        out.sort(key=lambda pair: (pair[0], pair[1].name))
        return out

    def ensure_custom_skill_is_editable(self, name: str, *, user_id: str) -> None:
        """Origin: ``zcjagent.skills.manager.ensure_custom_skill_is_editable``."""
        if self.custom_skill_exists(name, user_id=user_id):
            return
        if self.public_skill_exists(name):
            raise ValueError(
                f"'{name}' is a built-in skill. To customise it, create a new skill with the same name."
            )
        raise FileNotFoundError(f"Custom skill '{name}' not found for user '{user_id}'.")
