"""Domain manifest error types.

Raised by the manifest mutation helpers; mapped to HTTP status codes in the
skills router (404 / 409 / 400).
"""

from __future__ import annotations


class DomainManifestError(Exception):
    """Base class for domain manifest errors."""


class DomainNotFound(DomainManifestError):
    """Raised when a referenced domain id does not exist."""

    def __init__(self, domain_id: str) -> None:
        super().__init__(f"Domain '{domain_id}' not found")
        self.domain_id = domain_id


class SlotNotFound(DomainManifestError):
    """Raised when a referenced slot id does not exist under its domain."""

    def __init__(self, domain_id: str, slot_id: str) -> None:
        super().__init__(f"Slot '{slot_id}' not found in domain '{domain_id}'")
        self.domain_id = domain_id
        self.slot_id = slot_id


class DomainHasContent(DomainManifestError):
    """Raised when deleting a domain that still has uploaded skill content."""

    def __init__(self, domain_id: str) -> None:
        super().__init__(f"Domain '{domain_id}' has uploaded skills; clear them first")
        self.domain_id = domain_id


class SlotHasContent(DomainManifestError):
    """Raised when deleting a slot that still has an uploaded skill."""

    def __init__(self, domain_id: str, slot_id: str) -> None:
        super().__init__(f"Slot '{slot_id}' in domain '{domain_id}' has uploaded content; clear it first")
        self.domain_id = domain_id
        self.slot_id = slot_id


class IdAlreadyExists(DomainManifestError):
    """Raised when creating a domain/slot whose slug id already exists."""

    def __init__(self, id_: str) -> None:
        super().__init__(f"Id '{id_}' already exists")
        self.id_ = id_
